--
-- PostgreSQL database dump
--

-- Dumped from database version 13.21 (Debian 13.21-1.pgdg120+1)
-- Dumped by pg_dump version 13.21 (Debian 13.21-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: bet_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bet_status AS ENUM (
    'open',
    'in_progress',
    'closed',
    'failed'
);


--
-- Name: components; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.components AS ENUM (
    'real_money',
    'bonus_money',
    'points'
);


--
-- Name: spinningwheelmysterytypes; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.spinningwheelmysterytypes AS ENUM (
    'point',
    'internet_package_in_gb',
    'better',
    'other'
);


--
-- Name: spinningwheeltypes; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.spinningwheeltypes AS ENUM (
    'point',
    'internet_package_in_gb',
    'better',
    'mystery',
    'free spin'
);


--
-- Name: clean_expired_crypto_wallet_challenges(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.clean_expired_crypto_wallet_challenges() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM crypto_wallet_challenges WHERE expires_at < NOW();
END;
$$;


--
-- Name: get_user_wallets(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_user_wallets(user_uuid uuid) RETURNS TABLE(wallet_type character varying, wallet_address character varying, wallet_chain character varying, wallet_name character varying, is_verified boolean, last_used_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        cwc.wallet_type,
        cwc.wallet_address,
        cwc.wallet_chain,
        cwc.wallet_name,
        cwc.is_verified,
        cwc.last_used_at
    FROM crypto_wallet_connections cwc
    WHERE cwc.user_id = user_uuid
    ORDER BY cwc.last_used_at DESC;
END;
$$;


--
-- Name: update_crypto_wallet_connections_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_crypto_wallet_connections_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_block; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account_block (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    blocked_by uuid NOT NULL,
    duration character varying NOT NULL,
    type character varying NOT NULL,
    blocked_from timestamp with time zone,
    blocked_to timestamp with time zone,
    unblocked_at timestamp with time zone,
    reason character varying,
    note character varying,
    created_at timestamp with time zone
);


--
-- Name: adds_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.adds_services (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_url character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    service_id character varying(255) NOT NULL,
    service_secret character varying(255) NOT NULL,
    description text,
    status character varying(255) NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: agent_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    client_id character varying NOT NULL,
    client_secret text NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    name text NOT NULL,
    description text,
    callback_url character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: agent_referrals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_referrals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    request_id character varying(255) NOT NULL,
    callback_url text NOT NULL,
    user_id uuid,
    conversion_type character varying(100),
    amount numeric(20,8) DEFAULT 0,
    msisdn character varying(20),
    converted_at timestamp with time zone DEFAULT now(),
    callback_sent boolean DEFAULT false,
    callback_attempts integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: airtime_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.airtime_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    transaction_id character varying NOT NULL,
    cashout numeric NOT NULL,
    billername character varying NOT NULL,
    utilitypackageid integer NOT NULL,
    packagename character varying NOT NULL,
    amount numeric NOT NULL,
    status character varying NOT NULL,
    "timestamp" timestamp without time zone NOT NULL
);


--
-- Name: airtime_utilities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.airtime_utilities (
    local_id uuid DEFAULT gen_random_uuid() NOT NULL,
    id integer NOT NULL,
    productname character varying NOT NULL,
    billername character varying NOT NULL,
    amount character varying NOT NULL,
    isamountfixed boolean NOT NULL,
    price numeric,
    status character varying NOT NULL,
    "timestamp" timestamp without time zone NOT NULL
);


--
-- Name: balance_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.balance_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    component public.components NOT NULL,
    currency character varying(3),
    change_amount numeric,
    operational_group_id uuid,
    operational_type_id uuid,
    description text,
    "timestamp" timestamp without time zone,
    balance_after_update numeric DEFAULT 0.0 NOT NULL,
    transaction_id character varying DEFAULT ''::character varying NOT NULL,
    status character varying DEFAULT 'COMPLETED'::character varying
);


--
-- Name: balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.balances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    currency character varying(3) NOT NULL,
    real_money numeric,
    bonus_money numeric,
    points integer,
    updated_at timestamp without time zone
);


--
-- Name: banners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.banners (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    page character varying(50) NOT NULL,
    page_url text NOT NULL,
    image_url text NOT NULL,
    headline character varying(255) NOT NULL,
    tagline character varying(500),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: bets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    round_id uuid NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency character varying(3) NOT NULL,
    client_transaction_id character varying(255) NOT NULL,
    cash_out_multiplier numeric(10,2),
    payout numeric(10,2),
    "timestamp" timestamp without time zone,
    status character varying DEFAULT 'ACTIVE'::character varying
);


--
-- Name: casbin_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.casbin_rule (
    id integer NOT NULL,
    ptype character varying(100),
    v0 character varying(100),
    v1 character varying(100),
    v2 character varying(100),
    v3 character varying(100),
    v4 character varying(100),
    v5 character varying(100)
);


--
-- Name: casbin_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.casbin_rule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: casbin_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.casbin_rule_id_seq OWNED BY public.casbin_rule.id;


--
-- Name: clubs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clubs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    club_name character varying NOT NULL,
    status character varying DEFAULT 'ACTIVE'::character varying,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: company; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    site_name character varying(255) NOT NULL,
    support_email character varying(255) NOT NULL,
    support_phone character varying(50) NOT NULL,
    maintenance_mode boolean DEFAULT false,
    maximum_login_attempt integer,
    password_expiry integer,
    lockout_duration integer,
    require_two_factor_authentication boolean DEFAULT false,
    ip_list inet[],
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT company_lockout_duration_check CHECK ((lockout_duration > 0)),
    CONSTRAINT company_maximum_login_attempt_check CHECK ((maximum_login_attempt > 0)),
    CONSTRAINT company_password_expiry_check CHECK ((password_expiry > 0)),
    CONSTRAINT company_support_email_check CHECK (((support_email)::text ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'::text))
);


--
-- Name: configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.configs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(20) NOT NULL,
    value character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: crypto_kings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crypto_kings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    status character varying DEFAULT 'ACTIVE'::character varying NOT NULL,
    bet_amount numeric NOT NULL,
    won_amount numeric,
    start_crypto_value numeric NOT NULL,
    end_crypto_value numeric NOT NULL,
    selected_end_second integer,
    selected_start_value numeric,
    selected_end_value numeric,
    won_status character varying NOT NULL,
    type character varying NOT NULL,
    "timestamp" timestamp without time zone NOT NULL
);


--
-- Name: crypto_wallet_auth_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crypto_wallet_auth_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wallet_address character varying(255) NOT NULL,
    wallet_type character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    ip_address inet,
    user_agent text,
    success boolean NOT NULL,
    error_message text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT crypto_wallet_auth_logs_action_check CHECK (((action)::text = ANY ((ARRAY['connect'::character varying, 'disconnect'::character varying, 'login'::character varying, 'verify'::character varying, 'challenge'::character varying])::text[])))
);


--
-- Name: crypto_wallet_challenges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crypto_wallet_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wallet_address character varying(255) NOT NULL,
    wallet_type character varying(50) NOT NULL,
    challenge_message text NOT NULL,
    challenge_nonce character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    is_used boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: crypto_wallet_connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crypto_wallet_connections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    wallet_type character varying(50) NOT NULL,
    wallet_address character varying(255) NOT NULL,
    wallet_chain character varying(50) DEFAULT 'ethereum'::character varying NOT NULL,
    wallet_name character varying(255),
    wallet_icon_url text,
    is_verified boolean DEFAULT false,
    verification_signature text,
    verification_message text,
    verification_timestamp timestamp with time zone,
    last_used_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT crypto_wallet_connections_wallet_type_check CHECK (((wallet_type)::text = ANY ((ARRAY['metamask'::character varying, 'walletconnect'::character varying, 'coinbase'::character varying, 'phantom'::character varying, 'trust'::character varying, 'ledger'::character varying])::text[])))
);


--
-- Name: currencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.currencies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying NOT NULL,
    status character varying DEFAULT 'ACTIVE'::character varying NOT NULL,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: departements_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departements_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    department_id uuid NOT NULL,
    created_at timestamp with time zone
);


--
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying NOT NULL,
    notifications text[],
    created_at timestamp without time zone
);


--
-- Name: exchange_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exchange_rates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    currency_from character varying(3),
    currency_to character varying(3),
    rate numeric,
    updated_at timestamp without time zone
);


--
-- Name: failed_bet_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.failed_bet_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    round_id uuid NOT NULL,
    bet_id uuid NOT NULL,
    manual boolean DEFAULT true NOT NULL,
    admin_id uuid,
    status character varying DEFAULT 'IN_PROGRESS'::character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    transaction_id uuid NOT NULL
);


--
-- Name: football_match_rounds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.football_match_rounds (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    status character varying,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: football_matchs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.football_matchs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    round_id uuid NOT NULL,
    league character varying NOT NULL,
    date timestamp without time zone NOT NULL,
    home_team character varying NOT NULL,
    away_team character varying,
    status character varying DEFAULT 'ACTIVE'::character varying,
    won character varying,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL,
    home_score integer DEFAULT 0,
    away_score integer DEFAULT 0
);


--
-- Name: game_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.game_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    round_id uuid NOT NULL,
    action character varying(255) NOT NULL,
    detail json,
    "timestamp" timestamp without time zone
);


--
-- Name: games; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.games (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying NOT NULL,
    status character varying DEFAULT 'ACTIVE'::character varying NOT NULL,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL,
    photo character varying,
    price character varying,
    enabled boolean DEFAULT false
);


--
-- Name: ip_filters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ip_filters (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_by uuid NOT NULL,
    start_ip character varying NOT NULL,
    end_ip character varying NOT NULL,
    type character varying NOT NULL,
    created_at timestamp with time zone,
    description character varying DEFAULT ''::character varying NOT NULL,
    hits integer DEFAULT 0 NOT NULL,
    last_hit timestamp without time zone
);


--
-- Name: leagues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leagues (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    league_name character varying NOT NULL,
    status character varying DEFAULT 'ACTIVE'::character varying,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: level_requirements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.level_requirements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    level_id uuid NOT NULL,
    type character varying NOT NULL,
    value character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp without time zone,
    created_by uuid NOT NULL
);


--
-- Name: levels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.levels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    level numeric NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp without time zone,
    created_by uuid NOT NULL,
    type character varying(50) DEFAULT 'players'::character varying NOT NULL,
    CONSTRAINT levels_type_check CHECK (((type)::text = ANY ((ARRAY['players'::character varying, 'squads'::character varying])::text[])))
);


--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_attempts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    ip_address character varying(50) NOT NULL,
    success boolean NOT NULL,
    attempt_time timestamp without time zone,
    user_agent character varying(50)
);


--
-- Name: logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    module character varying(255) NOT NULL,
    detail json,
    ip_address character varying(46),
    "timestamp" timestamp without time zone
);


--
-- Name: loot_box; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loot_box (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    type text NOT NULL,
    prizeamount numeric NOT NULL,
    weight numeric NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: loot_box_place_bets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loot_box_place_bets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    user_selection uuid,
    loot_box jsonb NOT NULL,
    wonstatus character varying(10) DEFAULT 'pending'::character varying NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: lotteries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lotteries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    price numeric NOT NULL,
    min_selectable integer NOT NULL,
    max_selectable integer NOT NULL,
    draw_frequency text NOT NULL,
    number_of_balls integer NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: lottery_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lottery_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    lottery_id uuid NOT NULL,
    lottery_reward_id uuid NOT NULL,
    prize numeric NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    uniq_identifier uuid DEFAULT gen_random_uuid() NOT NULL,
    draw_numbers integer[]
);


--
-- Name: lottery_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lottery_services (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    client_id character varying NOT NULL,
    client_secret text NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    name text NOT NULL,
    description text,
    callback_url character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: lottery_winners_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lottery_winners_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    lottery_id uuid NOT NULL,
    user_id uuid NOT NULL,
    reward_id uuid NOT NULL,
    won_amount numeric NOT NULL,
    currency text DEFAULT 'P'::text NOT NULL,
    number_of_tickets integer NOT NULL,
    ticket_number text NOT NULL,
    status text DEFAULT 'closed'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: manual_funds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.manual_funds (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    admin_id uuid NOT NULL,
    transaction_id character varying NOT NULL,
    type character varying NOT NULL,
    amount numeric NOT NULL,
    currency character varying(3) NOT NULL,
    note character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    reason character varying DEFAULT 'system_restart'::character varying NOT NULL
);


--
-- Name: operational_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operational_groups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(50),
    description text,
    created_at timestamp without time zone
);


--
-- Name: operational_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operational_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    group_id uuid NOT NULL,
    name character varying(50),
    description text,
    created_at timestamp without time zone
);


--
-- Name: otps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.otps (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    otp_code character varying(10) NOT NULL,
    type character varying(50) DEFAULT 'email_verification'::character varying NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: TABLE otps; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.otps IS 'OTP table for email verification and password reset functionality';


--
-- Name: COLUMN otps.email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.otps.email IS 'Email address for OTP delivery';


--
-- Name: COLUMN otps.otp_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.otps.otp_code IS '6-digit OTP code';


--
-- Name: COLUMN otps.type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.otps.type IS 'Type of OTP: email_verification, password_reset, login';


--
-- Name: COLUMN otps.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.otps.status IS 'Status: pending, verified, expired, used';


--
-- Name: COLUMN otps.expires_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.otps.expires_at IS 'When the OTP expires';


--
-- Name: COLUMN otps.verified_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.otps.verified_at IS 'When the OTP was verified';


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying NOT NULL,
    description character varying
);


--
-- Name: plinko; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plinko (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    bet_amount numeric NOT NULL,
    drop_path character varying NOT NULL,
    multiplier numeric,
    win_amount numeric,
    finalposition numeric,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: quick_hustles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quick_hustles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    status character varying DEFAULT 'ACTIVE'::character varying NOT NULL,
    bet_amount numeric NOT NULL,
    won_status character varying,
    user_guessed character varying,
    first_card character varying NOT NULL,
    second_card character varying,
    "timestamp" timestamp without time zone NOT NULL,
    won_amount numeric
);


--
-- Name: risk_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.risk_settings (
    id smallint DEFAULT 1 NOT NULL,
    system_limits_enabled boolean DEFAULT false NOT NULL,
    system_max_daily_airtime_conversion bigint DEFAULT 0 NOT NULL,
    system_max_weekly_airtime_conversion bigint DEFAULT 0 NOT NULL,
    system_max_monthly_airtime_conversion bigint DEFAULT 0 NOT NULL,
    player_limits_enabled boolean DEFAULT false NOT NULL,
    player_max_daily_airtime_conversion integer DEFAULT 0 NOT NULL,
    player_max_weekly_airtime_conversion integer DEFAULT 0 NOT NULL,
    player_max_monthly_airtime_conversion integer DEFAULT 0 NOT NULL,
    player_min_airtime_conversion_amount integer DEFAULT 0 NOT NULL,
    player_conversion_cooldown_hours integer DEFAULT 0 NOT NULL,
    kyc_required_above_amount integer DEFAULT 0 NOT NULL,
    kyc_verification_timeout_hours integer DEFAULT 0 NOT NULL,
    kyc_allow_partial boolean DEFAULT false NOT NULL,
    fraud_max_login_attempts smallint DEFAULT 5 NOT NULL,
    fraud_login_lockout_duration_minutes integer DEFAULT 0 NOT NULL,
    alert_admins_on_trigger boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT singleton_check CHECK ((id = 1))
);


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying NOT NULL,
    description character varying
);


--
-- Name: roll_da_dice; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roll_da_dice (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    status character varying DEFAULT 'ACTIVE'::character varying NOT NULL,
    bet_amount numeric NOT NULL,
    won_status character varying,
    crash_point numeric NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    won_amount numeric,
    user_guessed_start_point numeric,
    user_guessed_end_point numeric,
    multiplier numeric
);


--
-- Name: rounds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rounds (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    status public.bet_status NOT NULL,
    crash_point numeric(10,2) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    closed_at timestamp without time zone
);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version bigint NOT NULL,
    dirty boolean NOT NULL
);


--
-- Name: scratch_cards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scratch_cards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    status character varying DEFAULT 'ACTIVE'::character varying NOT NULL,
    bet_amount numeric NOT NULL,
    won_status character varying,
    "timestamp" timestamp without time zone NOT NULL,
    won_amount numeric
);


--
-- Name: spinning_wheel_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spinning_wheel_configs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying NOT NULL,
    amount numeric NOT NULL,
    type public.spinningwheeltypes NOT NULL,
    status character varying DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid NOT NULL,
    deleted_at timestamp with time zone,
    frequency integer DEFAULT 1 NOT NULL,
    icon character varying DEFAULT ''::character varying NOT NULL,
    color text DEFAULT 'blue'::text NOT NULL
);


--
-- Name: spinning_wheel_mysteries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spinning_wheel_mysteries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying NOT NULL,
    amount numeric NOT NULL,
    type public.spinningwheelmysterytypes NOT NULL,
    status character varying DEFAULT 'ACTIVE'::character varying NOT NULL,
    frequency integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid NOT NULL,
    deleted_at timestamp with time zone,
    icon character varying DEFAULT ''::character varying NOT NULL
);


--
-- Name: spinning_wheel_rewards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spinning_wheel_rewards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    round_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    amount numeric NOT NULL,
    type character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    claim_status character varying(255) NOT NULL,
    transaction_id character varying,
    user_id uuid NOT NULL
);


--
-- Name: spinning_wheels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spinning_wheels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    status character varying DEFAULT 'ACTIVE'::character varying NOT NULL,
    bet_amount character varying NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    won_amount character varying,
    won_status character varying,
    type character varying(255)
);


--
-- Name: sport_bets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sport_bets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    transaction_id character varying(255) NOT NULL,
    bet_amount numeric(10,2) NOT NULL,
    bet_reference_num character varying(255) NOT NULL,
    game_reference character varying(255) NOT NULL,
    bet_mode character varying(50) NOT NULL,
    description text,
    user_id uuid NOT NULL,
    frontend_type character varying(50),
    status character varying(50),
    sport_ids text,
    site_id character varying(255) NOT NULL,
    client_ip character varying(255),
    affiliate_user_id character varying(255),
    autorecharge character varying(10),
    bet_details jsonb NOT NULL,
    currency character varying(3) DEFAULT 'NGN'::character varying NOT NULL,
    potential_win numeric(10,2),
    actual_win numeric(10,2),
    odds numeric(10,4),
    placed_at timestamp without time zone DEFAULT now() NOT NULL,
    settled_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: squads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.squads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    handle character varying NOT NULL,
    owner uuid NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp without time zone,
    type character varying(50) DEFAULT 'Open'::character varying NOT NULL
);


--
-- Name: squads_earns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.squads_earns (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    squad_id uuid NOT NULL,
    user_id uuid NOT NULL,
    currency character varying(3) DEFAULT 'P'::character varying NOT NULL,
    earned numeric DEFAULT 0 NOT NULL,
    game_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: squads_memebers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.squads_memebers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    squad_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: street_kings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.street_kings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    status character varying DEFAULT 'ACTIVE'::character varying NOT NULL,
    version character varying(50) NOT NULL,
    bet_amount numeric NOT NULL,
    won_amount numeric,
    crash_point numeric NOT NULL,
    cash_out_point numeric,
    "timestamp" timestamp without time zone NOT NULL
);


--
-- Name: temp; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.temp (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    data jsonb NOT NULL
);


--
-- Name: tournaments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournaments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    rank text NOT NULL,
    level integer NOT NULL,
    cumulative_points integer NOT NULL,
    rewards jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: tournaments_claims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournaments_claims (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tournament_id uuid NOT NULL,
    squad_id uuid NOT NULL,
    claimed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    type text NOT NULL,
    metadata jsonb,
    read boolean DEFAULT false NOT NULL,
    delivered boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    read_at timestamp with time zone,
    created_by uuid
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid NOT NULL
);


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    token text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    ip_address character varying(46),
    user_agent character varying(255),
    created_at timestamp without time zone,
    refresh_token text,
    refresh_token_expires_at timestamp without time zone
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    username character varying(20),
    phone_number character varying(15),
    password text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    default_currency character varying(3),
    profile character varying DEFAULT ''::character varying,
    email character varying DEFAULT ''::character varying,
    first_name character varying DEFAULT ''::character varying,
    last_name character varying DEFAULT ''::character varying,
    date_of_birth character varying DEFAULT ''::character varying,
    source character varying DEFAULT ''::character varying,
    is_email_verified boolean DEFAULT false,
    referal_code character varying DEFAULT ''::character varying,
    street_address character varying DEFAULT ''::character varying NOT NULL,
    country character varying DEFAULT ''::character varying NOT NULL,
    state character varying DEFAULT ''::character varying NOT NULL,
    city character varying DEFAULT ''::character varying NOT NULL,
    postal_code character varying DEFAULT ''::character varying NOT NULL,
    kyc_status character varying DEFAULT 'PENDING'::character varying NOT NULL,
    created_by uuid,
    is_admin boolean,
    status character varying DEFAULT 'ACTIVE'::character varying,
    referal_type character varying(255),
    refered_by_code character varying(255),
    user_type character varying(255) DEFAULT 'PLAYER'::character varying,
    primary_wallet_address character varying(255),
    wallet_verification_status character varying(50) DEFAULT 'none'::character varying,
    CONSTRAINT users_wallet_verification_status_check CHECK (((wallet_verification_status)::text = ANY ((ARRAY['none'::character varying, 'pending'::character varying, 'verified'::character varying, 'failed'::character varying])::text[])))
);


--
-- Name: users_football_matche_rounds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_football_matche_rounds (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    status character varying DEFAULT 'ACTIVE'::character varying NOT NULL,
    won_status character varying DEFAULT 'PENDING'::character varying,
    user_id uuid NOT NULL,
    football_round_id uuid,
    bet_amount numeric,
    won_amount numeric NOT NULL,
    "timestamp" timestamp without time zone,
    currency character varying DEFAULT 'USD'::character varying NOT NULL
);


--
-- Name: users_football_matches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_football_matches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    status character varying DEFAULT 'PENDING'::character varying NOT NULL,
    match_id uuid NOT NULL,
    selection character varying DEFAULT 'DRAW'::character varying NOT NULL,
    users_football_matche_round_id uuid
);


--
-- Name: users_otp; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_otp (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    otp character varying NOT NULL,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: waiting_squad_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.waiting_squad_members (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    squad_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: casbin_rule id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.casbin_rule ALTER COLUMN id SET DEFAULT nextval('public.casbin_rule_id_seq'::regclass);


--
-- Data for Name: account_block; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.account_block (id, user_id, blocked_by, duration, type, blocked_from, blocked_to, unblocked_at, reason, note, created_at) FROM stdin;
\.


--
-- Data for Name: adds_services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.adds_services (id, service_url, name, service_id, service_secret, description, status, created_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: agent_providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_providers (id, client_id, client_secret, status, name, description, callback_url, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: agent_referrals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_referrals (id, request_id, callback_url, user_id, conversion_type, amount, msisdn, converted_at, callback_sent, callback_attempts, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: airtime_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.airtime_transactions (id, user_id, transaction_id, cashout, billername, utilitypackageid, packagename, amount, status, "timestamp") FROM stdin;
\.


--
-- Data for Name: airtime_utilities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.airtime_utilities (local_id, id, productname, billername, amount, isamountfixed, price, status, "timestamp") FROM stdin;
\.


--
-- Data for Name: balance_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.balance_logs (id, user_id, component, currency, change_amount, operational_group_id, operational_type_id, description, "timestamp", balance_after_update, transaction_id, status) FROM stdin;
\.


--
-- Data for Name: balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.balances (id, user_id, currency, real_money, bonus_money, points, updated_at) FROM stdin;
86dccfa9-63cd-4771-8403-9e7c97f59448	47781512-f533-45f5-8e6e-14d239e890d5	P	0	0	\N	2025-08-31 23:30:37.356042
643bff9b-9539-4da3-a7d6-c7a2f3c1f68f	3fbc49ac-db45-40c4-a949-ade55082662e	USD	0	0	\N	2025-09-04 02:47:58.482478
43ebfd40-fcd2-410c-92b1-0c1b38d20173	f12e2768-0c41-40af-9c12-0d264a76d5ca	USD	0	0	\N	2025-09-04 02:48:43.232024
\.


--
-- Data for Name: banners; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.banners (id, page, page_url, image_url, headline, tagline, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bets (id, user_id, round_id, amount, currency, client_transaction_id, cash_out_multiplier, payout, "timestamp", status) FROM stdin;
\.


--
-- Data for Name: casbin_rule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.casbin_rule (id, ptype, v0, v1, v2, v3, v4, v5) FROM stdin;
1	p	6d9325c3-ea8c-47c1-ba2b-285d1f7667bb	*	*	\N	\N	\N
\.


--
-- Data for Name: clubs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clubs (id, club_name, status, "timestamp") FROM stdin;
\.


--
-- Data for Name: company; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company (id, site_name, support_email, support_phone, maintenance_mode, maximum_login_attempt, password_expiry, lockout_duration, require_two_factor_authentication, ip_list, created_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.configs (id, name, value, created_at) FROM stdin;
d7fea6f5-cb66-46b0-8e3c-fe28fd55c545	point_multiplier	1	2025-08-29 21:02:46.345987
df5929af-0ef2-4531-8fd0-8ec6caaca5fb	referral_bonus	0	2025-08-29 21:02:46.348864
715e692a-9f3b-461f-945e-478c9e18947d	plinko_max_bet	100	2025-08-29 21:02:46.350478
acd5aaa3-c4eb-47e1-ae51-848bb230b2ad	plinko_min_bet	0.10	2025-08-29 21:02:46.35146
04b162f9-04bf-47c5-8bfe-5f0091cb6197	plinko_rtp	97	2025-08-29 21:02:46.352324
5acd995c-7cb2-4119-8ebc-375b1fcfeef2	plinko_multipliers	{0.2,0.4,0.6,0.8,1,1.5,3,5,10,30}	2025-08-29 21:02:46.353033
afe9ecae-780f-43d1-aa74-d461ea8505e3	fb_match_multiplier	3	2025-08-29 21:02:46.353743
a73fc0b8-bf15-4330-85d0-f1fdd947e6b0	fb_match_price	3	2025-08-29 21:02:46.354208
2fae1d16-dc49-46df-b308-db14fbe177b3	signup_bonus	0	2025-08-29 21:02:46.361998
668a5764-37df-4e6d-871d-d680b707ed94	scratch_car	25000	2025-08-29 21:02:46.362464
98f1d552-e963-4b70-9e63-06b546571825	scratch_dollar	50000	2025-08-29 21:02:46.362918
83a427d5-1c86-4690-adf8-3bd7c4697075	scratch_crawn	10000	2025-08-29 21:02:46.363443
03e559b8-1697-4410-9cae-09434218925a	scratch_cent	1000	2025-08-29 21:02:46.364214
8d862306-4b4f-4d99-99ee-ea86eddd8377	scratch_diamond	2500	2025-08-29 21:02:46.364861
eaf3e1e7-d496-4ad7-815a-59e1d0dbd140	scratch_cup	5000	2025-08-29 21:02:46.365454
\.


--
-- Data for Name: crypto_kings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.crypto_kings (id, user_id, status, bet_amount, won_amount, start_crypto_value, end_crypto_value, selected_end_second, selected_start_value, selected_end_value, won_status, type, "timestamp") FROM stdin;
\.


--
-- Data for Name: crypto_wallet_auth_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.crypto_wallet_auth_logs (id, wallet_address, wallet_type, action, ip_address, user_agent, success, error_message, metadata, created_at) FROM stdin;
1094c0c0-37d0-471f-8929-802e1a1839d7	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	login	\N	\N	f	\N	{"error": "signature verification failed: invalid signature recovery id", "success": false, "timestamp": 1756850063, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-02 21:54:23.653579+00
ab924890-6564-4e01-b62a-9e7bac0b2d76	0x922d302ca89ed1a7b878f83aa0e9e7449a36d265	ethereum	login	\N	\N	f	\N	{"error": "signature verification failed: invalid signature recovery id", "success": false, "timestamp": 1756852239, "chain_type": "ethereum", "wallet_type": "walletconnect"}	2025-09-02 22:30:39.953395+00
cb447931-b139-4d94-81f6-5dd9b2405f64	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	login	\N	\N	f	\N	{"error": "signature verification failed: invalid signature recovery id", "success": false, "timestamp": 1756924078, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 18:27:58.359627+00
dce52647-ae4e-4198-b73d-7d9b9ab89d79	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	login	\N	\N	f	\N	{"error": "signature verification failed: invalid signature recovery id", "success": false, "timestamp": 1756924078, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 18:27:58.416433+00
d4776d50-c85e-4e77-be1c-177528adf44c	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	login	\N	\N	f	\N	{"error": "signature verification failed: invalid signature recovery id", "success": false, "timestamp": 1756924316, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 18:31:56.367234+00
6e29a105-e9b6-41b2-a6c1-71dbd6ecd068	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	login	\N	\N	f	\N	{"error": "signature verification failed: invalid signature recovery id", "success": false, "timestamp": 1756924316, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 18:31:56.440309+00
b62bb702-0975-46c4-9fab-f56274b5ca98	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	login	\N	\N	f	\N	{"error": "signature verification failed: invalid signature recovery id", "success": false, "timestamp": 1756932369, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 20:46:09.38883+00
86e83361-9c8a-42f3-b655-d4fe88143341	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	login	\N	\N	f	\N	{"error": "signature verification failed: invalid signature recovery id", "success": false, "timestamp": 1756932369, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 20:46:09.413594+00
a3cce10f-6521-4a56-b326-af978c8b84e2	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	login	\N	\N	f	\N	{"error": "signature verification error: signature does not match wallet address", "success": false, "timestamp": 1756933239, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 21:00:39.931292+00
0c46567c-d1ae-4199-8d29-ab7fa94f235e	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	login	\N	\N	f	\N	{"error": "signature verification error: signature does not match wallet address", "success": false, "timestamp": 1756933300, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 21:01:40.75942+00
4c6e1565-c26f-458e-a6a6-b79712bfe829	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	login	\N	\N	f	\N	{"error": "signature verification error: signature does not match wallet address", "success": false, "timestamp": 1756933492, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 21:04:52.436947+00
da2a4360-bdc4-469a-bd49-d8b7169bb4a0	0x742d35Cc6634C0532925a3b8D4C9db96C4b4d8b6	ethereum	login	\N	\N	f	\N	{"error": "signature verification error: signature does not match wallet address", "success": false, "timestamp": 1756934559, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 21:22:39.826189+00
7e1981cb-09a5-4e84-b0af-ee00293cd0d3	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	login	\N	\N	f	\N	{"error": "signature verification error: signature does not match wallet address", "success": false, "timestamp": 1756935357, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 21:35:57.417793+00
e79f4703-a02c-4278-9a17-8f555ba12938	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	login	\N	\N	f	\N	{"error": "signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756936483, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 21:54:43.094712+00
8c7534a5-6f30-46ed-a6a6-023713fb48bd	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756940453, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:00:53.183326+00
d82c0ce1-0038-4fff-9cb9-10de9b828250	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756940608, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:03:28.829674+00
0dd3bb08-ff9e-4197-851b-3dd1e55c2daf	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756940797, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:06:37.027376+00
d99be973-2ce3-4624-815e-b754241dab7d	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756940890, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:08:10.808191+00
8f8bd7af-e6fc-4d77-8c18-61f7e1a25a65	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756941096, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:11:36.430956+00
fe9a0642-f011-4c98-a424-0064deb6b84a	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756941452, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:17:32.58063+00
500f9e98-b8eb-43ed-b12c-37ac082f9723	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756941715, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:21:55.945228+00
0864bae2-b6c0-4e02-b90f-307ec92d33fd	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756941877, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:24:37.325532+00
c7e2fc43-101c-4a9d-b5fe-b1b059838538	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756941923, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:25:23.608508+00
47996b91-e36d-42a3-8aeb-cd225e0c1e6c	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756941962, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:26:02.119186+00
1fa8fa3d-77c5-409e-b4aa-eb90aea1e923	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756941965, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:26:05.607218+00
bc099728-7f7d-486b-8912-a2f5ad129088	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756941980, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:26:20.963225+00
17331d70-41a4-4708-85b8-469bffc20fb9	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756941984, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:26:24.464375+00
edb5748f-d0b5-4dab-b173-2de1c0be9943	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756942427, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:33:47.417162+00
4430cf67-4c4c-4ca7-8f17-d8a7b5eced73	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756942430, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:33:50.897591+00
f7aab812-860b-4dd9-b943-e8211a321775	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756942563, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:36:03.008769+00
7fc5a774-073c-47fb-9279-d95c06899e9b	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756942732, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:38:52.002202+00
c022196a-3c52-4519-9174-8344a1cf69cd	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756942749, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:39:09.660509+00
8de942f6-a703-45db-8b92-3a22677612f4	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756942989, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:43:09.893537+00
686061a5-5f70-4715-b397-ccf9c4795ea7	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756942995, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:43:15.610792+00
a0d9992d-d161-40a1-839d-501c5982a817	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756943134, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:45:34.507758+00
f223034f-9623-4a24-8066-ed7fd99b0eea	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756943278, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:47:58.472557+00
94ee90f1-a741-440a-84b4-c9819b8e097f	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	t	\N	{"success": true, "timestamp": 1756943278, "chain_type": "ethereum", "is_new_user": true, "wallet_type": "metamask"}	2025-09-03 23:47:58.48536+00
848a5e2e-9c54-4be7-ad99-e153a1ff9e00	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756943316, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:48:36.778785+00
eb1bb939-b4da-44c6-a983-70aab4e9cff6	0x1234567890abcdef1234567890abcdef12345678	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756943323, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:48:43.228821+00
704481ba-c726-43a2-a41a-90c772ed2cfd	0x1234567890abcdef1234567890abcdef12345678	ethereum	login	\N	\N	t	\N	{"success": true, "timestamp": 1756943323, "chain_type": "ethereum", "is_new_user": true, "wallet_type": "metamask"}	2025-09-03 23:48:43.23288+00
1b6fd731-3964-4f52-8f88-287f481af10c	0xabcdef1234567890abcdef1234567890abcdef12	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756943341, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:49:01.150293+00
3a1ed38b-3240-42a6-b431-c313d47dbe18	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756943424, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:50:24.691581+00
c205c2ae-2fa3-4718-b832-9c9d6cbc05e4	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756943428, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:50:28.395775+00
8f07724e-2180-4fdb-b991-a465c538f860	0x9999999999999999999999999999999999999999	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756943434, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:50:34.329051+00
a88b4092-6f37-4b70-80c3-84a9effe2302	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756943582, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:53:02.616649+00
642fd92f-a781-4352-9209-2cc48c07b8db	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756943586, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:53:06.723214+00
46fb3cc5-d19d-48b9-bc1c-a737a99d2b8b	0x7777777777777777777777777777777777777777	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756943594, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:53:14.304696+00
5629e6f4-b540-4ce5-a8ce-4232743548b9	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756943834, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:57:14.72104+00
1c14a47e-9ee9-47cb-b486-95cacb75d105	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756943840, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:57:20.463255+00
2aef68d4-415a-4061-8db2-6aac153b8952	0x1111111111111111111111111111111111111111	ethereum	login	\N	\N	f	\N	{"error": "wallet signature verification failed: signature verification error: failed to verify signature: address mismatch", "success": false, "timestamp": 1756943848, "chain_type": "ethereum", "wallet_type": "metamask"}	2025-09-03 23:57:28.259111+00
a380ca85-39fe-4c9b-b37b-3fc5ce81f16c	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	t	\N	{"success": true, "timestamp": 1756944048, "chain_type": "ethereum", "is_new_user": false, "wallet_type": "metamask"}	2025-09-04 00:00:48.71965+00
ecf7bbd2-4777-47fe-b9c7-8e0a8d988280	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	t	\N	{"success": true, "timestamp": 1756944166, "chain_type": "ethereum", "is_new_user": false, "wallet_type": "metamask"}	2025-09-04 00:02:46.904425+00
372bb33d-11b5-462b-afbb-91c00bec809e	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	t	\N	{"success": true, "timestamp": 1756945504, "chain_type": "ethereum", "is_new_user": false, "wallet_type": "metamask"}	2025-09-04 00:25:04.816301+00
096942b8-73b6-4003-add3-079e8fbdb7fd	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	t	\N	{"success": true, "timestamp": 1756997733, "chain_type": "ethereum", "is_new_user": false, "wallet_type": "metamask"}	2025-09-04 14:55:33.87542+00
2b4b7f78-adbb-4bb1-b83b-ccb4a2eee9cc	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	login	\N	\N	t	\N	{"success": true, "timestamp": 1756998514, "chain_type": "ethereum", "is_new_user": false, "wallet_type": "metamask"}	2025-09-04 15:08:34.042826+00
\.


--
-- Data for Name: crypto_wallet_challenges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.crypto_wallet_challenges (id, wallet_address, wallet_type, challenge_message, challenge_nonce, expires_at, is_used, created_at) FROM stdin;
18407dc1-7e62-40d5-adcb-07fe6e620cc2	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Sign this message to verify your wallet	52beab18-236a-426a-bec9-8787b94c45d2	2025-09-02 22:04:21.581639+00	f	2025-09-02 21:54:21.583599+00
533625f7-e1ad-467c-bd47-7f5b419f8aad	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Sign this message to verify your wallet	138a5610-7ed2-4e06-a46c-31b2e4c2b6a1	2025-09-02 22:20:31.748086+00	f	2025-09-02 22:10:31.749041+00
a0828896-ae5a-4b0e-be3d-ee404317d364	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Sign this message to verify your wallet	e4954c1f-e1be-4b73-8682-d896a394e19b	2025-09-02 22:27:15.080563+00	f	2025-09-02 22:17:15.082905+00
f2dcfcac-e80c-454f-823a-fd53f8a3365a	0x922d302ca89ed1a7b878f83aa0e9e7449a36d265	ethereum	Sign this message to verify your wallet	efd07c90-0368-4cb9-9c27-aed1bbe09148	2025-09-02 22:40:27.941359+00	f	2025-09-02 22:30:27.956077+00
b33d06f3-57a8-42ec-96f4-b87c41f25fb2	0x922d302ca89ed1a7b878f83aa0e9e7449a36d265	ethereum	Sign this message to verify your wallet	3ed6e801-e016-4e76-a271-585769873962	2025-09-02 22:41:14.249307+00	f	2025-09-02 22:31:14.249488+00
82b781c0-d80f-44fc-8b63-403266522031	0x922d302ca89ed1a7b878f83aa0e9e7449a36d265	ethereum	Sign this message to verify your wallet	17e828fa-eee8-466d-903a-ca9ad20c3416	2025-09-02 22:41:14.251532+00	f	2025-09-02 22:31:14.251766+00
74362f82-3bd7-483d-924b-cbc355274bd1	0x922d302ca89ed1a7b878f83aa0e9e7449a36d265	ethereum	Sign this message to verify your wallet	b2a2069e-b99e-4e27-81e1-916b546adcf5	2025-09-02 22:41:35.415297+00	f	2025-09-02 22:31:35.415411+00
01e4d23e-6d18-4d65-be10-3187d30b2876	0x922d302ca89ed1a7b878f83aa0e9e7449a36d265	ethereum	Sign this message to verify your wallet	c68cb460-a056-401a-922d-03e1dfa62c48	2025-09-02 22:41:35.41645+00	f	2025-09-02 22:31:35.416527+00
30b9297e-e3ed-4cd3-9719-143d65f308a6	0x922d302ca89ed1a7b878f83aa0e9e7449a36d265	ethereum	Sign this message to verify your wallet	0f2426bc-ada9-4119-a9c5-73c052a516dd	2025-09-02 22:45:35.542049+00	f	2025-09-02 22:35:35.543263+00
ab097305-a44d-42b7-bf30-71234d469534	0x922d302ca89ed1a7b878f83aa0e9e7449a36d265	ethereum	Sign this message to verify your wallet	aaf6af5c-53fb-4651-9400-f12c9d93663a	2025-09-02 22:45:50.331248+00	f	2025-09-02 22:35:50.331439+00
f2b686e8-3ec3-4c0f-b460-6944e69065f5	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Sign this message to verify your wallet	6450e083-22a8-4241-ad48-e761e4f6bde1	2025-09-03 18:37:48.719763+00	f	2025-09-03 18:27:48.72275+00
13c5b48a-9050-4950-b101-dcabb2950ee8	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Sign this message to verify your wallet	a38a4d34-5068-4bef-a636-d4ca203f9b88	2025-09-03 18:41:44.95642+00	f	2025-09-03 18:31:44.958448+00
6719b067-85db-4129-aba6-29703f775aa1	test	ethereum	Sign this message to verify your wallet	ae57653c-811f-4481-9068-fcc62462c270	2025-09-03 18:49:15.258905+00	f	2025-09-03 18:39:15.259159+00
90ec8da1-f36b-4e0d-b452-78b801556785	test	ethereum	Sign this message to verify your wallet	d3ed5306-21c1-4c30-830f-3c082e983aaa	2025-09-03 18:50:05.577017+00	f	2025-09-03 18:40:05.577474+00
cf7e07ef-8ffe-4700-a559-9b6a1597208e	test	ethereum	Sign this message to verify your wallet	07c47096-354b-4387-87b8-3aa17ba7befa	2025-09-03 18:50:14.100032+00	f	2025-09-03 18:40:14.100529+00
d23a43bf-7a46-49b8-b2d3-fa0984df041c	test	ethereum	Sign this message to verify your wallet	4dc76581-7b09-4194-9704-aeb01f961921	2025-09-03 18:50:15.823844+00	f	2025-09-03 18:40:15.824095+00
8977dedc-ced9-4247-b533-a2296be8271f	test	ethereum	Sign this message to verify your wallet	ddf4423d-ca92-4669-8447-cea6435afa92	2025-09-03 18:50:58.533619+00	f	2025-09-03 18:40:58.533933+00
f98d8bd5-b886-4aec-a322-11fc9d0ad977	test	ethereum	Sign this message to verify your wallet	83aa05d9-f125-4ebd-b7c7-e204db56f811	2025-09-03 18:50:58.592611+00	f	2025-09-03 18:40:58.592913+00
c5996027-638b-45f3-805e-266156278f03	test	ethereum	Sign this message to verify your wallet	f7fbc36e-371f-4d20-b322-b4e2c38ad065	2025-09-03 20:45:07.593281+00	f	2025-09-03 20:35:07.5939+00
7769b881-6e5f-49d0-8bb9-37bfa74a752a	test	ethereum	Sign this message to verify your wallet	56ef766c-fc5f-4127-b739-2c8f4a905e05	2025-09-03 20:45:07.595096+00	f	2025-09-03 20:35:07.595939+00
c7e7f3ce-b983-43e2-a9ac-ee96a645ecee	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Sign this message to verify your wallet	d5aaea58-bc8a-47f9-98ca-c73d44aacaaa	2025-09-03 20:45:29.766697+00	f	2025-09-03 20:35:29.767073+00
c16a638d-b070-4963-b19e-6efa891c4ccb	test	ethereum	Sign this message to verify your wallet	4dba1640-0da4-490f-9ea5-e16398b9e3ee	2025-09-03 20:48:55.3315+00	f	2025-09-03 20:38:55.331737+00
26d73431-7c97-4aa8-84a0-9a0eb61fa3a5	test	ethereum	Sign this message to verify your wallet	23d1934b-0436-409d-9ad3-9bb4537c3770	2025-09-03 20:48:55.339388+00	f	2025-09-03 20:38:55.339737+00
00275f04-3d56-4f6b-b9ae-08a063c83f91	test	ethereum	Sign this message to verify your wallet	7d9cd145-5995-4532-8d02-1abad73aaf27	2025-09-03 20:48:55.349467+00	f	2025-09-03 20:38:55.349804+00
412b4400-755d-48c3-8bf7-960199f6c3c2	test	ethereum	Sign this message to verify your wallet	8b21c955-11e6-46b9-b305-7594b360f755	2025-09-03 20:50:51.568204+00	f	2025-09-03 20:40:51.568481+00
b92948d3-0ef0-4efc-bc0c-1dce67e12895	test	ethereum	Sign this message to verify your wallet	b68df109-c730-42cf-843b-ddf89db8bfdf	2025-09-03 20:51:56.162262+00	f	2025-09-03 20:41:56.162576+00
065ee9fb-fd4d-436f-972b-7d9bece48174	test	ethereum	Sign this message to verify your wallet	081dc0bb-17a9-4a88-bcca-d46ff204d400	2025-09-03 20:51:56.169552+00	f	2025-09-03 20:41:56.169765+00
508826c0-bc47-4c14-9736-932ac95165cf	test	ethereum	Sign this message to verify your wallet	feaad62c-bfa1-4de7-9ccc-47b53f7d96f7	2025-09-03 20:51:56.207916+00	f	2025-09-03 20:41:56.208055+00
fee3ed0d-9b41-493e-b07e-26094757fedd	test	ethereum	Sign this message to verify your wallet	445a6751-a5a5-4986-b454-417aec729e1e	2025-09-03 20:52:22.07284+00	f	2025-09-03 20:42:22.072987+00
529ffe04-5528-4e33-8eec-576119572e2e	test	ethereum	Sign this message to verify your wallet	8fc40584-89c7-4b3d-86ed-938f62e8908a	2025-09-03 20:52:29.754845+00	f	2025-09-03 20:42:29.754981+00
b85a5fe1-9ca3-42a9-ad7c-280508376908	test	ethereum	Sign this message to verify your wallet	b825f6af-2a80-4256-b9ac-d2843ca638df	2025-09-03 20:52:37.656967+00	f	2025-09-03 20:42:37.657114+00
4796d7ff-49c6-4bd6-9194-25d2deda0888	test	ethereum	Sign this message to verify your wallet	d7231e3d-25f9-4049-b267-d356bd3a495b	2025-09-03 20:52:49.294377+00	f	2025-09-03 20:42:49.294543+00
30bf3db9-f984-4f19-bde6-6079161e28c9	test	ethereum	Sign this message to verify your wallet	636f2b51-29ad-4cee-9797-8b323629d7fe	2025-09-03 20:52:56.602193+00	f	2025-09-03 20:42:56.602349+00
d1443ffe-d952-4391-91e7-8731a1e7b61d	test	ethereum	Sign this message to verify your wallet	8e66771c-ee46-45c5-8e6f-333947e448f6	2025-09-03 20:53:08.704942+00	f	2025-09-03 20:43:08.705277+00
e166a0dd-f947-49a2-9f42-167d14c7a2e9	test	ethereum	Sign this message to verify your wallet	5162883c-0b01-421a-85b1-1f44a4aed9e6	2025-09-03 20:53:25.609922+00	f	2025-09-03 20:43:25.610071+00
3f2f527f-31e0-4a3d-930b-ac6f88024336	test	ethereum	Sign this message to verify your wallet	1246b5b6-a237-49df-914d-fa8f8a7c8ee3	2025-09-03 20:53:25.612047+00	f	2025-09-03 20:43:25.612302+00
a3be2935-5562-44ad-a72a-fe368bdaded3	test	ethereum	Sign this message to verify your wallet	ee8384f3-9f3e-4a9d-9243-27d383dec295	2025-09-03 20:53:25.625176+00	f	2025-09-03 20:43:25.625322+00
5f8ba272-0190-4a6f-af9c-8d2f60710186	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Sign this message to verify your wallet	0fa23496-0936-4327-b61c-d6a1a94d752e	2025-09-03 20:56:02.880273+00	f	2025-09-03 20:46:02.880702+00
7c065cce-f79d-443b-822b-3b1e175d7aa1	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Sign this message to verify your wallet	08d02e97-4f16-4b2a-97f0-d24a7d5e62a5	2025-09-03 20:58:13.052223+00	f	2025-09-03 20:48:13.052495+00
98c25603-b5c1-4e32-9780-06b78aea2780	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Sign this message to verify your wallet	21d2f349-7744-423e-bc04-eb6e796f09c0	2025-09-03 21:09:32.907473+00	t	2025-09-03 20:59:32.907942+00
96331206-11bb-46ce-a5a0-e3766a51f5c1	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Sign this message to verify your wallet	c9c3feaf-2f47-43ac-a379-1dee8ccbaefe	2025-09-03 21:10:35.17624+00	f	2025-09-03 21:00:35.176747+00
8215599e-a5dc-44be-9f6e-965fe35a8508	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Sign this message to verify your wallet	da68e832-cd66-439c-8530-1201e73df326	2025-09-03 21:11:35.94293+00	f	2025-09-03 21:01:35.943031+00
1b0c4b4e-6d6f-4414-b3e5-9be4201cd227	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Sign this message to verify your wallet	be159ede-907d-40e7-a169-408344aa9bbf	2025-09-03 21:16:56.035559+00	f	2025-09-03 21:06:56.03566+00
c221e6bc-a2a4-4401-958c-b06cda37eb34	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Sign this message to verify your wallet	462ff24b-f58d-4be1-b732-c53cde9b9047	2025-09-03 21:25:09.566517+00	f	2025-09-03 21:15:09.566642+00
1155de57-00ea-4f3b-8c36-bdb2ef370271	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Sign this message to verify your wallet	cea88975-4ff9-4b8b-9d0c-378204ffa014	2025-09-03 21:19:48.208818+00	t	2025-09-03 21:09:48.208985+00
bac034c8-74b8-481e-99a4-755846fe1757	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Sign this message to verify your wallet	63612877-af2f-4207-95af-d0cc1f361cd8	2025-09-03 21:25:16.478893+00	f	2025-09-03 21:15:16.479093+00
5e214911-4cff-4dff-a0ff-f2fc3c5ecc06	0x8a562976BF89101399F996D529bD1B00f3Bdf239	ethereum	Sign this message to verify your wallet	efa11471-b2d7-4a02-8502-f21f4d0b5b0c	2025-09-03 21:25:39.745462+00	f	2025-09-03 21:15:39.74558+00
f157fb45-0025-414f-ab3e-72ea48a818d8	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Sign this message to verify your wallet	7ee36ae2-25a3-4881-8682-f0209233818b	2025-09-03 21:26:34.040876+00	f	2025-09-03 21:16:34.041299+00
f4818e1a-0a76-49c0-bf19-2b1cde32bbf7	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Sign this message to verify your wallet	53423832-e0e0-41a2-a9d0-0d26588dc162	2025-09-03 21:26:44.920372+00	f	2025-09-03 21:16:44.920535+00
b48e28c1-fa69-45e0-9f32-f26e7f671e75	0x1D5386D92037752eA7f761987CdDc8681fc9b00e	ethereum	Sign this message to verify your wallet	eda96ee8-97cc-476e-bf04-826fc5417c54	2025-09-03 21:26:48.703144+00	f	2025-09-03 21:16:48.703281+00
2f32c4ad-7e09-4402-bd78-4a1a44c29521	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: d2096559-3007-46b8-affc-b29126ea49a0	d2096559-3007-46b8-affc-b29126ea49a0	2025-09-03 21:27:00.692925+00	f	2025-09-03 21:17:00.69358+00
989a4b52-9d32-485c-88af-3715fc6ebaae	0x742d35Cc6634C0532925a3b8D4C9db96C4b4d8b6	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: b68271e7-60ab-438b-b8b1-9f705a2a2863	b68271e7-60ab-438b-b8b1-9f705a2a2863	2025-09-03 21:29:06.879227+00	f	2025-09-03 21:19:06.881707+00
54b1dc85-955d-4c41-bb60-dd097819b0ab	0xa5f8920aF4051E354b501CDC8d62Dd843487df7d	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 9668d3f3-e6d7-4843-8f27-21993a2b78f4	9668d3f3-e6d7-4843-8f27-21993a2b78f4	2025-09-03 21:29:22.254777+00	t	2025-09-03 21:19:22.254882+00
bfd34bd6-93c6-4492-9c5b-bc5b468c41ac	0x742d35Cc6634C0532925a3b8D4C9db96C4b4d8b6	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: a344a81b-1f35-4438-9fda-141ddcd44acc	a344a81b-1f35-4438-9fda-141ddcd44acc	2025-09-03 21:31:43.281129+00	f	2025-09-03 21:21:43.281518+00
cff6e512-ff20-4383-b553-5b88dd330e9d	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 28c93dbc-6d6d-4998-85be-00f1f4ff2c9f	28c93dbc-6d6d-4998-85be-00f1f4ff2c9f	2025-09-03 21:34:43.807524+00	t	2025-09-03 21:24:43.807661+00
cab5a4bc-e6aa-40eb-a7ac-391d111317f9	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 55310f83-65b8-4f2b-a23b-96f3c9a31628	55310f83-65b8-4f2b-a23b-96f3c9a31628	2025-09-03 21:35:35.728994+00	f	2025-09-03 21:25:35.729138+00
5785103b-f361-4b36-a696-cf3ed8e1b348	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: fb5c7aad-2f4e-47eb-88e4-ee5a273db245	fb5c7aad-2f4e-47eb-88e4-ee5a273db245	2025-09-03 21:35:59.80902+00	f	2025-09-03 21:25:59.809216+00
530367e5-0ca3-4b14-a939-cb84a2bb6b29	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 08201dd1-1f44-46e4-b63c-0a310f320c54	08201dd1-1f44-46e4-b63c-0a310f320c54	2025-09-03 21:37:42.709964+00	f	2025-09-03 21:27:42.71011+00
2a9e009d-2a33-4bfe-bf41-de2be8d4dab4	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: fb357fa2-b916-4cda-8bbc-0adf85dd8ab5	fb357fa2-b916-4cda-8bbc-0adf85dd8ab5	2025-09-03 21:38:28.853543+00	t	2025-09-03 21:28:28.853761+00
dff01e5f-442e-4ac9-bcbf-92a255dcdae4	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: d51f4072-0ccd-47d0-a3b3-1617472b439c	d51f4072-0ccd-47d0-a3b3-1617472b439c	2025-09-03 21:41:16.475714+00	f	2025-09-03 21:31:16.475832+00
0e1deb65-f33e-4cd0-8e79-c0fdaa401a69	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 73b8a686-5234-498f-b08e-b065a0cc28d9	73b8a686-5234-498f-b08e-b065a0cc28d9	2025-09-03 21:39:16.212173+00	t	2025-09-03 21:29:16.212315+00
86cc89ed-a6f8-4014-8805-334d7cc491dc	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 2abd0094-63de-42ea-801b-8c4401940ca4	2abd0094-63de-42ea-801b-8c4401940ca4	2025-09-03 21:41:55.122579+00	t	2025-09-03 21:31:55.122701+00
1875e9b4-dc88-4e97-9cf9-522eeb07f047	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 8d209ef0-ee44-4414-b2b9-968ede08be67	8d209ef0-ee44-4414-b2b9-968ede08be67	2025-09-03 21:44:57.051158+00	f	2025-09-03 21:34:57.051331+00
60d4161b-80a7-49d2-9c4c-c2f57b5e6af4	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: be2d9dc8-36fe-445e-95d9-ce7bd03b2ae9	be2d9dc8-36fe-445e-95d9-ce7bd03b2ae9	2025-09-03 21:42:28.673504+00	t	2025-09-03 21:32:28.673612+00
802af2a2-8e96-4a52-9fb4-6894d9bf84d4	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 4c3e9ac0-1792-4891-8843-4cef455df1a4	4c3e9ac0-1792-4891-8843-4cef455df1a4	2025-09-03 21:47:11.695281+00	t	2025-09-03 21:37:11.695395+00
bd6a7ec3-9302-45ea-a983-bd999792a5c8	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 15e29aab-c8a2-44df-ad23-517e6c0aeb28	15e29aab-c8a2-44df-ad23-517e6c0aeb28	2025-09-03 22:02:21.729647+00	t	2025-09-03 21:52:21.730798+00
d211b888-815e-465a-8cf1-b083c03831fd	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 35c2850a-9a11-444d-b1c6-f6bd1ded6b98	35c2850a-9a11-444d-b1c6-f6bd1ded6b98	2025-09-03 22:03:47.812765+00	f	2025-09-03 21:53:47.812902+00
01650b58-2da2-45d6-ab78-3578b89c3c1b	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 6a163051-aa00-4862-874c-ff4634b6f84b	6a163051-aa00-4862-874c-ff4634b6f84b	2025-09-03 22:05:54.623522+00	t	2025-09-03 21:55:54.624821+00
eaa093f3-4af4-44c2-91fb-172f08c9330a	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 473a252b-fb8e-44b7-af0a-a201a50f939c	473a252b-fb8e-44b7-af0a-a201a50f939c	2025-09-03 22:09:25.708545+00	f	2025-09-03 21:59:25.708784+00
46addc29-3fb0-4aac-a949-31ccbb19e4a5	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 9ff83197-6a66-4927-a32f-50ee0be5479c	9ff83197-6a66-4927-a32f-50ee0be5479c	2025-09-03 22:10:02.775782+00	t	2025-09-03 22:00:02.776959+00
f4344019-3a37-43e4-aa44-b4e2d524cdc7	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 5d3e1a4a-f77f-4710-8f82-508234269b2c	5d3e1a4a-f77f-4710-8f82-508234269b2c	2025-09-03 22:38:42.383569+00	t	2025-09-03 22:28:42.384947+00
e8cd01cc-4f65-4c14-8fa9-8ac7fe75b82b	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 21f4bbf4-87bc-4ad1-a5e6-5c5c7dcfbb68	21f4bbf4-87bc-4ad1-a5e6-5c5c7dcfbb68	2025-09-03 22:39:40.358967+00	f	2025-09-03 22:29:40.360227+00
d6f50428-d3d9-404c-8685-811ebd04c12f	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 9aa132be-4688-451a-ba9c-8e70e4886dc7	9aa132be-4688-451a-ba9c-8e70e4886dc7	2025-09-03 22:40:49.660719+00	f	2025-09-03 22:30:49.66137+00
96c1738f-402c-466b-ac19-ce12af79d502	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: a7ae335e-fb50-4401-9937-a700da616912	a7ae335e-fb50-4401-9937-a700da616912	2025-09-03 22:53:35.695073+00	t	2025-09-03 22:43:35.695214+00
aef1e2d2-6e96-48b5-991d-6272002ed651	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: ebbb3a3d-7d38-44fe-baf4-e6e01d47d2f9	ebbb3a3d-7d38-44fe-baf4-e6e01d47d2f9	2025-09-03 22:58:49.018904+00	t	2025-09-03 22:48:49.019056+00
c6c72a58-4d29-48ca-a8fa-aedb8d7197c8	0x6d79dc497a41b244d67cbe444b9767c63ecc8e24	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 63a17243-826d-4be5-ab7c-fc4a90693356	63a17243-826d-4be5-ab7c-fc4a90693356	2025-09-03 22:46:14.84747+00	f	2025-09-03 22:36:14.847667+00
74af4d60-2a17-45c4-8285-29c7d3e4daa4	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: f2e91665-40d6-4396-89a1-99e0d4e4394e	f2e91665-40d6-4396-89a1-99e0d4e4394e	2025-09-03 22:49:41.419397+00	t	2025-09-03 22:39:41.419671+00
abe68ae4-336c-4bc8-bbba-e02d917dadd4	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 3b4a47c3-0195-414d-89f4-573de264282e	3b4a47c3-0195-414d-89f4-573de264282e	2025-09-03 22:57:52.861417+00	f	2025-09-03 22:47:52.861597+00
2470ba95-8258-4b59-9956-f9ef0387bab3	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 7d999511-8ba0-4194-bbea-cc3b33e2d7bc	7d999511-8ba0-4194-bbea-cc3b33e2d7bc	2025-09-03 22:59:51.542369+00	f	2025-09-03 22:49:51.543719+00
123ba227-16cb-4d10-845a-e8d3eb916ecf	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 0be98beb-7669-4ecb-bae5-cd9538ddb467	0be98beb-7669-4ecb-bae5-cd9538ddb467	2025-09-03 23:01:14.806982+00	t	2025-09-03 22:51:14.807645+00
6cb1a9c4-a2e0-4660-b551-b7daf75b7c64	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 6ffa047a-ac35-4cb4-be26-db013fb6b9bc	6ffa047a-ac35-4cb4-be26-db013fb6b9bc	2025-09-03 23:06:01.484046+00	f	2025-09-03 22:56:01.484587+00
b4d03e61-f279-4913-b033-bdaceb1bbbca	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: b006aead-9a6d-47b3-9619-e3f93504c96d	b006aead-9a6d-47b3-9619-e3f93504c96d	2025-09-03 23:07:22.101579+00	t	2025-09-03 22:57:22.101794+00
7f19395c-533a-44f2-b780-4cbd8c6a133e	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 18090dc0-3732-42a5-b4ed-6b1ff3e75b6e	18090dc0-3732-42a5-b4ed-6b1ff3e75b6e	2025-09-03 23:08:44.69964+00	f	2025-09-03 22:58:44.699768+00
a48b50ef-5d39-444b-b814-28227aa17a6a	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: e9336b3a-beeb-408b-8f44-b5eef757bae3	e9336b3a-beeb-408b-8f44-b5eef757bae3	2025-09-03 23:08:47.772+00	f	2025-09-03 22:58:47.772219+00
4f9f59dd-dd64-402e-8f39-3922e232ec8f	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 4ebf0d85-8e3b-4409-bf32-34ba2f104fab	4ebf0d85-8e3b-4409-bf32-34ba2f104fab	2025-09-03 23:10:47.479605+00	f	2025-09-03 23:00:47.479808+00
9c4ac2ad-84b6-414d-9015-63b08b953937	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 104cad8f-1f6c-4793-a9d7-5aa0348bf5d2	104cad8f-1f6c-4793-a9d7-5aa0348bf5d2	2025-09-03 23:11:47.57357+00	t	2025-09-03 23:01:47.573854+00
41390d8d-ece8-43e4-8ad3-6ecebd5148a1	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: a034031d-bd5d-4fb0-8bf0-7bc4b84f1654	a034031d-bd5d-4fb0-8bf0-7bc4b84f1654	2025-09-03 23:15:21.479497+00	t	2025-09-03 23:05:21.479797+00
467023ae-9075-4e80-bdde-ff414eb4c8a7	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 238da3a1-b3b1-4fbf-9e9f-847378c1a5f6	238da3a1-b3b1-4fbf-9e9f-847378c1a5f6	2025-09-03 23:16:32.41751+00	f	2025-09-03 23:06:32.418367+00
a41a434c-13fc-4b37-b705-a901110ca609	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 33be9b7a-ded1-4140-8b2a-12968361af34	33be9b7a-ded1-4140-8b2a-12968361af34	2025-09-03 23:17:13.129658+00	t	2025-09-03 23:07:13.130369+00
04ad2a4f-db2c-415e-b457-27ebffaf6d7f	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: bfe13b8b-4a3f-4454-9483-85ec91b9ac62	bfe13b8b-4a3f-4454-9483-85ec91b9ac62	2025-09-03 23:18:07.84939+00	f	2025-09-03 23:08:07.849672+00
b2c68def-d9f4-402c-b0c4-f7054cf4ad09	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: a49f7fb1-ade9-48f1-ae49-96c5976c048f	a49f7fb1-ade9-48f1-ae49-96c5976c048f	2025-09-03 23:19:48.734886+00	t	2025-09-03 23:09:48.735122+00
28c032e9-210f-422c-bf60-0a7ba61ad318	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 6ce993c3-ab1d-466c-aa71-32a9d5259e69	6ce993c3-ab1d-466c-aa71-32a9d5259e69	2025-09-03 23:21:28.909383+00	f	2025-09-03 23:11:28.910292+00
c6c9714e-9273-4025-b71e-3efbc3a8b733	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 8cc91d44-3c17-4202-b74f-74e3e9d0b632	8cc91d44-3c17-4202-b74f-74e3e9d0b632	2025-09-03 23:25:31.926538+00	f	2025-09-03 23:15:31.926688+00
f633e9f3-f287-4bce-b972-07f2ff551066	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 90bb6d5c-10a7-4c78-927b-35dee814a7d3	90bb6d5c-10a7-4c78-927b-35dee814a7d3	2025-09-03 23:26:18.027483+00	t	2025-09-03 23:16:18.027696+00
358cc98c-eb6c-4f42-bda0-3822577a644a	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 50e89fcd-2949-47af-a1f9-efbd6626ece6	50e89fcd-2949-47af-a1f9-efbd6626ece6	2025-09-03 23:27:27.598903+00	f	2025-09-03 23:17:27.601675+00
8847f9e5-5413-4afb-8236-3b0443cbabdc	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 7af8af9c-4df3-462f-a351-227e248ddad7	7af8af9c-4df3-462f-a351-227e248ddad7	2025-09-03 23:31:51.956748+00	f	2025-09-03 23:21:51.957695+00
92eac01d-4b99-4fda-a864-7792d9c2a124	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 4d6eaca9-e1ac-4e13-9e38-fdc6e9354f97	4d6eaca9-e1ac-4e13-9e38-fdc6e9354f97	2025-09-03 23:32:28.204585+00	t	2025-09-03 23:22:28.204827+00
945c8fee-c543-4263-ae27-190b016a5dd3	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 5ac5833c-fee8-46ad-ae7e-37a0c78605c7	5ac5833c-fee8-46ad-ae7e-37a0c78605c7	2025-09-03 23:34:33.518441+00	f	2025-09-03 23:24:33.51888+00
03f8952c-2290-467a-ab78-c3e68c13c449	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 51483c61-43f9-4ce5-9f84-64673c751cab	51483c61-43f9-4ce5-9f84-64673c751cab	2025-09-03 23:35:20.460457+00	f	2025-09-03 23:25:20.460751+00
653f2eea-d922-4030-a13a-0066b46550f9	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: f842d285-3905-4563-b3e6-6d3b8983f688	f842d285-3905-4563-b3e6-6d3b8983f688	2025-09-03 23:35:58.982991+00	f	2025-09-03 23:25:58.984256+00
f11e3c7f-495f-49b9-9e78-6a02b78a9965	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: d256aabb-2fd0-4c0b-be5d-642ef0b73a19	d256aabb-2fd0-4c0b-be5d-642ef0b73a19	2025-09-03 23:36:17.912499+00	f	2025-09-03 23:26:17.913671+00
22143628-0dee-4c89-9cb0-0e60abb58e91	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: ac966abd-f40a-46ba-9b4d-de4dcc4a00f4	ac966abd-f40a-46ba-9b4d-de4dcc4a00f4	2025-09-03 23:38:27.484783+00	t	2025-09-03 23:28:27.485049+00
24b35bc5-ba10-4682-a232-1162a8b7d72f	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 75331ba3-09b6-4966-9099-3268d40b74c4	75331ba3-09b6-4966-9099-3268d40b74c4	2025-09-03 23:43:43.049004+00	f	2025-09-03 23:33:43.04944+00
3e3a931e-ea4e-4849-8345-34e18273690e	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 438ae0c7-091d-41d4-a1fc-6e211f2b3d16	438ae0c7-091d-41d4-a1fc-6e211f2b3d16	2025-09-03 23:45:15.054426+00	t	2025-09-03 23:35:15.054593+00
fbb63b8d-5642-4ff4-8b10-b064399d652c	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: c3807023-ee77-4816-9821-3f33073504ed	c3807023-ee77-4816-9821-3f33073504ed	2025-09-03 23:46:01.067937+00	f	2025-09-03 23:36:01.068846+00
e1acd33a-fc16-4880-acd0-ef82014c8dcf	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 06e7f738-7c0c-4b90-9a74-edc5de434071	06e7f738-7c0c-4b90-9a74-edc5de434071	2025-09-03 23:47:02.28341+00	t	2025-09-03 23:37:02.284064+00
9468ce14-ffaa-4706-a972-69b51f9107a3	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: ef81ffda-8062-4f93-a065-2db234b30969	ef81ffda-8062-4f93-a065-2db234b30969	2025-09-03 23:48:49.432402+00	f	2025-09-03 23:38:49.432603+00
1fa0444e-fb22-418b-b2d4-ae17036331e9	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 868b1d58-a9b9-49af-aae7-18514cdc570c	868b1d58-a9b9-49af-aae7-18514cdc570c	2025-09-03 23:49:04.39027+00	f	2025-09-03 23:39:04.391001+00
dee1177c-1f50-442a-ad86-d68a43d07a08	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 3c5472ab-3196-4c26-8280-ff16b68188d8	3c5472ab-3196-4c26-8280-ff16b68188d8	2025-09-03 23:49:52.256438+00	t	2025-09-03 23:39:52.256802+00
f9a13c5b-f53b-485d-839b-2b4d0a23d22f	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 0b291ec2-ac5c-4ede-8a12-84174c280650	0b291ec2-ac5c-4ede-8a12-84174c280650	2025-09-03 23:53:06.681197+00	f	2025-09-03 23:43:06.682652+00
cabc6697-5acf-41ff-ad41-36fc9180db2d	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 122e0532-50bb-4176-bcbe-0b1f7682fc89	122e0532-50bb-4176-bcbe-0b1f7682fc89	2025-09-03 23:55:29.454277+00	t	2025-09-03 23:45:29.455514+00
eb26b17f-e163-47b1-b95e-18e13f488be5	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 12c8a28e-cfe4-4994-8ed0-88e9ad155eef	12c8a28e-cfe4-4994-8ed0-88e9ad155eef	2025-09-03 23:57:55.724314+00	t	2025-09-03 23:47:55.725405+00
faf4a61a-9e74-43d4-a35a-72b3a7c4c5c4	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 436a5335-73d1-4109-a5dd-169368a88de3	436a5335-73d1-4109-a5dd-169368a88de3	2025-09-03 23:58:33.596606+00	t	2025-09-03 23:48:33.596841+00
6432eadd-7bfe-4107-9998-205e70577481	0x1234567890abcdef1234567890abcdef12345678	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 3129bca9-a71c-4708-9d98-47c2af66f36b	3129bca9-a71c-4708-9d98-47c2af66f36b	2025-09-03 23:58:40.026948+00	t	2025-09-03 23:48:40.027177+00
d764136d-35f4-4cd5-a544-b358b15137d7	0xabcdef1234567890abcdef1234567890abcdef12	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 6da97f01-1e3b-49ed-acc9-70f8b65b0696	6da97f01-1e3b-49ed-acc9-70f8b65b0696	2025-09-03 23:58:57.56578+00	f	2025-09-03 23:48:57.566682+00
8216e3de-1dac-45c6-a00e-7f64ffb333df	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 9709121f-3656-4a0f-81aa-6bf44eb91b4e	9709121f-3656-4a0f-81aa-6bf44eb91b4e	2025-09-03 23:59:26.284894+00	t	2025-09-03 23:49:26.285087+00
c7f0c2ee-ff20-47c1-b52c-9fbf3af339a6	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 06fed8ee-285c-42c8-95ed-0851fa15c570	06fed8ee-285c-42c8-95ed-0851fa15c570	2025-09-04 00:00:19.892424+00	f	2025-09-03 23:50:19.892655+00
ed6591b4-5b46-42d0-952e-423d7c8f1847	0x9999999999999999999999999999999999999999	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: cfe96729-577d-4791-b7d2-b0d3868d32eb	cfe96729-577d-4791-b7d2-b0d3868d32eb	2025-09-04 00:00:31.20675+00	f	2025-09-03 23:50:31.20688+00
0f2e8889-a675-4798-848f-d468fb47d973	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 95284b7f-405f-4eb7-9ae7-baac24a7b387	95284b7f-405f-4eb7-9ae7-baac24a7b387	2025-09-04 00:01:09.543751+00	t	2025-09-03 23:51:09.544598+00
2abb7ad2-c31b-4b73-a65a-cbc6fced4db1	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 8bb0af0d-53bf-4a2c-9762-26fa954dd920	8bb0af0d-53bf-4a2c-9762-26fa954dd920	2025-09-04 00:02:55.670994+00	f	2025-09-03 23:52:55.671418+00
639c42ea-f66e-4a90-aa1a-dee1ebf412fd	0x7777777777777777777777777777777777777777	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: cee36302-5e4f-4d28-8b94-1ded6a98eae6	cee36302-5e4f-4d28-8b94-1ded6a98eae6	2025-09-04 00:03:10.160583+00	f	2025-09-03 23:53:10.160751+00
7687f89e-3a3f-4ffb-a910-a132671c49b9	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 34d84a13-94a8-474b-83c5-5c42a301d7b8	34d84a13-94a8-474b-83c5-5c42a301d7b8	2025-09-04 00:03:35.100609+00	t	2025-09-03 23:53:35.100768+00
23d6ab20-452c-4745-8970-da97799ae1eb	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: aa814569-62be-4105-b40e-f1bae40278b5	aa814569-62be-4105-b40e-f1bae40278b5	2025-09-04 00:07:09.916016+00	f	2025-09-03 23:57:09.916293+00
da490469-d195-4710-a62b-f84917e53c13	0x1111111111111111111111111111111111111111	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 07e91857-bf36-4616-959c-d4c919e9ff92	07e91857-bf36-4616-959c-d4c919e9ff92	2025-09-04 00:07:24.323998+00	f	2025-09-03 23:57:24.324134+00
1f4111ab-2d26-4608-92f7-321fbb273daa	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 58f161c0-c81e-4205-a62e-c2c9c19ca409	58f161c0-c81e-4205-a62e-c2c9c19ca409	2025-09-04 00:08:52.054396+00	t	2025-09-03 23:58:52.055197+00
ee28484e-1960-41b6-95ff-2512ee026794	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: d7385fed-6c28-4e51-b270-95bbd4e547db	d7385fed-6c28-4e51-b270-95bbd4e547db	2025-09-04 00:10:42.715278+00	t	2025-09-04 00:00:42.716162+00
e2f958dd-f9f4-407d-8221-38374c351c4f	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 68a5c5c1-c790-4496-9b35-6c28c06d8280	68a5c5c1-c790-4496-9b35-6c28c06d8280	2025-09-04 00:12:42.693438+00	t	2025-09-04 00:02:42.694363+00
bedc4a22-b9c8-468c-8c36-0323bfb7bc0b	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 2bdb5cdb-9981-4d9f-8d3b-6205536874ff	2bdb5cdb-9981-4d9f-8d3b-6205536874ff	2025-09-04 00:35:00.244089+00	t	2025-09-04 00:25:00.244212+00
c71918ae-8d73-4edd-a598-2651c357cfff	0x922d302ca89ed1a7b878f83aa0e9e7449a36d265	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: e5e7127c-553c-4847-af7d-b8a4a44df3ce	e5e7127c-553c-4847-af7d-b8a4a44df3ce	2025-09-04 00:37:15.925301+00	f	2025-09-04 00:27:15.925515+00
488bf4fe-261f-43fe-975c-5bd8543e9860	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: b8ebef7c-083a-4f58-9e94-465955c03503	b8ebef7c-083a-4f58-9e94-465955c03503	2025-09-04 00:38:23.661064+00	f	2025-09-04 00:28:23.661252+00
8a9feaf0-a94f-49cd-b35a-3f94c3373730	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 728ed5dd-37f1-483e-b44a-e5c5aa04a092	728ed5dd-37f1-483e-b44a-e5c5aa04a092	2025-09-04 15:02:29.388938+00	f	2025-09-04 14:52:29.392469+00
84421223-5356-498c-8780-a250cec47ab5	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: 39700db3-06a6-4292-a016-781c29474432	39700db3-06a6-4292-a016-781c29474432	2025-09-04 15:05:29.288537+00	t	2025-09-04 14:55:29.288815+00
d45dcb76-75ab-444e-924f-e3b0d5f6183c	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	Welcome to TucanBit Casino! Sign this message to verify your wallet ownership and access your account. Nonce: e86004e1-baf2-4ca1-bafd-ecf7da3d7e8b	e86004e1-baf2-4ca1-bafd-ecf7da3d7e8b	2025-09-04 15:17:05.286834+00	t	2025-09-04 15:07:05.287139+00
\.


--
-- Data for Name: crypto_wallet_connections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.crypto_wallet_connections (id, user_id, wallet_type, wallet_address, wallet_chain, wallet_name, wallet_icon_url, is_verified, verification_signature, verification_message, verification_timestamp, last_used_at, created_at, updated_at) FROM stdin;
125a23f5-2619-4c04-86ab-15dacaf5600e	3fbc49ac-db45-40c4-a949-ade55082662e	metamask	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	ethereum	\N	\N	f	\N	\N	\N	2025-09-03 23:47:58.479686+00	2025-09-03 23:47:58.479686+00	2025-09-03 23:47:58.479686+00
766503a1-84a8-443a-a498-896e9c7e0693	f12e2768-0c41-40af-9c12-0d264a76d5ca	metamask	0x1234567890abcdef1234567890abcdef12345678	ethereum	\N	\N	f	\N	\N	\N	2025-09-03 23:48:43.231022+00	2025-09-03 23:48:43.231022+00	2025-09-03 23:48:43.231022+00
\.


--
-- Data for Name: currencies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.currencies (id, name, status, "timestamp") FROM stdin;
\.


--
-- Data for Name: departements_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.departements_users (id, user_id, department_id, created_at) FROM stdin;
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.departments (id, name, notifications, created_at) FROM stdin;
\.


--
-- Data for Name: exchange_rates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exchange_rates (id, currency_from, currency_to, rate, updated_at) FROM stdin;
\.


--
-- Data for Name: failed_bet_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.failed_bet_logs (id, user_id, round_id, bet_id, manual, admin_id, status, created_at, transaction_id) FROM stdin;
\.


--
-- Data for Name: football_match_rounds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.football_match_rounds (id, status, "timestamp") FROM stdin;
\.


--
-- Data for Name: football_matchs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.football_matchs (id, round_id, league, date, home_team, away_team, status, won, "timestamp", home_score, away_score) FROM stdin;
\.


--
-- Data for Name: game_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.game_logs (id, round_id, action, detail, "timestamp") FROM stdin;
\.


--
-- Data for Name: games; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.games (id, name, status, "timestamp", photo, price, enabled) FROM stdin;
cfb2c688-0d30-46ea-ba7e-6ee2b29a8443	TucanBIT	ACTIVE	2025-08-29 21:02:46.355312	\N	\N	f
843495fe-c0b7-451f-b1d2-e68b86d06008	Plinko	ACTIVE	2025-08-29 21:02:46.356095	\N	\N	f
e567e3b0-a432-4062-84e5-dca294aa2479	Crypto_kings	ACTIVE	2025-08-29 21:02:46.356566	\N	\N	f
f144c263-911f-4bf6-b1d9-90b8efb92a9d	Football fixtures	ACTIVE	2025-08-29 21:02:46.357236	\N	\N	f
8d2ca9f6-1c0e-46ca-975f-72ca3afed060	Quick hustle	ACTIVE	2025-08-29 21:02:46.3577	\N	\N	f
b2a8cd89-83a0-40b5-8803-46a079ac245b	Roll Da Dice	ACTIVE	2025-08-29 21:02:46.359971	\N	\N	f
22ab4676-6657-410b-b030-4344d0ee1937	Scratch Card	ACTIVE	2025-08-29 21:02:46.360503	\N	\N	f
66f1020e-d9c8-4152-94c0-fc7b812b0016	Spinning Wheel	ACTIVE	2025-08-29 21:02:46.361111	\N	\N	f
5a729589-987d-4862-b1a5-3c32831da50d	Street Kings	ACTIVE	2025-08-29 21:02:46.361552	\N	\N	f
\.


--
-- Data for Name: ip_filters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ip_filters (id, created_by, start_ip, end_ip, type, created_at, description, hits, last_hit) FROM stdin;
\.


--
-- Data for Name: leagues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leagues (id, league_name, status, "timestamp") FROM stdin;
\.


--
-- Data for Name: level_requirements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.level_requirements (id, level_id, type, value, created_at, updated_at, deleted_at, created_by) FROM stdin;
\.


--
-- Data for Name: levels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.levels (id, level, created_at, updated_at, deleted_at, created_by, type) FROM stdin;
\.


--
-- Data for Name: login_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_attempts (id, user_id, ip_address, success, attempt_time, user_agent) FROM stdin;
85929894-c4c8-41af-91a2-10d15df4a52c	a5e168fb-168e-4183-84c5-d49038ce00b5	::1	t	2025-08-31 23:26:09.941001	curl/8.5.0
f048a15c-5418-43db-be7b-127dcc433dab	a5e168fb-168e-4183-84c5-d49038ce00b5	::1	t	2025-08-31 23:26:10.036911	curl/8.5.0
d59a61d9-f6cc-456c-8b60-57f77d5cc3c7	a5e168fb-168e-4183-84c5-d49038ce00b5	::1	t	2025-08-31 23:26:10.101304	curl/8.5.0
a66a56b9-60e5-40aa-91ad-37f7ae988e75	a5e168fb-168e-4183-84c5-d49038ce00b5	::1	t	2025-08-31 23:37:32.499274	curl/8.5.0
7edcace8-f1e6-44e4-9f19-dec24c2112bc	a5e168fb-168e-4183-84c5-d49038ce00b5	::1	t	2025-08-31 23:37:54.482686	curl/8.5.0
c2b9fecf-1508-4107-9b26-c3497a6b4143	a5e168fb-168e-4183-84c5-d49038ce00b5	::1	t	2025-08-31 23:38:23.570403	curl/8.5.0
4c99675b-d2bb-40d7-8c55-966e5904010c	a5e168fb-168e-4183-84c5-d49038ce00b5	::1	t	2025-08-31 23:39:04.739562	curl/8.5.0
ef6ec1e5-2a6f-4e30-820f-bb8abfd12661	a5e168fb-168e-4183-84c5-d49038ce00b5	::1	t	2025-08-31 23:40:27.685094	curl/8.5.0
47c947cb-f376-4ca2-8dbe-93c413a32453	a5e168fb-168e-4183-84c5-d49038ce00b5	::1	t	2025-08-31 23:41:15.262762	curl/8.5.0
ec2add3c-c24e-4520-80e4-6dba6a7ac61d	a5e168fb-168e-4183-84c5-d49038ce00b5	::1	t	2025-08-31 23:41:39.920212	curl/8.5.0
174a675d-4d55-47af-942e-c1d877a07d84	a5e168fb-168e-4183-84c5-d49038ce00b5	::1	t	2025-08-31 23:42:19.051125	curl/8.5.0
72011fdc-cdf1-469d-9c2e-7c955fbc0d42	a5e168fb-168e-4183-84c5-d49038ce00b5	::1	t	2025-08-31 23:43:24.278363	curl/8.5.0
b0f8000b-b4fe-4ea1-a0c8-c656abd6db48	a5e168fb-168e-4183-84c5-d49038ce00b5	::1	t	2025-08-31 23:44:39.530286	curl/8.5.0
6f24a652-57cc-47cd-95db-a572747a11e2	a5e168fb-168e-4183-84c5-d49038ce00b5	::1	t	2025-08-31 23:44:54.784118	curl/8.5.0
6d8bbe31-3abb-4946-83b5-af254a819924	a5e168fb-168e-4183-84c5-d49038ce00b5	::1	t	2025-08-31 23:46:37.392698	curl/8.5.0
b3986ce3-7c7c-42ce-a8dd-90a14c1052c3	a5e168fb-168e-4183-84c5-d49038ce00b5	::1	t	2025-08-31 23:46:53.907343	curl/8.5.0
8466d05e-7ff5-4e91-84a2-fbdf360e1b49	a5e168fb-168e-4183-84c5-d49038ce00b5	::1	t	2025-08-31 23:47:12.835756	curl/8.5.0
6471d70f-dea0-4d09-9ed8-ceca84b25621	a5e168fb-168e-4183-84c5-d49038ce00b5	::1	t	2025-08-31 23:47:33.826045	curl/8.5.0
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.logs (id, user_id, module, detail, ip_address, "timestamp") FROM stdin;
\.


--
-- Data for Name: loot_box; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.loot_box (id, type, prizeamount, weight, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: loot_box_place_bets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.loot_box_place_bets (id, user_id, user_selection, loot_box, wonstatus, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lotteries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lotteries (id, name, price, min_selectable, max_selectable, draw_frequency, number_of_balls, description, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lottery_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lottery_logs (id, lottery_id, lottery_reward_id, prize, created_at, updated_at, uniq_identifier, draw_numbers) FROM stdin;
\.


--
-- Data for Name: lottery_services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lottery_services (id, client_id, client_secret, status, name, description, callback_url, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: lottery_winners_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lottery_winners_logs (id, lottery_id, user_id, reward_id, won_amount, currency, number_of_tickets, ticket_number, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: manual_funds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.manual_funds (id, user_id, admin_id, transaction_id, type, amount, currency, note, created_at, reason) FROM stdin;
\.


--
-- Data for Name: operational_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.operational_groups (id, name, description, created_at) FROM stdin;
\.


--
-- Data for Name: operational_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.operational_types (id, group_id, name, description, created_at) FROM stdin;
\.


--
-- Data for Name: otps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.otps (id, email, otp_code, type, status, expires_at, verified_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, name, description) FROM stdin;
fa680098-83f8-4a29-bc52-b7a4bf0104cf	update level requirements	allow user to update level requirements
005a52da-766c-42e2-955a-7ead7945427d	Get Loot Box	allow user to get loot box
825fe594-12c0-43b0-90c8-ba7ec1909fd0	banner delete	allow user to delete banner information
e6374fb9-52a5-4753-86a5-a8c7fb285ae0	assign userto depertment	allow user to assign user to department
63081091-dae0-411d-ba97-8770d56da141	create league	allow user to create league
8d0ece27-5fb1-47b9-ab2a-5633c86cbe8b	refresh airtime utilities	allow user to fresh database to get updated utilities
befc8df0-59ff-410c-90dd-95f2b45d9b9f	get airtime utilities stats	allow user to get airtime utilities stats
c7e35017-0713-4fae-97b5-038600feb6ee	create adds service	allow user to create adds service
cf584334-eb5b-47c2-a818-779d7b63f161	Create Lottery Service	allow user to create lottery service
0bd5d799-e231-436f-9dd0-c55edbaeeba5	add or remove fund manually	allow user to add or remove fund manually
d3749109-bea0-46a4-b924-213fcb55585b	get leagues	allow user to get leagues
04f1c1b4-afc5-41cf-aa8f-425a7fa2b2b7	get football match round matches	allow user to get football match round matches
31fb3354-c027-4bdc-b5cd-e4b65d15d15a	get airtime utilities	allow user to get airtime utilities
9441898d-19f2-4ea2-9c19-db5d656b5957	Create Lottery	allow user to create lottery
ba1d6cd9-f1dd-48f7-9d37-ae7614eb98b8	Get Agent Referrals	allow user to get agent referrals
177a02ea-530f-4fa4-8d21-f0e93c52fee8	assign role	allow user to assign role to other user
fdeca284-39ed-465a-bb39-dd13ed4d6631	revoke role	allow user to revoke other user role
832f40d7-6979-4487-b9f2-23e108bb78b6	remove ip filter	allow user to remove ip filter
d3f028fa-b1af-4d3f-868e-333e1ec075b0	create departments	allow user to create new department
5ce6fb8f-6539-4087-b578-bd644d1f19b9	get point to users	allow user to get admin funded points
9e663847-3dcd-425a-a91a-08246093eb35	get admins	allow user to list admins
5e794e7f-95cd-4e6c-b0db-a098f1e93033	get daily report	allow user to get daily report
e37e21dc-f407-462b-9a42-57a8a33effa1	Update Loot Box	allow user to update loot box
5cd72d36-8a21-4df3-a740-1ac85591637e	super	supper user has all permissions on the system
1a580814-fadc-4c2a-afeb-8a971962ec2c	add ip filter	allow user to add ip filter
79239794-ccca-42ce-88d2-be66fc594248	reset user account password	allow user to reset user account password
af4f7885-9155-4c7f-bcf1-08efea4c71d9	delete games	allow user to delete games
931a03b4-ca19-40e5-9bd5-2b1475a12f19	get bet levels	allow user to get bet levels
a21666e7-a02d-47b1-ad89-8b7af0b799cd	banner update	allow user to update banner information
36c171fd-7b7b-40a8-95a1-87693bab3e51	get roles	allow user to get roles
eeef386c-6981-41f0-911a-b88f0ad6d9da	get user roles	allow user to get user roles
538d442d-87e6-4dce-acff-34e8fded0e91	block user account	allow user to block player's account
6fd62738-d0b7-468e-b7d9-b0da1172bc07	get bet history	allow user to fetch bet history
7f5f974d-4daf-4cc3-96c1-2214425e970e	create clubs	allow user to create clubs
7cfb07b0-ea17-465c-b394-f4585e08dec0	udpate football round price	allow user to udpate football round price
12414be3-3fb9-4ab7-ad6a-9df017259712	get signup bonus	allow user to get signup bonus
4d7f902b-a24b-4dd9-b57f-89c1f699c974	banner create	allow user to create banner information
c5289370-3726-4756-b34c-f1bbb4b7139b	get departments	allow user to fetch list of departments
97422e2c-cb3d-4aab-bee1-2d83d3b471a6	update department	allow user to update department
81774695-dd1a-4a9d-b87f-964b41c9b8c9	manual refund failed rounds	allow user to refund failed round players
26052ad5-8b9b-4044-873f-8f39fda0071e	get financial metrics	allow user to get financial metrics
d725c99c-4441-4039-b889-6e487e0ce64d	delete company	allow user to delete company
af3cbbd8-34fa-4be8-8925-7fcace421306	update scratch card configs	allow user to update scratch card configs
11183c90-b960-42c4-aecd-3371fa28c24e	get permissions	allow user to get list of permissions
6269cf6b-6c03-44c1-b6ec-7be8c6ce6124	update role permissions	allow user to update role permissions
e1797a4d-926e-4c45-af90-46f4fff01ad4	get balance logs	allow user to fetch balance logs
a4fc5db7-aa7a-4977-922a-f9abbbda9479	create company	allow user to create company
c7f8119d-5081-4a8d-b871-af31c716d909	update game status	allow admin to update game status
40a44d4f-9cb2-47f7-81ce-2c5999dccce0	remove role	allow user to remove role
f53867c6-8614-4f57-a2c4-dcc96cdac461	get role users	allow user to get role users
a4f5fa7e-50fa-48e7-87b4-f2a4ce91e824	update referral multiplier	allow user to update the current referral multiplier 
c3aa549a-42e7-4815-9014-2777e17985bc	update football match multiplier	allow user to update football match multiplier
75654e18-e870-4a6c-8fc5-997459a509fc	delete mysteries	allow user to delete spinning wheel mysteries
49963f7d-f46b-4ef3-b46b-33af7caae682	banner read	allow user to read banner information
db6386fe-cc70-4233-81ba-8149f377ef1f	banner display	allow user to display banner information
aef8f72e-de31-4411-885e-f1bb7168c317	update games	allow user to update games
e310fb83-f3f2-4990-bdf7-b053c8b9ac16	get company	allow user to get company
1818f407-682e-4e4f-8eee-af81b3cf5571	add games	allow user to add games
17984d54-635b-4fa7-9cb7-6cee554822e2	create mysteries	allow user to create spinning wheel mysteries
26d8c748-c5f4-435f-98ab-c267f479e071	update bet icon	allow user to update bet icon
b36d52d4-b8f7-4305-aa7d-2a0a3b922d38	Create tournament	allow user to create tournament
4f3c749a-4373-401f-82b9-c34ee577069b	get adds services	allow user to get adds services
6b263c69-4d0b-4c7a-b7cb-03ad31f52451	banner image upload	allow user to upload banner images
e44aba67-cfb3-467f-a2af-1f53f9afc63b	get referral multiplier	allow user to get the current referral multiplier 
bd6fda86-56a6-46fd-8360-96bea2ef5d8a	get football round price	allow user to get football round price
541e105c-1f5b-4175-8303-aed1bbc4d9ff	update airtime price	allow user to update airtime price
3fc9ecc6-f10a-4d32-b741-0c4175e9e790	get airtime transactions	allow user to get airtime transactions
b06232b5-5af2-43d5-b184-b7cd40041859	Get Available Logs Module	allow user to Get Available Logs Module
91ce7374-0096-4b43-a68d-01deb5ff4447	create level requirements	allow user to create level requirements
2e51788f-d8cf-4e77-badc-32a32ef2b2ad	update signup bonus	allow user to update signup bonus
25843045-c2eb-4531-969a-b9cd6aea753d	Get Agent Referral Stats	allow user to get agent referral stats
8342bc13-5b2f-4eda-83d8-dfef8c913009	get ip filters	allow user to fetch ip filters
e00f031e-bc8f-46c7-a8b3-1733d8421515	get operational group type	allow to get operational group type
2a75a867-17ff-4c46-bc8a-e047ee45b0c8	get players	allow to get players 
d2f4d1f0-498e-47dd-b3b9-9f85bc5a2389	get clubs	allow user to get clubs
bcd8d73c-1dd3-4cbc-a00e-7108adcbeff5	close football matche	allow user to close football matche
6e232e63-6fc6-49e0-81de-1912de7aa747	delete spinning wheel config	allow user to delete spinning wheel config
10f372e2-c3f2-4d6a-871d-fd4827811fbc	create bet level	allow user to create bet level
ce29ea49-613c-4be8-ab5b-5a834f175630	Delete Loot Box	allow user to delete loot box
0ba3f5d8-6016-4828-a0f5-aed16464e0d7	get game metrics	allow user to get game metrics
94b3d04e-2e95-493d-80f8-748ca43c8785	add operational group	allow to add operational group types
5f6a75bb-de83-4f01-bf61-77571f37a810	get football match multiplier	allow user to get football match multiplier
ab251697-bad9-49f3-bd81-459c68528074	update cryptokings config	allow admin to update crypto kings config 
05317c54-28f7-40b1-a1d1-0e176848a4d9	get games	allow user to get games
b3b3fe3e-0b20-4d42-aacf-540f5c8c8098	get mysteries	allow user to get spinning wheel mysteries
acb51b42-7521-44d5-9da8-2e4668fa5f5a	Create Agent Provider	allow user to create agent provider
b6256c3e-fd59-4bb5-9c3a-49f2bcb003b1	get failed rounds	allow user to fetch failed rounds
457b9ab7-d33b-459e-b746-148a3983c2e7	get blocked account	allow user to get blocked account
7eec8477-83e3-4a80-b19e-7326e9d43ba2	get operational group	allow to get operational group type
52963ad7-8ae6-4e0e-819b-cf658971994f	create football matches	allow user to create football matches
c12dc59e-f3f1-4653-8ff3-889f01a8763a	Get Audit Logs	allow user to list Audit Logs
4d57b8db-4dad-49d1-8606-7cbe81edc361	register players	allow user to register players
616447e1-8ca2-453a-8bb4-faa71449b658	update airtime amount	allow user to update airtime amount
e304cfaa-a5ca-4962-95f5-244c99f525e2	update company	allow user to update company
45274a86-78df-47de-87d3-669fd161dcce	get fund logs	allow user to fetch manual fund logs
8161a0ce-3647-43fb-98c5-66b9c814fb0a	update user profile	allow user to update user profile
4aaab334-87f8-4304-8a66-a6c0cd5a3d0b	add operational group type	allow to add operational group types
460d3cab-ce42-42f3-bd11-34505cf72185	update airtime utility status	allow user to update airtime status
62d51725-d41b-48b1-9b4e-636f4940fbc5	get companies	allow user to get companies
c8bedaff-433f-4e48-be04-814d644a85fb	get available games	allow user to get available games
a6b74c48-3a33-4568-a090-2cc3e293452b	update mysteries	allow user to update spinning wheel mysteries
d994baec-c5e6-41a9-8c7e-4dd006723932	get spinning wheel configs	allow user to get spinning wheel configs
4ac7d8ab-0ddf-40e8-81b9-f62f28a070d7	add point to users	allow user to add points to players
31642eb4-0879-457f-b830-fc072b57fa2b	get football match round	allow user to get football match round
019a3a0a-524e-4681-96ea-09f621af74d3	disable games	allow user to disable games
6d0a4b7e-8bcf-4c77-8970-8ef65c5f3de6	Create Loot Box	allow user to create loot box
d2b74795-2df3-4afd-8779-fbcb3e5057e4	create role	allow user to create role
17f41fa3-0ae3-4b06-b622-6ff686714cc2	create football match round	allow user to create football match round
2fdab71e-b844-4939-a136-8f84cdee0a7c	add ip to company	allow user to add ip to company
641b0998-0f28-41d7-a821-141b9444cac0	create spinning wheel config	allow user to create spinning wheel config
4b96d99d-afac-474b-86a3-26586024b351	update spinning wheel config	allow user to update spinning wheel config
5670e0bb-a6e0-474f-bae9-90cc4703bb21	get scratch card configs	allow user to get scratch card configs
\.


--
-- Data for Name: plinko; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plinko (id, user_id, bet_amount, drop_path, multiplier, win_amount, finalposition, "timestamp") FROM stdin;
\.


--
-- Data for Name: quick_hustles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quick_hustles (id, user_id, status, bet_amount, won_status, user_guessed, first_card, second_card, "timestamp", won_amount) FROM stdin;
\.


--
-- Data for Name: risk_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.risk_settings (id, system_limits_enabled, system_max_daily_airtime_conversion, system_max_weekly_airtime_conversion, system_max_monthly_airtime_conversion, player_limits_enabled, player_max_daily_airtime_conversion, player_max_weekly_airtime_conversion, player_max_monthly_airtime_conversion, player_min_airtime_conversion_amount, player_conversion_cooldown_hours, kyc_required_above_amount, kyc_verification_timeout_hours, kyc_allow_partial, fraud_max_login_attempts, fraud_login_lockout_duration_minutes, alert_admins_on_trigger, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (id, role_id, permission_id) FROM stdin;
074120f0-5d69-44c8-b09c-28bec7c960b8	6d9325c3-ea8c-47c1-ba2b-285d1f7667bb	5cd72d36-8a21-4df3-a740-1ac85591637e
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, description) FROM stdin;
6d9325c3-ea8c-47c1-ba2b-285d1f7667bb	super	\N
\.


--
-- Data for Name: roll_da_dice; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roll_da_dice (id, user_id, status, bet_amount, won_status, crash_point, "timestamp", won_amount, user_guessed_start_point, user_guessed_end_point, multiplier) FROM stdin;
\.


--
-- Data for Name: rounds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rounds (id, status, crash_point, created_at, closed_at) FROM stdin;
5dd3ae28-108e-4dcd-8af0-9588d0edc429	closed	0.54	2025-08-30 22:19:24.00153	2025-08-31 01:24:30.088925
d5ca32bf-e4c0-4599-aff9-105cb9622078	closed	0.44	2025-08-29 21:02:47.001567	2025-08-30 00:07:51.979574
707aa8db-2db6-4293-a111-11269d1b1d85	closed	2.54	2025-08-29 21:07:51.976984	2025-08-30 00:13:19.205275
ad42f771-6ae6-492e-bc39-6c62bfbd333a	closed	0.31	2025-08-30 20:07:59.002187	2025-08-30 23:13:02.544114
58a38bfa-5e8e-4ebd-8d77-8b2bdd8c32de	open	0.78	2025-08-29 21:18:28.945607	\N
18d9c23e-c690-4a8c-8894-9c2b36b72d9f	closed	0.89	2025-08-29 21:13:19.187363	2025-08-30 00:18:28.94908
867dd19a-eb21-40bb-a4a2-4f9e62f0b660	open	3.00	2025-08-29 21:26:50.576156	\N
f62623bc-fd97-4c0c-b1d3-cfd053a8cdba	closed	1.58	2025-08-29 21:21:34.001534	2025-08-30 00:26:50.581152
3f1a44b3-3fe1-490b-a972-2bf39c963e3c	closed	0.39	2025-08-29 21:27:02.001247	2025-08-30 00:32:05.430434
c1600eb6-ed6e-45f7-9153-5c65cf0c4632	closed	4.49	2025-08-30 20:13:02.541199	2025-08-30 23:18:51.731294
e1d95c67-9ff4-4a60-8c22-2499ca8d3935	open	0.25	2025-08-29 21:37:06.441414	\N
9f30b242-a4ea-4283-b7b9-85ee467ebaa2	closed	0.12	2025-08-29 21:32:05.42626	2025-08-30 00:37:06.443788
fdf3bbf8-853c-40a3-9c24-26d509100b16	open	0.16	2025-08-29 21:43:48.002235	\N
7f8ea616-049e-4b2c-b87a-2624b66dd762	closed	1.25	2025-08-30 21:22:42.002409	2025-08-31 00:27:55.933883
3e6a4244-4b9f-49ab-ad16-7697a4f53720	open	2.12	2025-08-29 21:52:12.671388	\N
56f4dad8-dce3-4eb8-9c13-5d5f4e072c55	closed	1.68	2025-08-29 21:46:54.002216	2025-08-30 00:52:12.6747
2cbc6e7f-700f-4652-9235-06d8227c4421	open	3.81	2025-08-29 21:53:05.001521	\N
0d15db11-a334-4158-9f99-b1e83b33650c	open	0.78	2025-08-30 20:24:26.574204	\N
19cbc7ea-7d19-4872-9723-f492841b2746	open	0.61	2025-08-29 22:00:15.106699	\N
41d4161c-5010-4e65-96fb-3fee4ef6e312	closed	1.90	2025-08-29 21:54:54.002205	2025-08-30 01:00:15.114129
2f7dafe7-e68f-4129-ab1b-8a4c00ae90bb	open	1.92	2025-08-29 22:03:17.001583	\N
1ae41e7c-962e-40fa-85f3-bed05a080b7a	closed	3.21	2025-08-30 20:18:51.727116	2025-08-30 23:24:26.577825
19954f06-297b-40fd-8497-c68789f9cb7b	open	4.15	2025-08-29 22:13:33.727181	\N
5e171c0b-2623-49b6-9036-23136391572e	closed	0.87	2025-08-29 22:08:24.004613	2025-08-30 01:13:33.72962
4688f235-2ad1-4e65-9e60-c7ce7130220a	open	1.84	2025-08-29 22:14:25.001695	\N
f4875118-24fc-4f66-8261-51f9fcbf84a7	open	1.59	2025-08-29 22:19:17.001399	\N
fd7e7369-9e41-4113-90b7-98dc58d8c367	open	1.72	2025-08-30 20:25:50.001373	\N
da2b08f0-ac6f-44cf-aa24-9532dfa76080	open	2.47	2025-08-29 22:28:44.991899	\N
59fcdec4-e417-4646-94c2-87e960fd548b	closed	0.17	2025-08-29 22:23:44.001629	2025-08-30 01:28:45.007536
57f41a9b-1b2c-4e8c-97ad-9c1f97999779	open	0.15	2025-08-29 22:31:18.001496	\N
73292c2e-681e-4d48-ae25-ce2ca64bc49f	open	9.72	2025-08-29 22:33:34.001231	\N
e672bfc8-2468-4ef2-983a-abe5a9494df1	open	1.29	2025-08-29 22:40:05.151708	\N
c279e4f5-7a97-45a8-b947-f05fbf1b74c9	closed	1.18	2025-08-29 22:34:53.001843	2025-08-30 01:40:05.155939
e3831d74-5950-4501-ab72-9d3539481db2	open	1.57	2025-08-29 22:41:44.002392	\N
b0329ebc-9bda-4975-bb51-4efecc1c932d	open	0.12	2025-08-29 22:47:41.000777	\N
a72437c2-bdf4-4551-a2a5-9e76e0e0958f	open	1.74	2025-08-29 22:57:22.23735	\N
7d849fd2-b23f-4a49-9481-c0a73a90f646	closed	0.01	2025-08-29 22:52:23.001566	2025-08-30 01:57:22.239044
e30b1099-191e-4c5a-bd08-89f8fe81de77	open	0.10	2025-08-29 23:03:58.02941	\N
16438de0-55ff-4c37-9264-4d1d624f1ddf	closed	1.26	2025-08-29 22:58:45.000973	2025-08-30 02:03:58.030084
d0f74fae-8066-4d1e-94c3-bfc9d68d84f0	open	1.90	2025-08-30 06:06:12.002686	\N
d50cde7c-a9ae-4363-9fd6-2acc7f6b278d	open	0.57	2025-08-30 06:23:31.002443	\N
f578e5a0-3634-4c5e-bb35-381427756406	open	0.28	2025-08-30 06:27:53.001599	\N
d3f47261-aac9-479e-8466-f1721df17481	open	1.47	2025-08-30 06:32:59.002274	\N
4d83355e-e4e1-424c-9bfe-e3d56454d792	closed	0.10	2025-08-30 20:27:14.001344	2025-08-30 23:32:14.229367
2246f056-0daf-4042-bf3a-8a9d313fc366	closed	1.11	2025-08-30 06:37:36.002189	2025-08-30 09:42:47.387613
54b14ffb-19d9-4269-829a-baf4ad0f6685	open	1.35	2025-08-30 21:33:01.533939	\N
795b73fe-84e6-4b85-97e0-c8ce9e78a543	closed	4.99	2025-08-30 06:42:47.386097	2025-08-30 09:48:42.260878
e7b634cb-4990-4c67-88ff-29d64c218f32	open	0.19	2025-08-30 20:37:31.699768	\N
d2cdc19c-61b5-4160-b635-29a6172fe167	open	0.34	2025-08-30 06:53:46.206344	\N
cb585719-12a5-45c9-95c7-68878ea071ef	closed	0.37	2025-08-30 06:48:42.256305	2025-08-30 09:53:46.209646
e7ed9436-3208-44ef-8e5b-cce874139613	open	1.97	2025-08-30 06:59:48.001642	\N
15194a1e-6329-4109-9655-32971efe56ed	open	3.76	2025-08-30 07:02:50.002494	\N
2f79e56f-96f6-4c4b-a2b3-3e0a89e2c50b	open	0.57	2025-08-30 18:32:36.003534	\N
b0593872-0eb2-4d1d-b408-8a8e836f0d4f	closed	1.59	2025-08-30 20:32:14.225838	2025-08-30 23:37:31.707663
cbbadcaf-477d-4e59-a282-330e2926b1a9	closed	0.52	2025-08-30 18:35:58.001252	2025-08-30 21:41:02.872559
0f3cb0e5-91b1-4a25-9c70-2959f9bc101d	open	1.59	2025-08-30 20:41:21.002411	\N
eabca7ca-0eb1-4de6-b137-a4e2d3f4b1e7	closed	2.72	2025-08-30 18:41:02.868385	2025-08-30 21:46:32.186591
9e7c47fa-b010-42b9-84c0-dbfa87caa87a	open	0.53	2025-08-30 20:42:48.001817	\N
c9d1dcbe-dd25-4034-a455-cc4a4f2eb235	open	1.86	2025-08-30 18:51:33.333219	\N
78b48aef-48a3-461c-b599-7e8bb2ca3a8c	closed	0.11	2025-08-30 18:46:32.183059	2025-08-30 21:51:33.336655
ec6c7376-d1f0-4797-8ea6-a92121f5fef3	open	1.72	2025-08-30 18:56:23.002348	\N
f1078540-a720-4c5b-a6fd-1daf5b10a1ae	open	0.81	2025-08-30 19:00:53.001483	\N
51b911ca-51e6-4ffb-916a-590ef3e9ca56	open	1.72	2025-08-30 19:03:37.001527	\N
3cb6eaec-18f0-4f6a-a472-51b6ae9735ff	open	2.01	2025-08-30 19:15:16.001919	\N
50883922-e522-4539-9024-b825d3e65296	open	1.84	2025-08-30 19:16:50.000985	\N
da003a25-8501-4deb-aec3-3edf7dbe66c2	open	1.35	2025-08-30 19:18:55.002037	\N
afc277d0-9184-4010-b4bd-29382bc98dc7	open	0.70	2025-08-30 20:46:58.001308	\N
fd1c3383-ffde-4802-a5e2-f296e5adcf25	closed	1.17	2025-08-30 19:23:45.000984	2025-08-30 22:28:57.078661
90f816a9-0a21-42cd-8f5b-31399c28a4db	open	0.47	2025-08-30 19:34:00.21485	\N
073b111a-630e-4da3-a139-eb1cf87c5ed4	closed	0.28	2025-08-30 19:28:57.055512	2025-08-30 22:34:00.218685
da6f3f99-e429-41ac-ade5-bfe479abe2f3	open	1.08	2025-08-30 19:36:20.001412	\N
7ed29ba7-5877-4441-b307-bae1a557d6a0	open	0.22	2025-08-30 19:40:03.000998	\N
79ed6ad5-c410-431f-adff-ef449abdc914	closed	0.58	2025-08-30 21:27:55.926498	2025-08-31 00:33:01.534584
c37a09e5-3d66-4786-9024-044cd2f583e8	open	0.03	2025-08-30 19:49:55.992278	\N
fea74917-7d27-4db5-966c-24b851f93b21	closed	2.43	2025-08-30 19:44:30.001192	2025-08-30 22:49:55.995729
977ca361-46f2-4d81-8765-34079c168a1f	open	1.10	2025-08-30 19:52:36.001922	\N
7f3d04db-38cb-42dd-afda-f0b71589f1ef	closed	1.45	2025-08-30 20:48:52.00183	2025-08-30 23:54:07.150023
4e290ad9-d88d-4faf-ae29-f729f98067fc	closed	0.77	2025-08-30 20:54:07.14646	2025-08-30 23:59:15.629739
3bda3ed2-cbfb-49d8-b1a6-fa28e8662559	closed	2.26	2025-08-30 22:00:28.912476	2025-08-31 01:05:53.083799
01a133da-8d6a-4110-b022-a2e4c337674d	closed	0.92	2025-08-30 20:59:15.627383	2025-08-31 00:04:25.29181
e4fb8dbd-5e66-4191-a9c7-a333fd800b3a	open	0.83	2025-08-30 21:09:25.999696	\N
19cce9a2-69ad-42bc-912c-ab8f62d315cf	closed	0.08	2025-08-30 21:04:25.289397	2025-08-31 00:09:26.002301
e84043ec-963d-4d3c-9595-534e8a6d00b7	open	0.24	2025-08-30 21:11:30.001712	\N
74819353-da37-4f7b-bcb0-42cf9a68ca0a	closed	0.14	2025-08-30 21:39:58.001086	2025-08-31 00:44:58.684781
85ca2055-942e-4811-b5be-3ed245d380d8	open	3.30	2025-08-30 21:20:25.307145	\N
e3cefcd9-ea53-47a5-b787-8fa283eab0df	closed	0.56	2025-08-30 21:15:20.001494	2025-08-31 00:20:25.309553
ec360c72-ad4e-412c-87ea-c2d23a10e404	open	0.30	2025-08-30 21:20:57.001472	\N
38572553-fec4-4009-b959-db114093d1ca	open	0.44	2025-08-30 21:22:10.001368	\N
b5812754-0afd-4f98-ba0b-b4ecbeb5958f	closed	1.13	2025-08-30 21:44:58.664568	2025-08-31 00:50:10.598366
82521a99-c4dc-4758-b910-323c85d26554	closed	0.29	2025-08-30 21:50:10.595162	2025-08-31 00:55:13.323528
dc27decc-4562-4426-bb2d-ae750091596b	closed	1.50	2025-08-30 22:05:53.081377	2025-08-31 01:11:09.699196
e78d4ca0-4146-47c3-8184-8d3ded74c9cf	closed	1.43	2025-08-30 21:55:13.320494	2025-08-31 01:00:28.914684
ef9fa898-5871-4b93-9d34-eb4d67078f9e	open	0.26	2025-08-30 22:37:32.001181	\N
0cc84a60-1674-4c87-a328-5df5e538f98d	open	0.45	2025-08-30 22:16:12.207456	\N
fc292002-7d46-48d6-ab6d-4f11c596bb2c	closed	0.28	2025-08-30 22:11:09.695344	2025-08-31 01:16:12.210688
f8c83a31-5a9e-4e6c-a96d-a9d6747dce44	open	0.48	2025-08-30 22:24:30.087078	\N
7fa9ee3f-88f9-4fad-831f-749ca6df24ec	open	4.54	2025-08-30 22:33:02.476751	\N
471d5d18-c68c-484c-a34c-e823de46ac0b	closed	1.39	2025-08-30 22:27:48.002085	2025-08-31 01:33:02.479844
d3c711c3-0cda-42dd-bab2-2378a8ca4093	open	1.85	2025-08-30 22:35:51.001671	\N
0a10d445-d7f0-49b5-8e25-a66b74f59400	open	1.75	2025-08-30 22:44:51.814407	\N
f21e0de3-253b-4aa7-8256-6f9e720d5f18	closed	1.33	2025-08-30 22:39:38.001233	2025-08-31 01:44:51.816118
a7d62655-3815-4818-a065-8e8b360ff5a9	open	1.21	2025-08-30 23:09:05.001331	\N
dbcebfb0-8b6e-4e01-b378-b6375e022066	open	0.86	2025-08-30 23:07:43.503913	\N
db5a7a23-8c65-4629-89d9-7ca2b2ca15d3	closed	1.12	2025-08-30 23:02:32.002448	2025-08-31 02:07:43.505466
c3528d82-f942-4d6d-b46a-ba2c5ac3eed5	open	1.50	2025-08-30 23:13:22.000819	\N
492779f7-1223-4c03-bd7c-93efc7cd646f	open	1.65	2025-08-30 23:15:09.00274	\N
c435fd5e-6870-4e4f-bd2f-999d1d88d307	open	1.59	2025-08-30 23:18:56.000814	\N
11f86b0e-b531-4bd9-9ac1-fd3f4977e8af	open	2.37	2025-08-30 23:26:33.808788	\N
6244a432-44c8-4d3f-bdf8-0c76d891dcfe	closed	1.33	2025-08-30 23:21:19.004228	2025-08-31 02:26:33.809558
1f0570a5-6f6b-4290-b154-8a2015a9ca88	open	1.37	2025-08-30 23:33:09.033238	\N
36c3b189-bbc3-4c36-a03d-18b965c0bb16	closed	1.62	2025-08-30 23:27:52.001368	2025-08-31 02:33:09.035739
d08ab5c2-015e-4e6e-ac54-9fe387ceebe6	closed	1.20	2025-08-31 09:03:16.891281	2025-08-31 12:08:29.375689
52c9f6c5-fda1-4f88-8832-f0477a714423	closed	1.09	2025-08-30 23:35:31.001025	2025-08-31 02:40:42.159777
995fd643-d14b-447f-9929-6e2199957a46	closed	0.79	2025-08-31 11:53:15.493787	2025-08-31 14:58:23.845847
16b0c85a-67b1-44a6-9dde-12b0afc0b310	open	2.54	2025-08-30 23:45:58.245582	\N
84bae5ae-72eb-4d3b-9b64-3a55405ea328	closed	1.46	2025-08-30 23:40:42.156787	2025-08-31 02:45:58.246721
d881cb03-5d7d-42ec-8443-26e21b30ad1e	open	1.80	2025-08-30 23:47:28.000991	\N
cb52c469-3ea0-43cc-935c-a5f4d313d7fd	open	0.19	2025-08-30 23:52:07.003874	\N
1a896343-2bb3-4f06-839a-336996f4d62a	closed	1.63	2025-08-30 23:52:27.001432	2025-08-31 02:57:44.132753
04b5cf09-4d43-4918-ab94-e305c7d7f2e2	closed	2.14	2025-08-31 09:08:29.368284	2025-08-31 12:13:52.753575
4060c060-d115-4e1f-adc7-c8d40664a71d	closed	0.52	2025-08-30 23:57:44.130515	2025-08-31 03:02:49.860305
845faa4a-982f-400b-a638-62ffed8e49f7	in_progress	3.02	2025-08-31 00:02:49.857404	\N
40ec6499-074a-47e7-9009-ebad3382acf7	closed	0.06	2025-08-31 00:08:06.004594	2025-08-31 03:13:06.779721
18f32afc-3e82-4c6d-aa8b-1fd812c17dd7	open	3.01	2025-08-31 00:18:23.685641	\N
09f6f95d-d5e9-404d-8cfc-bf6d6cab61bf	closed	1.59	2025-08-31 00:13:06.779041	2025-08-31 03:18:23.686646
ccde854c-f40d-420d-b225-4ca86fcc0a8b	closed	1.41	2025-08-31 09:13:52.75061	2025-08-31 12:19:07.695991
92623c3e-3e02-4cd9-9fde-f73de8669a33	closed	1.99	2025-08-31 00:18:47.001045	2025-08-31 03:24:08.151196
a082bfcd-7b4b-409d-8313-140468f2330b	closed	1.53	2025-08-31 10:48:33.379921	2025-08-31 13:53:50.019594
55d16b2d-61bc-4df1-8c94-214ad8024caf	closed	0.83	2025-08-31 00:24:08.146436	2025-08-31 03:29:17.288182
ff120584-3e00-4be2-b23a-a786afadb743	open	4.03	2025-08-31 00:34:17.226755	\N
e1c7c39e-20cf-4bd0-b1fc-1f4ef6bba359	closed	0.01	2025-08-31 00:29:17.285349	2025-08-31 03:34:17.227553
0a287f52-94b4-451e-a778-93e34acc19f4	closed	1.82	2025-08-31 09:19:07.692587	2025-08-31 12:24:27.224806
050749b7-29ea-4313-b141-b7405a3f45ef	closed	0.78	2025-08-31 00:36:29.001503	2025-08-31 03:41:36.755997
4abc6857-9935-4eb5-9c2a-e6cd8cab78b6	closed	1.57	2025-08-31 12:58:05.068667	2025-08-31 16:03:22.460427
90d3f341-8c0d-42a0-bb0e-c0b54132f115	open	3.65	2025-08-31 07:00:05.242043	\N
f2eee053-af06-4ebb-8e50-311874f269d1	closed	2.14	2025-08-31 00:41:36.752348	2025-08-31 10:00:05.25127
47adb587-ee56-46c7-b39b-5ce834fc0065	open	1.93	2025-08-31 07:20:08.745662	\N
d42ef4b5-1a6e-4939-b203-2abcbbf790c9	closed	0.60	2025-08-31 07:15:03.001226	2025-08-31 10:20:08.747991
52a1a018-257f-4297-b13e-5c37b3a6f148	closed	1.29	2025-08-31 09:24:27.217002	2025-08-31 12:29:41.379948
11723356-e2c1-4e76-bd5e-c66703512a6a	closed	1.64	2025-08-31 07:23:40.001991	2025-08-31 10:28:57.244754
3d3bc9d5-2a02-4f90-851c-ba80ac3939e4	closed	0.20	2025-08-31 07:28:57.240237	2025-08-31 10:33:59.330233
46c4e697-6af2-454b-a106-6f8a41ad3013	closed	3.52	2025-08-31 07:33:59.326738	2025-08-31 10:39:37.986085
31fe10df-26c4-4959-b7cf-041dc13d069e	closed	0.29	2025-08-31 09:29:41.37088	2025-08-31 12:34:44.323077
d55bd787-a378-41e6-94df-1072a9b323dc	closed	1.06	2025-08-31 07:39:37.982948	2025-08-31 10:44:48.834119
a7fcd3c9-8b4b-4d0d-8f73-92b80c3c40cb	closed	1.96	2025-08-31 10:53:50.016573	2025-08-31 13:59:11.768132
6f37acdc-b023-4b50-98ce-9c02e3b0572e	closed	0.36	2025-08-31 07:44:48.83098	2025-08-31 10:49:52.098329
09d6d4f8-81f0-4e86-a3c7-40a6ac96455a	closed	1.09	2025-08-31 07:49:52.096437	2025-08-31 10:55:04.162629
80643f44-f702-44dc-b05e-72b0a99833da	closed	0.43	2025-08-31 09:34:44.319528	2025-08-31 12:39:48.867569
14b4cb0f-193c-4f2f-b143-cf73f43f192c	closed	0.99	2025-08-31 07:55:04.159155	2025-08-31 11:00:15.059382
498bb5eb-2175-4a6c-860c-411868dc8a60	closed	0.30	2025-08-31 08:00:15.055969	2025-08-31 11:05:18.437394
1cf00e2d-2696-43a6-9ecc-8d60be16c350	closed	1.83	2025-08-31 08:05:18.434185	2025-08-31 11:10:38.35273
27d9d134-2fb8-4929-9e38-9c5f7cd63350	closed	0.23	2025-08-31 09:39:48.864388	2025-08-31 12:44:50.662484
48fcc175-629b-4bc5-b461-7fa607520d96	closed	0.30	2025-08-31 08:10:38.349535	2025-08-31 11:15:41.434344
0163729d-f332-4612-bc9f-b05f61065b4a	closed	0.93	2025-08-31 08:15:41.431459	2025-08-31 11:20:51.396564
02d0428e-8e83-4e11-a82e-64e66f54595e	closed	0.47	2025-08-31 08:20:51.393661	2025-08-31 11:25:56.313803
e9365e2a-a508-48a6-9937-65f2d7552708	closed	4.83	2025-08-31 09:44:50.658698	2025-08-31 12:50:43.469509
8974fa80-16cb-4570-bcd8-11c347c64a05	closed	2.04	2025-08-31 08:25:56.305613	2025-08-31 11:31:18.652587
ac8c3245-bd51-49a2-a2f7-092ff6d416f7	closed	0.95	2025-08-31 10:59:11.765412	2025-08-31 14:04:21.617059
1a938f8e-0627-484b-b157-2e0d16d1b35c	closed	1.34	2025-08-31 08:31:18.649423	2025-08-31 11:36:32.919
bb64a3dc-ffc7-4a93-988a-2b77d3d703aa	closed	2.85	2025-08-31 08:36:32.916046	2025-08-31 11:42:03.59424
54d22d65-90d0-4990-ae3e-bfce8e843ac9	closed	0.20	2025-08-31 09:50:43.46836	2025-08-31 12:55:45.335038
efb0d82a-4370-4592-b3ad-cf455bcace2a	closed	2.62	2025-08-31 08:42:03.589826	2025-08-31 11:47:32.048566
a68493ee-98b1-4432-ab2b-acd91273dde0	closed	3.64	2025-08-31 11:58:23.842672	2025-08-31 15:04:03.330973
55afaa7c-81b9-4814-bd32-bc45922a0aee	closed	0.56	2025-08-31 08:47:32.045072	2025-08-31 11:52:38.306458
97777fc1-a35e-4d31-8270-f642a0281eb0	closed	0.14	2025-08-31 08:52:38.303369	2025-08-31 11:57:39.665517
6066aa93-bd26-4918-afdd-103219e1aba6	closed	3.63	2025-08-31 09:55:45.327409	2025-08-31 13:01:25.224756
dd52b6bb-c8cd-496c-be32-3d838cd9ce73	closed	3.42	2025-08-31 08:57:39.662359	2025-08-31 12:03:16.895028
519e3210-f781-4919-bd18-bd54839916ab	closed	0.05	2025-08-31 11:04:21.613775	2025-08-31 14:09:21.670952
21127cd7-a6bb-4e56-a607-6b168fbfacd9	closed	1.08	2025-08-31 10:01:25.216952	2025-08-31 13:06:37.049543
07592041-0ebb-425e-8306-ce1c3b7bb0d3	closed	0.22	2025-08-31 10:06:37.048213	2025-08-31 13:11:39.553907
75f1df2d-1aaf-4c43-bb3d-63e3361f091a	closed	1.40	2025-08-31 10:11:39.54671	2025-08-31 13:16:54.586493
1165b735-d96f-4eb8-98b4-41bc70b5eeb5	closed	4.74	2025-08-31 11:09:21.667853	2025-08-31 14:15:13.47344
8e9882a0-5e34-4544-8bd5-dbe6fe5d8d80	closed	0.46	2025-08-31 10:16:54.579227	2025-08-31 13:21:59.19994
2a82134b-610f-4acf-bbe5-8cab0fc45067	closed	3.58	2025-08-31 10:21:59.196626	2025-08-31 13:27:38.666363
890366ab-bc3b-4693-93cc-8d59daecea09	closed	2.08	2025-08-31 10:27:38.662457	2025-08-31 13:33:01.093749
b445cdf2-0a76-4c8d-8600-ff891d4c1cbe	closed	4.32	2025-08-31 11:15:13.470474	2025-08-31 14:21:00.838352
4304f7d7-bdbb-4643-8f08-aaa5570df950	closed	1.13	2025-08-31 10:33:01.090818	2025-08-31 13:38:13.602647
1dde7c86-a505-497d-84dd-5b553cc1ebfa	closed	1.77	2025-08-31 12:04:03.327562	2025-08-31 15:09:22.66778
01dd43cb-8ea8-4721-8049-43cc1d313f2a	closed	0.75	2025-08-31 10:38:13.599418	2025-08-31 13:43:21.405932
cfa17164-39b6-46c1-9641-b50f15b47cf6	closed	1.11	2025-08-31 10:43:21.40284	2025-08-31 13:48:33.382461
a12b7913-7e66-40e0-9390-c50984f13c95	closed	0.35	2025-08-31 11:21:00.835259	2025-08-31 14:26:03.989912
73b4b5e6-c157-426e-ad69-c64c0baa44d8	closed	4.99	2025-08-31 12:35:52.514369	2025-08-31 15:41:47.228581
66c4f192-9caa-4533-93c9-daa83e7dfd89	closed	4.09	2025-08-31 11:26:03.986622	2025-08-31 14:31:48.304048
c02f99a8-d32f-4196-add9-3558d62201da	closed	2.96	2025-08-31 11:31:48.295093	2025-08-31 14:37:20.815944
50b7fb59-f171-409c-950a-d794e3df8f2b	closed	1.15	2025-08-31 12:09:22.664335	2025-08-31 15:14:34.817724
cc70cce9-bc25-4e9f-922e-fdbdc909bde2	closed	3.35	2025-08-31 11:37:20.811626	2025-08-31 14:42:57.124295
11985769-ac95-4679-87c9-f8ecf7cff85c	closed	0.49	2025-08-31 13:13:41.839352	2025-08-31 16:18:46.530086
4293e06a-eef4-44b7-bb93-58c82583fdf7	closed	0.63	2025-08-31 11:42:57.120946	2025-08-31 14:48:04.08227
1d634414-73de-4ffc-84ab-4dbfe3a71f54	closed	1.03	2025-08-31 11:48:04.079924	2025-08-31 14:53:15.496888
bfc410b4-0cb0-4a4a-8fe1-4d8bb517a361	closed	2.65	2025-08-31 12:14:34.814797	2025-08-31 15:20:03.390107
cda1e530-904a-4732-8828-14f8b20a2061	closed	1.55	2025-08-31 12:41:47.227355	2025-08-31 15:47:04.245658
e0f76ebf-d3ea-40c6-910f-7cc4f92c0adc	closed	0.41	2025-08-31 12:20:03.387179	2025-08-31 15:25:07.648613
7cafdc69-6b48-4dcf-bcc7-dd7d14008dc7	closed	1.69	2025-08-31 12:25:07.645636	2025-08-31 15:30:25.794212
625db847-dc36-4a70-8c91-47d0ed51c2ff	closed	2.48	2025-08-31 12:30:25.785926	2025-08-31 15:35:52.517933
54f623f6-1276-4798-9c94-bc320f2b9c69	closed	4.86	2025-08-31 12:47:04.238275	2025-08-31 15:52:57.799678
ecff4805-c268-4db2-978c-18ef8934ffc7	closed	0.97	2025-08-31 13:03:22.456982	2025-08-31 16:08:32.837146
ba240e92-a7ec-4a93-9e97-abc0fb4623af	closed	0.72	2025-08-31 12:52:57.797654	2025-08-31 15:58:05.070704
437f166d-a48c-4b69-a74a-f69021314899	closed	0.18	2025-08-31 13:23:49.214134	2025-08-31 16:28:51.112032
4f307866-92ca-433a-9893-96c09f291756	closed	0.88	2025-08-31 13:08:32.829547	2025-08-31 16:13:41.847252
ea9c53c6-1e38-47d8-aa83-751a12461269	closed	0.11	2025-08-31 13:33:52.442196	2025-08-31 16:38:53.336603
211cac2f-4c74-4eec-bcaf-56be06d5250c	closed	0.28	2025-08-31 13:18:46.52672	2025-08-31 16:23:49.217492
48c4efe0-6044-473e-a238-fc707b4d78da	closed	0.12	2025-08-31 13:28:51.108746	2025-08-31 16:33:52.446985
7177a0b6-d4f9-4561-b7e4-cf910ea65ea2	closed	3.93	2025-08-31 13:38:53.332658	2025-08-31 16:44:36.532116
a6ca29dd-f255-4666-9d86-97d2501077ca	closed	2.79	2025-08-31 13:44:36.528624	2025-08-31 16:50:06.935486
eeace43a-9a4b-4b59-95a2-1a54b52c6993	closed	2.10	2025-08-31 13:50:06.929635	2025-08-31 16:55:29.318725
d40243be-387f-49fd-a2fc-795af7797173	closed	0.00	2025-08-31 13:55:29.310979	2025-08-31 17:00:29.120196
35b510f4-c138-49e9-ad29-21a58032e4a8	closed	1.23	2025-08-31 14:00:29.116974	2025-08-31 17:05:42.705648
a7bc8a12-2168-4f9a-b656-b001ae0aa2a6	closed	3.72	2025-08-31 14:05:42.702661	2025-08-31 17:11:23.214745
406eefaa-f7db-4899-8d72-3f00eeb42936	closed	0.41	2025-08-31 14:11:23.211158	2025-08-31 17:16:27.64827
f38ed252-bbe8-4ff4-90a0-c5a06516f309	closed	0.10	2025-08-31 14:16:27.644402	2025-08-31 17:21:28.229269
2bf236e2-a7c4-4aa0-8453-d6d52708e191	closed	4.53	2025-08-31 14:21:28.225501	2025-08-31 17:27:18.158683
28253fea-1323-41d9-b34a-5948a4b7672b	closed	0.51	2025-08-31 14:27:18.150993	2025-08-31 17:32:23.758415
6c102078-bd56-47d2-84e0-48f939cbf6b9	closed	3.02	2025-08-31 18:16:39.266158	2025-08-31 21:22:12.473442
ae1beae9-2fe3-4692-a62d-a63d90d94e00	closed	3.34	2025-08-31 14:32:23.754504	2025-08-31 17:38:00.013932
59efe6f8-adbe-42e2-8952-3e4a4995ae8f	closed	1.11	2025-08-31 20:15:11.93266	2025-08-31 23:20:23.377534
1a04c3b9-896e-4a23-95aa-3115e1b27255	closed	0.03	2025-08-31 14:38:00.006231	2025-08-31 17:43:00.45289
9137991a-9848-4502-ac01-177b21f97ca1	open	2.72	2025-08-31 18:27:54.858846	\N
8f85521a-e708-4841-9743-6b6068cbeadd	closed	3.26	2025-08-31 14:43:00.449546	2025-08-31 17:48:36.131083
e3a1dfe3-362f-4943-a0df-d555565e41dd	closed	3.87	2025-08-31 18:22:12.470844	2025-08-31 21:27:54.861628
a19fbdb0-d05c-4732-98b8-cd7e433966be	closed	0.33	2025-08-31 14:48:36.128182	2025-08-31 17:53:39.770136
7feab151-92e7-4ced-877a-046c39f56127	closed	1.96	2025-08-31 14:53:39.762365	2025-08-31 17:59:00.768791
02a40a38-7cee-4cd1-81e7-d8185d170514	closed	2.02	2025-09-02 06:35:25.329532	2025-09-02 09:40:47.458297
3965a1d9-ce60-4751-bce0-9c8e183ed916	closed	4.12	2025-08-31 14:59:00.765507	2025-08-31 18:04:45.626758
f78152b1-0968-4618-891e-4ea9880043a8	open	0.59	2025-08-31 18:38:09.258185	\N
da33a84b-94c6-445e-9be8-935092a5cf50	closed	2.93	2025-08-31 15:04:45.619111	2025-08-31 18:10:17.484685
45121bee-5bdf-4a4c-b734-0b734f414b4a	closed	3.00	2025-08-31 18:32:37.002063	2025-08-31 21:38:09.261564
8f2a5b26-bfec-4455-aea8-99977c46682a	closed	4.67	2025-08-31 15:10:17.481844	2025-08-31 18:16:08.705814
c7feb426-7870-43c3-a2af-b6451d4d0ae5	open	0.34	2025-08-31 18:39:14.001906	\N
ecfd3289-5cdd-4fee-a50b-7f965af81983	closed	2.66	2025-08-31 15:16:08.702488	2025-08-31 18:21:37.496272
305cc1f4-e0fb-4e4f-9f17-04a8bd8755ff	open	1.36	2025-08-31 18:41:52.001137	\N
9dc41a79-aa7c-40d5-856d-20d65d3a70b5	closed	0.29	2025-08-31 15:21:37.493007	2025-08-31 18:26:40.329927
d74ab9c2-627d-4eea-8d73-4d00199de995	closed	0.31	2025-08-31 15:26:40.322081	2025-08-31 18:31:43.551076
8b662af3-8d58-401f-82e2-80f12ec083da	open	0.32	2025-08-31 20:26:04.212771	\N
204c6595-5d6b-4e87-847a-270b2cadda3f	closed	4.04	2025-08-31 15:31:43.547652	2025-08-31 18:37:27.744327
232fdf90-f1be-490e-adcc-ad255da25971	open	0.51	2025-08-31 18:48:30.927936	\N
612d49ca-b6d4-4411-8b17-48e09ab7182b	closed	4.77	2025-08-31 15:37:27.739852	2025-08-31 18:43:19.804748
eb3b2c64-a652-4672-a958-6810a342450c	closed	1.16	2025-08-31 18:43:19.001786	2025-08-31 21:48:30.930424
b29a44c1-15b9-411a-b213-464536e51fd0	closed	2.99	2025-08-31 15:43:19.801697	2025-08-31 18:48:52.152517
bc84044a-431e-460c-9600-c42d0302a9e8	closed	4.40	2025-08-31 15:48:52.149392	2025-08-31 18:54:40.714932
48b04e39-2ed0-4a2a-90fa-c6c06f61afad	closed	3.72	2025-08-31 20:20:23.373949	2025-08-31 23:26:04.218351
8e517b55-dfda-4099-9e85-9cea0d3cf79b	closed	1.72	2025-08-31 15:54:40.711846	2025-08-31 18:59:59.119448
9947e389-26e9-4209-935b-f80fe91ba02a	open	1.70	2025-08-31 18:54:19.774472	\N
8969b362-a7d0-4dcd-9096-5e240d50d089	closed	0.05	2025-08-31 15:59:59.116692	2025-08-31 19:04:59.672673
574cb098-ac0f-41a8-a471-30c7eca489e3	closed	0.15	2025-08-31 18:49:19.00159	2025-08-31 21:54:19.778414
d5ee17a1-db1c-46da-bffe-d704dafb366e	closed	3.30	2025-08-31 16:04:59.669441	2025-08-31 19:10:35.5679
854d3432-07de-4c3c-8ee2-a210b09ca733	closed	3.23	2025-08-31 16:10:35.564804	2025-08-31 19:16:10.797626
d5809e2f-eb35-41cd-8149-2149d78cffe9	closed	2.07	2025-08-31 16:16:10.794595	2025-08-31 19:21:32.983609
a55406be-e440-4c6e-9c1c-9931db392407	closed	0.63	2025-08-31 16:21:32.980468	2025-08-31 19:26:39.078819
30347d1f-1d7d-4a45-9b81-8c3fe3e4ec29	closed	0.39	2025-08-31 18:55:07.001462	2025-08-31 22:00:10.431739
9880824e-fd7a-4525-a0cc-b5fd702493e5	closed	0.68	2025-08-31 16:26:39.07567	2025-08-31 19:31:46.634885
edf83437-cbe6-4c34-ad5d-9f6b92dc67af	closed	0.40	2025-09-02 07:06:41.775218	2025-09-02 10:11:45.539147
67e7196d-254f-4344-8840-6585fe3b3a30	closed	0.31	2025-08-31 16:31:46.62731	2025-08-31 19:36:49.551775
e9bf05a7-bf4e-44c1-b735-353c61030c0a	open	1.30	2025-08-31 19:06:03.029442	\N
14b4fa13-e886-4327-9d3b-2b9efbee6b04	closed	3.36	2025-08-31 16:36:49.547943	2025-08-31 19:42:26.236341
575a3289-fe7a-4058-886c-19c0e1469037	closed	4.79	2025-08-31 19:00:10.428259	2025-08-31 22:06:03.030435
4c876fcf-97dd-487e-81ab-471ca14efc25	closed	0.19	2025-08-31 16:42:26.232753	2025-08-31 19:47:28.219657
c0069fe3-00bf-4405-93b9-bfb5b9bbbeb0	in_progress	3.93	2025-08-31 16:47:28.216376	\N
849dbb8f-12ca-491f-9135-4d6e91a2fc85	open	1.83	2025-08-31 19:06:53.000939	\N
f28898b4-d6eb-4b7a-86f8-06cc9bf35b80	closed	0.10	2025-08-31 17:30:32.001148	2025-08-31 20:35:32.227654
78df74ab-34fb-4060-8917-af3479970a37	closed	3.53	2025-08-31 17:35:32.224152	2025-08-31 20:41:11.116353
7a013a11-6d5d-4829-be03-9555dcaae010	open	0.61	2025-08-31 20:33:51.725057	\N
2e4cc380-bbc6-491f-b9a6-da590ca59d77	closed	0.03	2025-08-31 17:41:11.113391	2025-08-31 20:46:11.450983
a6d5c93d-89e6-4d1b-94a9-d03e5c9373fb	open	0.58	2025-08-31 17:51:51.321366	\N
8d1f0594-ad8e-404a-895c-f8e475d7b401	closed	3.64	2025-08-31 17:46:11.448128	2025-08-31 20:51:51.323032
ac6068ae-c4a4-4383-aa0d-7806487350b3	closed	0.53	2025-08-31 19:07:30.001615	2025-08-31 22:12:34.976164
4386fdd3-2097-4f67-8485-b4e33f4b6f4d	closed	0.10	2025-08-31 17:54:53.001131	2025-08-31 20:59:53.237032
5fb552dc-c261-408b-83d4-f2a3ab29e5d5	closed	4.13	2025-08-31 20:28:06.001868	2025-08-31 23:33:51.727468
8cb15df6-6bbc-46e7-a5ff-ecba2032dcc0	closed	1.69	2025-08-31 17:59:53.234082	2025-08-31 21:05:11.796809
2751b529-c884-44e3-89f1-fe0e45769e02	open	3.07	2025-08-31 18:10:39.503798	\N
f1af7e44-ccbe-49f2-bced-993a1c3b3264	closed	2.57	2025-08-31 18:05:11.793187	2025-08-31 21:10:39.506213
a9d54194-1964-4f6a-9d87-d2f9279002ec	closed	1.84	2025-08-31 19:12:34.971737	2025-08-31 22:17:54.437237
9c83834c-1248-4daa-80c7-a4835101534b	closed	1.10	2025-08-31 18:11:28.000967	2025-08-31 21:16:39.269587
3fb9d644-4348-4ea2-ab63-177ccdada795	open	0.13	2025-08-31 19:23:43.824837	\N
1fc3084a-0f12-4be4-8b5c-8552bee7c845	closed	4.50	2025-08-31 19:17:54.436512	2025-08-31 22:23:43.828384
716b67f2-40d0-4452-affa-b0d66a09cdfb	open	1.54	2025-08-31 20:43:45.386342	\N
ae9c745d-c29d-45e0-a3ca-d940da4e7ef0	closed	1.26	2025-08-31 19:25:55.001896	2025-08-31 22:31:08.039025
e8c3ed3a-a95d-4762-ac0e-f50d12fb5bee	closed	2.74	2025-08-31 20:38:16.00156	2025-08-31 23:43:45.389374
c0c13c4b-1084-45df-a079-e13e7bf822d5	open	4.27	2025-08-31 19:36:12.764009	\N
9bf92508-8639-400f-86e3-289add30b2fa	closed	0.42	2025-08-31 19:31:08.036666	2025-08-31 22:36:12.768919
9ccc2bb5-cc8b-4305-904f-ddf969aa75c1	open	2.25	2025-08-31 19:46:11.779833	\N
69caaa06-f165-4b2b-b5d4-16f58e297277	closed	1.69	2025-08-31 19:40:53.00441	2025-08-31 22:46:11.783702
34e264f7-4d4e-48f6-ab35-88063782a588	closed	0.65	2025-09-02 06:40:47.450337	2025-09-02 09:45:54.311786
804ef6cb-ebcb-4192-8600-95f63fa905eb	closed	9.19	2025-08-31 19:47:38.002103	2025-08-31 22:54:19.641397
ed358d1d-9f4f-4067-a60d-db905ebdf5f1	closed	1.04	2025-08-31 19:54:19.636046	2025-08-31 22:59:30.612599
fd38d5f7-5639-45af-92d6-d3eac3877e7c	closed	0.46	2025-08-31 20:47:29.001746	2025-08-31 23:52:33.201764
992004d9-2875-4ac9-b997-52a30923dfae	closed	1.25	2025-08-31 19:59:30.605211	2025-08-31 23:04:43.923482
b6500a34-e043-461f-8981-c889754e047f	in_progress	4.83	2025-08-31 20:04:43.920619	\N
11bf0566-2336-4b3f-8634-46baff2a8666	closed	0.10	2025-09-02 07:38:30.727084	2025-09-02 10:43:31.221535
83532170-3cc8-4d51-8c32-fddf4e6f577b	closed	1.07	2025-08-31 20:10:00.002276	2025-08-31 23:15:11.938387
fb430c73-5416-4fd2-aefe-3ef95a74c546	closed	0.60	2025-08-31 20:52:33.198311	2025-08-31 23:57:39.759882
03bca048-c04e-456d-bf64-da6b72215ca5	closed	1.31	2025-09-02 06:45:54.308418	2025-09-02 09:51:08.613315
4db7db42-5ec9-4e4d-83bd-ef84dadfde9d	open	4.67	2025-08-31 22:01:04.288574	\N
86768e74-8403-4fb1-9582-70a86b100f20	closed	3.60	2025-08-31 20:57:39.751073	2025-09-01 01:01:04.292104
e59892ef-74b6-4dc8-b0c6-204a67ec8485	closed	0.11	2025-09-02 06:25:21.00444	2025-09-02 09:30:22.337846
f4425e32-ffb7-48b3-92ab-102ccd47b419	closed	0.29	2025-09-02 06:30:22.334567	2025-09-02 09:35:25.338482
4c496d25-7610-4cd5-9604-4c2434692cdd	closed	0.08	2025-09-02 07:11:45.535872	2025-09-02 10:16:46.006454
360c410b-382a-48d8-ac62-0ac7ad9de619	closed	1.19	2025-09-02 06:51:08.61045	2025-09-02 09:56:21.266023
88a087da-a749-4471-9995-07ddbfec4264	closed	0.04	2025-09-02 06:56:21.265237	2025-09-02 10:01:21.566392
affbe835-d7ca-4962-9939-3de291b54489	closed	1.87	2025-09-02 07:01:21.564854	2025-09-02 10:06:41.778098
8c206f16-1e72-4052-84f6-7853c831352b	closed	0.05	2025-09-02 07:28:00.062055	2025-09-02 10:33:00.673621
792e1e2d-7097-4335-b41c-b67553c38983	closed	1.82	2025-09-02 07:16:46.002202	2025-09-02 10:22:06.23603
ef1cf9c3-eec2-446e-bb94-8bf5ec2e9117	closed	4.88	2025-09-02 07:22:06.233477	2025-09-02 10:28:00.065809
3219529a-5f11-4341-81d5-29ac3a08bcca	closed	2.77	2025-09-02 07:33:00.670578	2025-09-02 10:38:30.727792
e47bd0e9-3c55-4e98-8ed6-5f13e46a0c3f	open	1.16	2025-09-02 07:49:23.37969	\N
e6ed8f7e-e0f8-47ea-9a83-8520be80aed0	closed	4.73	2025-09-02 07:43:31.220004	2025-09-02 10:49:23.381526
59b1c9cf-9d39-4559-aa5d-d27456927eba	open	1.25	2025-09-02 07:56:24.001209	\N
7d4e43cf-7c4c-4d8a-9006-77e227db646e	open	0.34	2025-09-02 07:58:19.001432	\N
274e859b-7701-4520-a978-74a6a8dc0101	open	1.86	2025-09-02 08:00:29.002363	\N
e0cba753-d2f9-413c-9874-bd7eb77e5b32	closed	1.64	2025-09-02 08:01:56.003684	2025-09-02 11:07:14.247603
189aaf4c-527e-48e0-bcd8-c0af14212c33	closed	2.15	2025-09-02 08:07:14.245167	2025-09-02 11:12:37.876004
6372ba26-c19d-4853-ba06-3f0e7c1fae7b	closed	0.67	2025-09-02 08:12:37.873768	2025-09-02 11:17:44.535327
cad3716c-4b16-4d31-968b-b5fdb0aa45a0	closed	0.30	2025-09-02 08:17:44.531559	2025-09-02 11:22:47.435034
e61ac45e-f795-47b2-a82c-c3c6b4dd4ac0	closed	0.29	2025-09-02 08:22:47.432438	2025-09-02 11:27:50.324289
310546b1-b6b4-4b37-9393-4cb1911b03b8	closed	0.58	2025-09-02 08:27:50.320287	2025-09-02 11:32:56.523435
3d1902fb-8605-4ebc-a541-9f1f7f05118a	closed	2.97	2025-09-02 08:32:56.519714	2025-09-02 11:38:28.92489
b220908f-7b6c-40eb-a282-4686e7a3d559	closed	3.27	2025-09-02 08:38:28.921329	2025-09-02 11:44:04.22128
025bbd02-ec34-4599-a0ac-077886a84a9f	closed	1.30	2025-09-02 14:13:50.052314	2025-09-02 17:23:38.912553
7a89a32f-e5b8-411a-bd31-316541c7d48a	closed	0.69	2025-09-02 08:44:04.217595	2025-09-02 11:49:11.739646
17c3ac1d-cac0-46cb-9b92-b68e763c60ba	closed	2.57	2025-09-02 18:03:48.830685	2025-09-02 21:09:16.523515
a4325b6b-c523-4673-afaf-4433ab7e88f1	closed	0.82	2025-09-02 08:49:11.736835	2025-09-02 11:54:20.187523
ca05ae41-f2e6-4d74-82ad-170b148e215f	closed	1.33	2025-09-02 08:54:20.186006	2025-09-02 11:59:34.80527
abc71d9a-392f-4d48-990f-9dc580b72947	closed	3.31	2025-09-02 14:23:38.909472	2025-09-02 17:29:24.060518
be738894-745c-4b04-8681-6ec13835cf5c	closed	2.71	2025-09-02 08:59:34.801887	2025-09-02 12:05:04.035771
c8e9c577-8aae-4022-90dd-5388c9064b3a	closed	0.52	2025-09-02 09:05:04.034179	2025-09-02 12:10:09.858518
3689e16b-e92f-47af-9bfe-1cd02bc2f89f	closed	3.38	2025-09-02 09:10:09.855255	2025-09-02 12:15:46.451723
c414e8bc-5726-4ccf-bf3a-f9be8536398d	closed	2.37	2025-09-02 14:29:24.059268	2025-09-02 17:34:50.304551
76852c4a-fa6c-4c54-9fbe-53324f4e0b26	closed	1.78	2025-09-02 09:15:46.427717	2025-09-02 12:21:05.774958
f4aa80ab-72f0-4d3e-906d-584fb6a43c27	closed	2.68	2025-09-02 20:45:25.001985	2025-09-02 23:50:54.712859
89733716-86f5-4ec2-8cd9-f6b56fe36510	closed	0.22	2025-09-02 09:21:05.772711	2025-09-02 12:26:07.55056
7c7045d6-206b-44e3-b2ab-dbb8fae4b65a	closed	6.67	2025-09-02 09:26:07.549372	2025-09-02 12:32:20.785316
202eaefd-a89c-4ff5-8b63-08919e2f0614	closed	1.44	2025-09-02 14:34:50.300419	2025-09-02 17:40:07.458688
19376f2d-919b-463c-ac39-f11c9263374b	closed	3.64	2025-09-02 09:32:20.782909	2025-09-02 12:38:00.323474
ef162db3-816b-4b88-be8a-e739d75f98bb	open	1.54	2025-09-02 19:34:17.919696	\N
a3713ddd-9e57-44ab-b56e-57917367a64f	closed	4.04	2025-09-02 09:38:00.320118	2025-09-02 12:43:44.73445
2880b5c4-8ea9-49b4-9575-626efb9309b3	closed	3.82	2025-09-02 09:43:44.730767	2025-09-02 12:49:26.317906
f9c3bb3c-dfeb-49d5-ae2b-ff2737eea631	closed	1.64	2025-09-02 14:40:07.455155	2025-09-02 18:00:27.63228
2c5e48fd-79b6-4623-8e6e-c2d4a91e6163	closed	1.35	2025-09-02 09:49:26.310406	2025-09-02 12:54:41.036983
2ab3a47e-ee19-4414-bc67-e0265bd32517	closed	1.34	2025-09-02 19:29:03.004521	2025-09-02 22:34:17.922231
fbbc3dbb-8b64-4e53-94b2-4d23c71338a0	closed	0.78	2025-09-02 09:54:41.029807	2025-09-02 12:59:49.739366
315f5bda-b4b6-4721-8e56-8e353279a960	closed	3.09	2025-09-02 09:59:49.736734	2025-09-02 13:05:23.252032
bd2e006e-3d0f-4800-8691-9e50134906b4	closed	0.23	2025-09-02 15:00:27.628795	2025-09-02 18:23:36.276167
ffce114c-501b-4bd0-82f5-c2677530f382	closed	3.30	2025-09-02 10:05:23.24704	2025-09-02 13:10:59.549859
60d0765a-76d0-4a06-bc2b-5d473efb2352	closed	0.76	2025-09-02 10:10:59.546531	2025-09-02 13:16:07.518573
ffcae259-b145-42aa-ac44-c4e7de72f7e2	closed	0.07	2025-09-02 10:16:07.517173	2025-09-02 13:21:07.893334
865f867d-7891-4268-bfb5-10b85231f7d2	closed	1.69	2025-09-02 15:23:36.272501	2025-09-02 18:28:58.209671
12ab20fc-d076-49ec-8ed4-883c3914b4e7	closed	0.97	2025-09-02 10:21:07.890222	2025-09-02 13:26:17.821732
5c6473a2-4ccb-4d3a-a42b-fc25a70b8c9f	closed	3.44	2025-09-02 21:22:19.615924	2025-09-03 00:27:57.128987
f1703d16-f128-4bc4-82df-9eb222ad80fb	closed	4.74	2025-09-02 10:26:17.821118	2025-09-02 13:32:09.448242
64d80d1d-b222-4865-a796-fff79865011c	closed	0.05	2025-09-02 10:32:09.446557	2025-09-02 13:37:09.671386
f176f28c-2271-4eca-befc-617d5c770873	closed	0.43	2025-09-02 15:28:58.200458	2025-09-02 18:36:34.35937
2fa03289-e017-4dc6-89f9-fb9a3daafae0	closed	1.95	2025-09-02 10:37:09.668291	2025-09-02 13:42:30.650396
5d80d88e-023b-4605-a361-4d01b4c0f161	closed	1.44	2025-09-02 10:42:30.648103	2025-09-02 13:47:46.020305
a759aa42-7524-4f4f-8fbf-8a6743865c7e	closed	4.90	2025-09-02 10:47:46.017312	2025-09-02 13:53:40.236365
2bed0379-f5f5-4987-bf0c-6088e72927ca	closed	0.69	2025-09-02 15:36:34.355522	2025-09-02 18:42:27.472053
68218d65-40d4-49e0-93af-9737c55e3f40	closed	3.53	2025-09-02 10:53:40.234998	2025-09-02 13:59:19.112002
b76d1ed8-b6fb-477b-9d7c-878828e84ef8	closed	1.38	2025-09-02 19:36:36.00145	2025-09-02 22:41:50.349621
d7db814e-971d-40e4-9650-df0f5ba94fbe	closed	1.21	2025-09-02 10:59:19.108879	2025-09-02 14:04:32.483548
0bf37eea-02a2-40a1-bafb-55c2f8c9934e	closed	0.85	2025-09-02 11:04:32.482475	2025-09-02 14:09:41.514192
c0ff459e-276a-4df0-979b-8d30d72b0c80	closed	4.31	2025-09-02 15:42:27.468998	2025-09-02 18:51:02.027016
2e4c8d57-fa07-4f76-ad3e-c85dcb1634d4	closed	0.42	2025-09-02 11:09:41.510002	2025-09-02 14:14:45.760863
f798f0e0-02af-4ec5-86a5-7cf69568caa6	closed	0.28	2025-09-02 11:14:45.757057	2025-09-02 14:19:48.214938
36142841-b00b-4b26-b77e-a9fa72e4e3f1	closed	0.94	2025-09-02 11:19:48.21119	2025-09-02 14:24:58.50342
4c647363-ad93-453b-9661-f0906c876cc5	closed	1.16	2025-09-02 15:51:02.025576	2025-09-02 19:04:35.250251
07137b26-d5f9-4d5b-b134-796423102e62	open	0.61	2025-09-02 11:30:33.902067	\N
5ef2b73e-47c4-4af3-a694-cb7e2b41a034	closed	3.24	2025-09-02 11:24:58.499219	2025-09-02 14:30:33.90568
5a9d806a-f156-4f84-82af-24aa2058be2b	closed	0.22	2025-09-02 13:57:36.002085	2025-09-02 17:02:38.202183
9391c153-bf54-49b4-b3c2-f813256f85ad	closed	1.79	2025-09-02 14:02:38.183646	2025-09-02 17:07:57.917132
86e8b766-1960-4f92-87ba-19c499a10f75	closed	0.07	2025-09-02 16:04:35.245594	2025-09-02 19:11:28.488107
2969809b-0e70-4c0a-aaa8-ec9ab9a04dc3	closed	4.79	2025-09-02 14:07:57.91503	2025-09-02 17:13:50.056516
da6cd831-6050-467c-add6-e3950f93288e	closed	1.34	2025-09-02 19:41:50.348147	2025-09-02 22:47:04.926163
e074bc95-05b3-48d6-ba42-24c33300871d	closed	0.64	2025-09-02 20:50:54.708156	2025-09-02 23:56:01.205328
7c859258-32d0-4bb3-9dc9-030acfb77f15	closed	0.82	2025-09-02 16:11:28.487371	2025-09-02 19:28:27.822667
60a1f795-8546-41c9-b076-eb93c16bcc73	closed	1.99	2025-09-02 16:28:27.81928	2025-09-02 19:56:04.500674
e813d136-a723-4aa2-a3c6-096c2f20d0cb	closed	0.34	2025-09-02 19:47:04.924113	2025-09-02 22:52:07.870419
cec6838a-479b-4ba7-b050-b36a42805e6a	closed	4.79	2025-09-02 16:56:04.4988	2025-09-02 20:32:13.791856
c2cc4d46-89bd-4d4f-9c99-30d528bad4b2	closed	0.75	2025-09-02 21:54:17.001076	2025-09-03 00:59:24.40548
8f38bd9e-031b-4906-9489-e1ddf8cd3a37	closed	0.22	2025-09-02 17:32:13.789072	2025-09-02 20:37:15.564366
d5e88664-9add-4af0-8309-5da008b89c27	closed	0.30	2025-09-02 17:37:15.556076	2025-09-02 20:42:18.437799
880e7324-2c70-4be5-91fa-b9a7f5b8be38	closed	0.65	2025-09-02 19:52:07.869073	2025-09-02 22:57:14.299423
9932629c-97ca-47d1-8bc3-1f2447e158ca	closed	4.39	2025-09-02 17:42:18.434348	2025-09-02 20:48:06.636955
28f9ac85-84b5-49b0-8156-080913854d29	open	1.41	2025-09-02 17:53:06.228968	\N
2788fada-3f29-4df7-b7af-1a37b5274287	closed	0.01	2025-09-02 17:48:06.632725	2025-09-02 20:53:06.229989
70f6a8c1-4d06-406b-a697-b6d5aaf0bda0	closed	0.07	2025-09-02 17:53:17.001971	2025-09-02 20:58:16.897842
ff8deb37-4d33-49e4-bdfd-0bde68574c03	closed	3.15	2025-09-02 19:57:14.293975	2025-09-02 23:02:48.927999
cd28c904-9c7c-40eb-8474-5fceb4156953	closed	2.96	2025-09-02 17:58:16.894823	2025-09-02 21:03:48.83435
2ebf40fe-012b-4224-b0f4-820f4d324091	closed	3.19	2025-09-02 20:56:01.201484	2025-09-03 00:01:36.732448
64a494ff-3d9b-4345-99e5-05d1ee9bace9	open	1.45	2025-09-02 18:09:16.520098	\N
6b115355-4aa3-402d-9ea7-946098eac25b	open	0.08	2025-09-02 20:08:22.245255	\N
06cbd650-50a7-48cc-bcc0-5129a3d46c77	closed	3.09	2025-09-02 20:02:48.926085	2025-09-02 23:08:22.249156
d8241045-2f8e-4c64-89d1-8d20343af9a3	open	4.14	2025-09-02 20:17:36.8866	\N
d2012ed6-4ed2-4f45-a104-f433bd8ecfad	closed	1.06	2025-09-02 20:12:25.001821	2025-09-02 23:17:36.888203
39ef9c00-e6bd-4201-b29e-2f86a33529f4	closed	0.32	2025-09-02 21:01:36.729878	2025-09-03 00:06:39.658563
63e17275-02a7-491d-a3cb-acaa31505fb5	closed	0.04	2025-09-02 20:18:20.00218	2025-09-02 23:23:20.579467
9c5ae52a-e6c2-488f-b977-441d5903b1ba	closed	1.75	2025-09-02 21:27:57.127822	2025-09-03 00:33:16.446734
dc6ccc6e-0d02-4d2a-88ec-4886c408a37a	open	2.20	2025-09-02 20:28:38.454703	\N
70b6e95b-0798-436f-9722-d367b2952627	closed	1.38	2025-09-02 20:23:20.577841	2025-09-02 23:28:38.468426
84921833-bef1-44c5-b3d4-e2982033f25d	closed	4.66	2025-09-02 22:22:07.651423	2025-09-03 01:27:58.57479
c15cea9d-6b9f-4705-aa59-ddf55053792d	closed	1.27	2025-09-02 21:06:39.653594	2025-09-03 00:11:53.141689
4c08264b-f2ca-49a5-9fab-9850b2e732b4	closed	1.46	2025-09-02 21:11:53.138051	2025-09-03 00:17:09.252293
20aafd1a-299b-4661-8326-18ff07ac4a2d	closed	4.74	2025-09-02 21:33:16.444525	2025-09-03 00:39:08.498247
c5c35414-0634-423d-9f76-fee05c73789b	closed	0.95	2025-09-02 21:17:09.249287	2025-09-03 00:22:19.619474
f02aa510-e720-499a-974a-10239946bd63	closed	0.38	2025-09-02 21:59:24.402635	2025-09-03 01:04:28.327122
cbf182ae-33a5-4dc3-8903-f81acaa9018f	open	0.95	2025-09-02 21:44:53.199862	\N
2ed45a7c-3a3d-4426-8931-75c114b888f9	closed	4.08	2025-09-02 21:39:08.496271	2025-09-03 00:44:53.208373
fe00a098-710f-46f5-b97a-aa5480dee514	closed	0.59	2025-09-02 22:17:02.001515	2025-09-03 01:22:07.653748
af3280de-675a-4c56-879a-ee889a3db24e	open	3.76	2025-09-02 22:10:17.928447	\N
5b9fada3-b6f0-4ae9-8fc9-ff1acf26a5be	closed	4.51	2025-09-02 22:04:28.324643	2025-09-03 01:10:17.929852
f83fbf46-5526-4843-9e5b-9ac9c1da48d2	closed	3.17	2025-09-02 22:27:58.572856	2025-09-03 01:33:33.184247
85bd76eb-1e95-4962-ab45-264e154f90c7	in_progress	4.76	2025-09-02 23:10:33.711778	\N
82e9f0c7-8237-4291-9d79-62538c059d2d	closed	0.22	2025-09-02 22:33:33.17616	2025-09-03 01:38:35.568914
0e6a678a-31af-48e2-9371-57c0087366ac	closed	0.24	2025-09-02 22:38:35.566003	2025-09-03 01:43:37.790452
3453cbf7-015b-4b62-af8b-f93ef5c24ee1	closed	0.12	2025-09-02 22:43:37.787735	2025-09-03 01:48:38.462892
e1adcf6c-79dc-4ae8-b0e6-4739c36fb716	closed	0.08	2025-09-02 22:48:38.46071	2025-09-03 01:53:39.018498
a2df0fa4-2496-409c-bafa-450ba85772de	closed	4.08	2025-09-02 22:53:39.016474	2025-09-03 01:59:24.216521
4bc7fe42-266c-4a70-b1b7-981558be0f9b	closed	4.66	2025-09-02 22:59:24.203515	2025-09-03 02:05:15.614459
e81751d8-0d2c-4f34-820d-2900f6353714	closed	1.68	2025-09-02 23:05:15.605397	2025-09-03 02:10:33.719416
bdc84240-2bf8-47f1-b278-0687a46d3dab	open	1.29	2025-09-02 23:22:06.003729	\N
c9c5edd9-c194-4271-b8be-26a5773b9d94	open	0.94	2025-09-02 23:25:38.000921	\N
e51be5da-7eb5-4952-a975-071a2398d65d	closed	1.74	2025-09-03 18:27:19.004079	2025-09-03 21:32:38.344802
bafd7537-7cf2-4771-85b8-d855002db8a2	closed	3.78	2025-09-03 18:32:38.342865	2025-09-03 21:38:19.875449
b9723408-b40b-4423-b200-825e8bbe45db	closed	0.42	2025-09-03 18:43:28.503174	2025-09-03 21:48:32.758514
51eb80c7-1405-449f-b57a-5b094fb92789	closed	0.33	2025-09-03 18:48:32.754813	2025-09-03 21:53:35.765386
640befa5-19f4-468d-89f4-6d93611ce504	closed	1.67	2025-09-04 14:49:45.945096	2025-09-04 17:55:03.578455
2cf97e23-a16a-43ed-9047-7cf149934c1d	closed	0.85	2025-09-03 18:38:19.871461	2025-09-03 21:43:28.506413
ca4d6395-d03c-466b-9d14-d6b4965a8e36	closed	0.31	2025-09-03 18:53:35.761709	2025-09-03 21:58:38.543858
d03dff6b-f34f-4460-8a74-e572bd57bed4	closed	2.96	2025-09-03 22:04:18.727999	2025-09-04 01:09:50.825621
faadfb79-8f0f-48a9-a7a6-914a9ef229f9	closed	0.48	2025-09-03 18:58:38.540159	2025-09-03 22:03:43.420174
7e775283-379d-4faf-b95b-1f539c0b8f2d	closed	0.36	2025-09-03 19:03:43.416857	2025-09-03 22:08:47.097998
08ff347c-3491-4a52-9374-7357484ec922	closed	1.53	2025-09-03 19:08:47.094788	2025-09-03 22:14:04.003493
97691a57-2058-408a-829d-27b3bdb0f6ed	closed	1.52	2025-09-03 22:09:50.822641	2025-09-04 01:15:06.901623
fe1fd74c-3142-4ed2-9f61-67e585445842	closed	0.92	2025-09-03 19:14:04.000552	2025-09-03 22:19:13.275043
18f5fffc-4a18-4703-9c2c-82371bbd35df	closed	0.63	2025-09-04 00:05:41.724782	2025-09-04 03:10:48.07902
33ad12fe-f462-4f11-8588-5ed5bf1fe254	closed	0.04	2025-09-03 19:19:13.271386	2025-09-03 22:24:13.564996
1b5b1955-0ad7-4aec-8e03-1661da33f5c1	closed	1.63	2025-09-03 19:24:13.560586	2025-09-03 22:29:31.122337
6ff19090-e840-4a68-ac63-3ffc42566284	closed	4.46	2025-09-03 22:15:06.899306	2025-09-04 01:20:55.372745
a8ed9024-1cdb-45e4-9b07-2e02678ea208	closed	2.11	2025-09-03 19:29:31.119233	2025-09-03 22:34:54.425141
873e4b3c-37ca-459d-abdc-9b5d8657fed9	closed	0.10	2025-09-04 15:16:06.442943	2025-09-04 18:21:07.22368
6ebf80ba-e8c0-4817-a021-8583c7fb7706	closed	0.95	2025-09-03 19:34:54.417196	2025-09-03 22:40:04.609815
5b9cc0ac-cd13-4b4d-82db-8106c3f27e85	open	0.32	2025-09-03 22:26:13.774342	\N
3eaeb634-4283-4bcd-befe-8d5cd7a111db	closed	2.60	2025-09-03 19:40:04.606422	2025-09-03 22:45:32.844635
85fffae7-f503-47f1-b810-1f165b7ec589	closed	1.69	2025-09-03 22:20:55.370547	2025-09-04 01:26:13.776799
9e3880e5-a019-4a68-99cf-ff53db15b41c	closed	4.79	2025-09-03 19:45:32.842104	2025-09-03 22:51:25.015846
f15f380d-aaed-417c-ae1c-a39609a0eb17	closed	1.08	2025-09-03 19:51:25.013001	2025-09-03 22:56:37.05093
b3e63b8c-e16f-496c-9a03-408cadbc760c	closed	1.45	2025-09-03 19:56:37.048959	2025-09-03 23:01:53.137189
79283bdd-ceaf-4419-aaea-a2e197effebe	closed	4.04	2025-09-03 20:01:53.136234	2025-09-03 23:07:37.743684
5f698de3-9b00-43c7-b982-0ec0e151e0b4	closed	0.66	2025-09-03 22:29:40.002322	2025-09-04 01:34:47.414223
9397a813-3ad9-4aaa-96a3-02aedf4fa559	closed	0.74	2025-09-03 20:07:37.740616	2025-09-03 23:12:45.288186
003fc0ff-8809-42bf-8a80-b043517a5561	closed	4.81	2025-09-04 00:10:48.075439	2025-09-04 03:16:41.256719
5fffc5d8-93f3-4b88-9cae-43b50bb121f9	closed	4.03	2025-09-03 20:12:45.286192	2025-09-03 23:18:29.632107
91790d7d-70cd-4a0c-9fbf-aab66d32044b	closed	1.85	2025-09-03 20:18:29.628883	2025-09-03 23:23:49.540837
128af679-b4be-46b6-a21c-0602b40c5847	closed	1.72	2025-09-03 22:34:47.410838	2025-09-04 01:40:06.112363
7c8d8a86-9327-4065-9203-15df354e4790	closed	0.04	2025-09-03 20:23:49.537511	2025-09-03 23:28:49.56209
b63a1434-a7b1-4370-8ad4-b78a5d5aa6d1	closed	0.75	2025-09-03 20:28:49.55827	2025-09-03 23:33:57.397778
3338ebd5-bf0f-479b-b97b-ac6e1c5ec7cb	open	1.58	2025-09-03 22:45:17.719721	\N
e208589c-4325-4e41-b75e-1bbec1d1fffc	closed	4.16	2025-09-03 20:33:57.393481	2025-09-03 23:39:43.042769
bfaf9300-2b3f-4759-b315-52e8aae5278b	closed	1.05	2025-09-03 22:40:06.108736	2025-09-04 01:45:17.723218
f67bc3f1-9c4c-4e03-85a3-da1726fc292d	closed	2.46	2025-09-03 20:39:43.039616	2025-09-03 23:45:10.264675
e4d45ccd-d929-4009-baae-2fef5e230e1e	open	0.58	2025-09-03 22:49:44.002266	\N
85b21611-b0e5-4d77-937d-806e0e2c9187	closed	4.04	2025-09-03 20:45:10.261797	2025-09-03 23:50:54.735627
af764746-e47a-4c5a-8de3-002d7c182dbf	open	0.52	2025-09-03 20:56:20.28724	\N
02a13f23-4bb8-4b33-b8d9-93a9932b2fec	closed	2.37	2025-09-03 20:50:54.731935	2025-09-03 23:56:20.289207
5e9c29ae-2afe-449d-bda1-8fb1c6d56818	closed	0.68	2025-09-03 20:59:05.001728	2025-09-04 00:04:11.634735
d1618446-d8df-4c43-b320-a2641b9823a3	closed	4.52	2025-09-03 21:04:11.63059	2025-09-04 00:10:01.026686
b26a8221-d920-4de6-b67b-1bd6d5154b6e	closed	0.07	2025-09-03 22:50:54.002117	2025-09-04 01:55:54.892268
becaabdb-6e1a-4248-9d2b-3bcf1d987e21	open	0.20	2025-09-03 21:15:01.668152	\N
23c9f790-7dfd-4b5d-af37-b165cf172a14	closed	0.05	2025-09-03 21:10:01.025986	2025-09-04 00:15:01.669077
0245456f-21fe-4dee-ab3d-1f25f2f97091	open	0.22	2025-09-03 21:16:59.002038	\N
a2e2da56-1a6d-4a7a-98e1-bc7f2c834ee0	closed	1.68	2025-09-04 00:16:41.253283	2025-09-04 03:21:59.670884
14f6ce7c-d64c-450e-af74-6060e18cd488	closed	1.22	2025-09-03 21:19:02.007725	2025-09-04 00:24:15.596285
a19c1cf4-2bac-4dfe-a17c-6f8e3186b81c	closed	4.95	2025-09-03 21:24:15.593529	2025-09-04 00:30:09.767654
22eace4f-2a77-4780-ab30-fcd1139dfc5f	closed	1.29	2025-09-03 22:55:54.888248	2025-09-04 02:01:08.376949
15e7a212-3755-4dab-8842-67675f97ab45	closed	1.34	2025-09-03 21:30:09.764523	2025-09-04 00:35:23.908776
9d5ce0ad-504c-48b2-b311-8d8438292bf4	closed	4.52	2025-09-04 14:55:03.576319	2025-09-04 18:00:53.046351
5c32c5bb-a8da-42aa-84ad-c09bc098db7b	open	0.33	2025-09-03 21:40:28.195291	\N
57d09d6a-8aff-454f-b9e2-d4a80aa70ddc	closed	0.46	2025-09-03 21:35:23.904939	2025-09-04 00:40:28.197614
53653d68-b8f8-4544-88db-c0d3fb031a1a	open	0.04	2025-09-03 21:50:40.000512	\N
ea150722-d468-419b-8feb-041214a1f7e4	open	0.36	2025-09-03 23:06:22.703403	\N
5b0b608e-9dbd-4db1-9010-820a393f322c	closed	1.38	2025-09-03 21:53:56.001926	2025-09-04 00:59:10.356954
3b24fca8-6f29-45d8-8785-f4d521d0792b	closed	1.32	2025-09-03 23:01:08.373914	2025-09-04 02:06:22.708513
95a69ac9-58f8-4731-9c7a-48fb6cba09ad	closed	0.78	2025-09-03 21:59:10.35542	2025-09-04 01:04:18.73079
76b73703-99b2-47b9-8af9-e04486e1e0a0	open	4.55	2025-09-04 00:26:59.334338	\N
11173da0-d533-4fe1-808b-431926d79a58	open	1.29	2025-09-03 23:16:27.212333	\N
adfe01ec-9aec-4608-bd5e-0c0cf2160b36	closed	0.19	2025-09-03 23:11:25.003592	2025-09-04 02:16:27.214828
fe38ac4d-bef7-4fbd-b932-6a493da750dc	open	1.86	2025-09-03 23:17:18.00238	\N
ce647d9c-7f97-4a04-a5cb-231fa425cd63	open	1.12	2025-09-03 23:20:44.001665	\N
145dbb37-7071-4a66-8bdb-bf96de0bac2d	open	1.87	2025-09-03 23:21:47.002822	\N
60281666-9cd8-45cb-a43b-a39ef6bfb251	open	1.58	2025-09-03 23:24:29.001227	\N
b421a156-9075-48a8-a362-659afc4bf7b9	open	7.19	2025-09-03 23:26:13.00201	\N
bd40fc0e-c3bf-4823-9419-9ffd6e9bba76	open	0.81	2025-09-03 23:29:00.002151	\N
95974856-39c5-4eca-9860-9f1bcd2eedfb	open	0.89	2025-09-03 23:29:34.001807	\N
d625ea28-2005-4c07-b923-0074f2c11c10	open	1.29	2025-09-03 23:33:38.001875	\N
77e84154-7dfc-451a-b7df-69f95d6e1c49	open	1.28	2025-09-03 23:35:57.001539	\N
21a93c01-f46a-4005-9143-89cad1ab63bb	open	0.68	2025-09-03 23:39:00.001906	\N
8c65b344-a667-4a8a-bab9-4f0365605ac0	open	0.22	2025-09-03 23:43:02.001779	\N
f3b6c452-ee87-4e63-90a1-a383e72220fe	open	0.12	2025-09-03 23:43:20.002088	\N
6d0d62b9-2df1-4e16-9169-f978332880c9	open	1.42	2025-09-03 23:45:23.001772	\N
b415c86a-fb96-4669-8938-05dfe9a902b7	open	1.06	2025-09-03 23:46:04.001755	\N
1f96eea8-8145-4ebd-af36-3d950ceeab01	open	1.91	2025-09-03 23:46:47.001993	\N
b3ece324-3843-4630-81c1-b56da33660d8	open	0.04	2025-09-03 23:47:51.001971	\N
0990d3fd-46fe-4456-8a05-8af1346bd262	closed	0.02	2025-09-04 00:21:59.669692	2025-09-04 03:26:59.335231
2d36fe1e-f9be-4148-95e0-de3dedb5c405	open	1.24	2025-09-03 23:53:54.215361	\N
befc7490-679d-40da-a79d-c81c9662c484	closed	0.19	2025-09-03 23:48:53.001999	2025-09-04 02:53:54.217552
db8f878d-89bc-4f06-bde5-b8e7cfd6eb92	open	1.40	2025-09-03 23:58:36.002541	\N
44c81701-b64f-403a-9cdb-9ddf19f893ed	open	0.96	2025-09-04 13:56:38.00154	\N
006504ef-ad5a-4ddd-a8e3-4d9f7be58237	closed	1.05	2025-09-04 00:00:31.000929	2025-09-04 03:05:41.727733
648f0bed-91ae-4efc-a911-350823d8a26f	closed	0.31	2025-09-04 15:32:25.022196	2025-09-04 18:37:28.553518
f57e41db-be3b-4682-aac1-6d00fff6a7fa	closed	1.00	2025-09-04 14:33:46.002149	2025-09-04 17:38:56.169304
2865e5f1-5ea0-4e35-8c0a-4a4d4d737080	closed	3.48	2025-09-04 14:38:56.164705	2025-09-04 17:44:34.571316
305dc50a-ab9f-4636-84e1-d89a25443973	closed	0.99	2025-09-04 15:00:53.044873	2025-09-04 18:06:04.052444
35b1e140-9c75-48af-9a69-e266e25cd490	closed	1.07	2025-09-04 14:44:34.568634	2025-09-04 17:49:45.947106
fab36b5a-2e9f-4ead-aa25-a63e8c720c98	closed	3.95	2025-09-04 15:21:07.220856	2025-09-04 18:26:50.751329
84de9dcb-45d7-4a82-86f0-a70d32aa4bca	closed	0.09	2025-09-04 15:06:04.049652	2025-09-04 18:11:05.112318
40600f9e-51bd-4fc3-972f-a169d6908b62	closed	0.12	2025-09-04 15:11:05.110245	2025-09-04 18:16:06.446535
55c8c78d-e85c-4745-a66a-7e406b6fe144	closed	3.16	2025-09-04 15:26:50.748313	2025-09-04 18:32:25.025181
08aee46f-7fd4-421b-9d41-f94915866b78	closed	0.02	2025-09-04 15:37:28.549418	2025-09-04 18:42:28.345062
413e0e0b-2a01-4505-b023-bf80dac9e995	closed	0.19	2025-09-04 15:42:28.34051	2025-09-04 18:47:30.223669
06f1a6e5-3117-405b-ae93-850fb3b8949f	closed	2.89	2025-09-04 15:47:30.220357	2025-09-04 19:37:28.408891
e4ae7668-cce0-40b3-96e7-18ce23963566	closed	0.66	2025-09-04 16:37:28.406072	2025-09-04 19:42:35.408827
9d4e6d0f-41b2-4c2d-b436-7e840cad9b4a	closed	8.73	2025-09-04 16:42:35.40801	2025-09-04 19:49:11.558308
988289c6-14ed-45e5-bdd4-c8685257d9d9	closed	1.59	2025-09-04 16:49:11.556704	2025-09-04 19:54:28.684739
0bac3c55-20d4-4aa8-be3d-c42d523cd3ef	closed	0.85	2025-09-04 16:54:28.681357	2025-09-04 19:59:37.511238
fc3a3917-391b-4946-976d-35c0ea728723	closed	0.03	2025-09-04 16:59:37.507762	2025-09-04 20:04:37.450258
4a0f2478-ffbf-49e0-b66d-69b009589a98	closed	2.87	2025-09-04 17:04:37.447279	2025-09-04 20:10:08.847666
36b7a18a-84c0-44d0-875a-9173f54ffc17	closed	1.69	2025-09-04 17:10:08.844508	2025-09-04 20:15:26.805164
ded8ea42-dfd2-4023-8022-fb938c4b57e8	open	1.50	2025-09-04 17:20:27.106454	\N
566574f9-97d2-40ac-980d-74d027312a7a	closed	0.09	2025-09-04 17:15:26.797372	2025-09-04 20:20:27.109496
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (version, dirty) FROM stdin;
20250827104500	f
\.


--
-- Data for Name: scratch_cards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scratch_cards (id, user_id, status, bet_amount, won_status, "timestamp", won_amount) FROM stdin;
\.


--
-- Data for Name: spinning_wheel_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spinning_wheel_configs (id, name, amount, type, status, created_at, created_by, deleted_at, frequency, icon, color) FROM stdin;
\.


--
-- Data for Name: spinning_wheel_mysteries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spinning_wheel_mysteries (id, name, amount, type, status, frequency, created_at, created_by, deleted_at, icon) FROM stdin;
\.


--
-- Data for Name: spinning_wheel_rewards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spinning_wheel_rewards (id, round_id, name, amount, type, status, claim_status, transaction_id, user_id) FROM stdin;
\.


--
-- Data for Name: spinning_wheels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spinning_wheels (id, user_id, status, bet_amount, "timestamp", won_amount, won_status, type) FROM stdin;
\.


--
-- Data for Name: sport_bets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sport_bets (id, transaction_id, bet_amount, bet_reference_num, game_reference, bet_mode, description, user_id, frontend_type, status, sport_ids, site_id, client_ip, affiliate_user_id, autorecharge, bet_details, currency, potential_win, actual_win, odds, placed_at, settled_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: squads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.squads (id, handle, owner, created_at, updated_at, deleted_at, type) FROM stdin;
\.


--
-- Data for Name: squads_earns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.squads_earns (id, squad_id, user_id, currency, earned, game_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: squads_memebers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.squads_memebers (id, squad_id, user_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: street_kings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.street_kings (id, user_id, status, version, bet_amount, won_amount, crash_point, cash_out_point, "timestamp") FROM stdin;
\.


--
-- Data for Name: temp; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.temp (id, user_id, created_at, updated_at, data) FROM stdin;
eb83224a-eb88-474a-87b7-9a8472ec491d	742a9f80-de40-4f18-b9f7-1b44c8cf226d	2025-08-29 23:00:53.536187+00	2025-08-29 23:00:53.536187+00	{"referral_code": "P-NYjOiCdYo3es"}
bd101e6d-4bc3-46d7-a6c4-a19f24920866	8c0a47dc-f4a3-4005-9564-dfa5f5c6ef4a	2025-08-30 06:57:29.380307+00	2025-08-30 06:57:29.380307+00	{"referral_code": "P-2jjJv3UjIOdY", "refered_by_code": "REF123", "agent_request_id": "AGENT001"}
041c32ea-9be5-4527-b0bd-1bb02b784f5d	32794ef9-21c1-4402-9a57-c5ae327e5628	2025-08-30 20:31:42.440761+00	2025-08-30 20:31:42.440761+00	{"referral_code": "P-9O3jf9xKAiql", "refered_by_code": "REF123", "agent_request_id": "AGENT001"}
1fb31a64-17f3-4d34-884d-1c29be5d9db5	c31f3159-615d-4ab1-95d7-1ef3cc616246	2025-08-30 20:43:17.930811+00	2025-08-30 20:43:17.930811+00	{"referral_code": "P-0UAvUU24PCkg", "refered_by_code": "REF123", "agent_request_id": "AGENT001"}
f7b19cdd-2733-4e05-9eea-0d924d1cd21f	43b5061a-9587-4869-88d8-131c252d8c36	2025-08-30 20:43:52.113351+00	2025-08-30 20:43:52.113351+00	{"referral_code": "P-isXGDTAZMEcr", "refered_by_code": "REF123", "agent_request_id": "AGENT001"}
049d0dae-0b8b-453b-80ba-5ce699803cec	2f18fe42-1794-4abe-8a53-b28449312569	2025-08-30 20:45:47.637516+00	2025-08-30 20:45:47.637516+00	{"referral_code": "P-moSpksaqJ7Ds", "refered_by_code": "REF123", "agent_request_id": "AGENT001"}
8cbd490b-0700-4864-9c9c-d88b6668dbab	a2721844-375b-461e-9f9e-8ae3e59bdcdf	2025-08-30 20:46:13.849566+00	2025-08-30 20:46:13.849566+00	{"referral_code": "P-FAYcUaBAZBI3", "refered_by_code": "REF123", "agent_request_id": "AGENT001"}
4e00692f-ee83-43d7-a78d-172fc4fa4cf4	54d3fa8b-7caf-4b70-85c0-8de2a834e34b	2025-08-30 20:53:59.43685+00	2025-08-30 20:53:59.43685+00	{"referral_code": "P-cQIcqwmRSAj4", "refered_by_code": "REF123", "agent_request_id": "AGENT001"}
da9c629a-b0a8-45c1-9785-dbe6a9e08682	d74889ef-2f4e-462f-a6bd-7fcdcccbaf06	2025-08-30 23:37:53.769525+00	2025-08-30 23:37:53.769525+00	{"referral_code": "P-99T3kKBl0GwO", "refered_by_code": "REF123", "agent_request_id": "AGENT001"}
e34a016b-f52b-41a8-9d7f-8e34af2f8948	21703745-3849-4b23-a318-c0c9ef2a5304	2025-08-30 23:53:18.277419+00	2025-08-30 23:53:18.277419+00	{"referral_code": "P-3DNedMEXj3Sa", "refered_by_code": "REF123", "agent_request_id": "AGENT001"}
240ea8d3-3090-4bb0-b9b7-49130bf383d7	78872d78-4ec1-454d-a563-c00ce47bece7	2025-08-31 00:26:54.565992+00	2025-08-31 00:26:54.565992+00	{"referral_code": "P-uBKtmkyl5LPo", "refered_by_code": "REF123", "agent_request_id": "AGENT001"}
1184f858-7a53-4c89-a58e-de4042866f99	47781512-f533-45f5-8e6e-14d239e890d5	2025-08-31 20:30:37.358924+00	2025-08-31 20:30:37.358924+00	{"referral_code": "P-f2zhknBSxyfh", "refered_by_code": "REF999", "agent_request_id": "AGENT002"}
\.


--
-- Data for Name: tournaments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tournaments (id, rank, level, cumulative_points, rewards, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: tournaments_claims; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tournaments_claims (id, tournament_id, squad_id, claimed_at) FROM stdin;
\.


--
-- Data for Name: user_notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_notifications (id, user_id, title, content, type, metadata, read, delivered, created_at, read_at, created_by) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (id, user_id, role_id) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sessions (id, user_id, token, expires_at, ip_address, user_agent, created_at, refresh_token, refresh_token_expires_at) FROM stdin;
5c5b7edd-eb1a-496d-bf63-2c2964cd1266	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU4MzcwLCJpYXQiOjE3NTY2NzE5NzAsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.KvgMfqZAsrB_hCST5zdazyipL8CSqFi0eB2yBmxoJTE	2025-08-31 23:36:10.023934	::1	curl/8.5.0	2025-08-31 23:26:10.023935	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc2NzcwLCJpYXQiOjE3NTY2NzE5NzAsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.XJYczJjO5Jezrg3GbKmZjaGshsvIX3qzY-izROIOBUlcLX_zmD5S8hB4h1Oy9MySMezzqiEisE7LzIr5qUQdPw	2025-08-31 23:56:10.023934
793c04ae-484e-4f34-b1c9-6a27b1d90144	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU4MzcwLCJpYXQiOjE3NTY2NzE5NzAsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.KvgMfqZAsrB_hCST5zdazyipL8CSqFi0eB2yBmxoJTE	2025-08-31 23:36:10.089825	::1	curl/8.5.0	2025-08-31 23:26:10.089826	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc2NzcwLCJpYXQiOjE3NTY2NzE5NzAsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.XJYczJjO5Jezrg3GbKmZjaGshsvIX3qzY-izROIOBUlcLX_zmD5S8hB4h1Oy9MySMezzqiEisE7LzIr5qUQdPw	2025-08-31 23:56:10.089825
75a1f13d-5b6c-4d9e-a77c-0f2cba95a3ec	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU4MzcwLCJpYXQiOjE3NTY2NzE5NzAsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.KvgMfqZAsrB_hCST5zdazyipL8CSqFi0eB2yBmxoJTE	2025-08-31 23:36:10.152457	::1	curl/8.5.0	2025-08-31 23:26:10.152459	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc2NzcwLCJpYXQiOjE3NTY2NzE5NzAsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.XJYczJjO5Jezrg3GbKmZjaGshsvIX3qzY-izROIOBUlcLX_zmD5S8hB4h1Oy9MySMezzqiEisE7LzIr5qUQdPw	2025-08-31 23:56:10.152457
dcc7e0ec-65b7-4f1b-baea-c41992760ffb	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU4NDMzLCJpYXQiOjE3NTY2NzIwMzMsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.7ZUPXoCWo-FbBR4w3SN3DDZ9QltBc-i3cRy5FyRjnl4	2025-08-31 23:37:13.1948	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	2025-08-31 23:27:13.1948	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc2ODMzLCJpYXQiOjE3NTY2NzIwMzMsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.jYlFw7uqhpOuyW0zWoNym0C7rD3EkN5-_Bs0Geh1gnFvmVKYDh9DY0WEeOFn24_mNGZLgJbybsrl5kd_1y1xQA	2025-08-31 23:57:13.1948
203ccc0b-f2f8-489c-8f45-470ace6ded6e	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU4ODYxLCJpYXQiOjE3NTY2NzI0NjEsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.ouPzrQ5jU87lsGg8E0nDNfjPvkxP_o-aw6q70YopMgY	2025-08-31 23:44:21.389272	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	2025-08-31 23:34:21.389272	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc3MjYxLCJpYXQiOjE3NTY2NzI0NjEsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.nHqs5a3wAvFMq8SIEaoQzhT4ahKL1Kfo-azfPv9kgXnL5jF7hdi0aCyR_IYLcSN3C_PZzTjMbpReN5n0AsJ32g	2025-09-01 00:04:21.389272
e2366682-db3e-4ac9-af72-a9fdbaa45b1f	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU4OTMwLCJpYXQiOjE3NTY2NzI1MzAsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.UC-gC33uim55rqkL3X2A6jF2yj7UIXZmsGMl9NaS2Zs	2025-08-31 23:45:30.453675	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	2025-08-31 23:35:30.453675	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc3MzMwLCJpYXQiOjE3NTY2NzI1MzAsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.3--ljPig1QpqU3FPb2-jA5ZpcDAm4doKAeMokvpmlQIRC5izbWZUT07Bu0nHp-wBM6cb_iX7fPsq5n86iRA8TQ	2025-09-01 00:05:30.453675
23ccc124-fa6d-463b-a61a-82d02ffa2ae6	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU5MDUyLCJpYXQiOjE3NTY2NzI2NTIsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.S2Cnlj0bkf_fnPmmrfwQWuFnsePNPrn4JlMl2H8e7X4	2025-08-31 23:47:32.552496	::1	curl/8.5.0	2025-08-31 23:37:32.552496	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc3NDUyLCJpYXQiOjE3NTY2NzI2NTIsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.QvRhs1Vwvgmy4anSxlG79zEqS2Z2WJRqLWjFYqy4XGEB0PHcjw9bUYzr7m2vxUBhKv6OmVv1qWq914qXAAu-mQ	2025-09-01 00:07:32.552495
458fba5c-cc34-4e78-a9a1-a6937e0d1ff6	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU5MDc0LCJpYXQiOjE3NTY2NzI2NzQsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.MnrJ5ER4yicqrO0HRbteSKXAqHZVAnucw5Jx9Wbtl04	2025-08-31 23:47:54.568644	::1	curl/8.5.0	2025-08-31 23:37:54.568645	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc3NDc0LCJpYXQiOjE3NTY2NzI2NzQsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.oM-9lNroITUpALuiWBeATsMXRdlzqDl4EkJf4VHKRVUzGdUFkM7dwj6byBCl8PAge6ChUKAHop5ziiZFI3GVAw	2025-09-01 00:07:54.568644
597fbefa-818e-41db-995f-99a9a08bcb8f	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU5MTAzLCJpYXQiOjE3NTY2NzI3MDMsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.W9GcYLllPcQmQ2QXOx-x7ROlHpl9u5BAXzNEQi4QLu0	2025-08-31 23:48:23.630159	::1	curl/8.5.0	2025-08-31 23:38:23.63016	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc3NTAzLCJpYXQiOjE3NTY2NzI3MDMsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.bMHR_AsLMBHYBbOD6ZuPzht4fDlyGDAHZ641-Xi7StqwxoFHPiqGykUwFV6AGiWU5W9oANFF8j2odZzOlloymA	2025-09-01 00:08:23.630159
cc125674-a26b-48cb-868f-5850bc1f42bd	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU5MTQ0LCJpYXQiOjE3NTY2NzI3NDQsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.0rlKpruNCHQUlg_-Ne92L0ayY3O-ARHNDfToJ6RVin8	2025-08-31 23:49:04.792059	::1	curl/8.5.0	2025-08-31 23:39:04.792059	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc3NTQ0LCJpYXQiOjE3NTY2NzI3NDQsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.ybgWjlZKNlY1K7VG1jbGUDXWmYFCYChQ3E3BbQh573SPdDYc0TbFpvDoEBD8_ehiaxwcYs_ZtWHzet5qWMvpkg	2025-09-01 00:09:04.792059
1aa27f13-79ed-4475-8b4f-2e7ad443f2e9	47781512-f533-45f5-8e6e-14d239e890d5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNDc3ODE1MTItZjUzMy00NWY1LThlNmUtMTRkMjM5ZTg5MGQ1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU5MTg5LCJpYXQiOjE3NTY2NzI3ODksImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiNDc3ODE1MTItZjUzMy00NWY1LThlNmUtMTRkMjM5ZTg5MGQ1In0.kdKblbYK7nSBGMTW9x8O1po0nuhuSbDLMRpxOUIQyQ0	2025-08-31 23:49:49.216985	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	2025-08-31 23:39:49.216985	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNDc3ODE1MTItZjUzMy00NWY1LThlNmUtMTRkMjM5ZTg5MGQ1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc3NTg5LCJpYXQiOjE3NTY2NzI3ODksImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiNDc3ODE1MTItZjUzMy00NWY1LThlNmUtMTRkMjM5ZTg5MGQ1In0.9JiVcUdC0IgDSGnd-SJRZeZvkM9dWrLTd5Fq9avUXdB1xkWk-jBQ4ulnd0NPTn6eWihhnhYZWWG3wXSDGsNTDQ	2025-09-01 00:09:49.216984
eed54620-efb8-4da6-acff-dfe0cf9c915c	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU5MjI3LCJpYXQiOjE3NTY2NzI4MjcsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.7h6s_2VC-yGeSXTqdMPZxqrs6-ORPuZI6j7lHJ0cArQ	2025-08-31 23:50:27.747254	::1	curl/8.5.0	2025-08-31 23:40:27.747254	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc3NjI3LCJpYXQiOjE3NTY2NzI4MjcsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.aKsz9etY29gBgY94JxawhXOoQfVvqoL3_2CoBvUol7vz1UupydAVQbkFnQg81rIzGWiwRy4a1ZLR7kD9ZfM0uA	2025-09-01 00:10:27.747254
707b93f1-c54f-4c4a-9547-c96f0e91678a	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU5Mjc1LCJpYXQiOjE3NTY2NzI4NzUsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.47Z4-Bx90r7Zf-c6M3Z6qNcBSaUXw6EztX8M1hA3OnU	2025-08-31 23:51:15.311789	::1	curl/8.5.0	2025-08-31 23:41:15.311789	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc3Njc1LCJpYXQiOjE3NTY2NzI4NzUsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.FyQeCwR0kyUL3znIvC_tESZuotBUvKdMbx-DQQRaYwsbZ640iDPLjdhdpVrwoJmV7ISSFgUtX9izHknKvwiMbg	2025-09-01 00:11:15.311789
fa02b95b-2927-4972-8d92-a6c363b257ea	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU5MzAwLCJpYXQiOjE3NTY2NzI5MDAsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.hgw1cM7TCLEo02LBb6NOi7M0-dOeYw4HcszB1JgIrg8	2025-08-31 23:51:40.044657	::1	curl/8.5.0	2025-08-31 23:41:40.044657	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc3NzAwLCJpYXQiOjE3NTY2NzI5MDAsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.G-SCfZG4XyS2zMqaQYK1ysnE8CKlSDM8M9ZaAzj8DaK0bDFxOZLbGaYp9xL0AGUBRhpMrRhHHLGaKzkRihtJ7w	2025-09-01 00:11:40.044657
6cb260dc-9d7f-451d-a6e6-53f5ffe3f5c4	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU5MzM5LCJpYXQiOjE3NTY2NzI5MzksImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.k-i_mjkyrEOgoPnnibOXy542Pji0l8ntKpL2VSThH8Q	2025-08-31 23:52:19.115913	::1	curl/8.5.0	2025-08-31 23:42:19.115913	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc3NzM5LCJpYXQiOjE3NTY2NzI5MzksImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.F2NRo2h_7ChhKotjsg8a_x882gDqoiIj4e9MXQw6ShLOKrZCrtd8MMI3_Y-Is57_kqf1AY8x4ld7t3f9F9z61Q	2025-09-01 00:12:19.115912
e6971d9f-f7a9-4459-8188-8a54d1826ce6	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU5NDA0LCJpYXQiOjE3NTY2NzMwMDQsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.F4_H5qObreQlLNcoq64iml3LiJrbfYkBiAAM88j1XYY	2025-08-31 23:53:24.331533	::1	curl/8.5.0	2025-08-31 23:43:24.331533	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc3ODA0LCJpYXQiOjE3NTY2NzMwMDQsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.ZclBtGn7VSt4KHJnwhYCVmMmZ9OTaZdhdqFrMZ54fZitluXb0BEm63CY4OkX0AaNCfaggMSZWXOqgnbRUJJ25w	2025-09-01 00:13:24.331533
3fb7e2da-6c19-4e9d-b367-df1da2653b76	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU5NDc5LCJpYXQiOjE3NTY2NzMwNzksImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.64wBXTQVVWBuwK68PE0_nWHzohTD927rPkRbxMbWulw	2025-08-31 23:54:39.585458	::1	curl/8.5.0	2025-08-31 23:44:39.585458	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc3ODc5LCJpYXQiOjE3NTY2NzMwNzksImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.4bYXdL2pi3wdRGJLwFrTOGrbSxmPhmktuREWXBGkOfaFv9A5fWD51N_L7nd0En8uX2WaYHPf3lNBt9U82gTEjw	2025-09-01 00:14:39.585458
36c4fff2-fdec-43f4-b8bb-cc29132e2f05	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU5NDk0LCJpYXQiOjE3NTY2NzMwOTQsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.czbNvzhLldExV5v_vuUTJIKi-cvwOZsjlEuDFApddD0	2025-08-31 23:54:54.842589	::1	curl/8.5.0	2025-08-31 23:44:54.842589	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc3ODk0LCJpYXQiOjE3NTY2NzMwOTQsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.vsAADHrehMPb88KT_pgxnKD4AdJlVcCVdNHigxQ5DQT5hKrV9biQGjvBwtcMiBGUVFXqk-cOQaVnGHN1z6VwCg	2025-09-01 00:14:54.842589
94dade19-ebe4-4b08-b3fa-b183e776aca7	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU5NTk3LCJpYXQiOjE3NTY2NzMxOTcsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.U-NVS9JA9mh8stvUJ3Rp0heU-ABcDDnxgw-LxMmD05Y	2025-08-31 23:56:37.4592	::1	curl/8.5.0	2025-08-31 23:46:37.4592	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc3OTk3LCJpYXQiOjE3NTY2NzMxOTcsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.2IIuC75jBn_8Q4xgsqupe8fpF787F3322UJSng53TUvDVvPGyU9ey7Aqc3fSVlnlnsvWgSHWaGy2syyT625Jrw	2025-09-01 00:16:37.4592
9f2a2ad3-00f6-42d5-8e7b-0f37b5efe5ab	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU5NjEzLCJpYXQiOjE3NTY2NzMyMTMsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.my2Nl1QiTo8evVOtEPposDXqN124tw3xHIYOqI5cXwo	2025-08-31 23:56:53.972771	::1	curl/8.5.0	2025-08-31 23:46:53.972772	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc4MDEzLCJpYXQiOjE3NTY2NzMyMTMsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.MTPA_9pakP0MJ-Q_ltmzQRC-4vjvZsh0HpmeERNqJXjyoOLO_hOk3inlLuQB5flmc1SFwo9RYCEzs50jyjuZbg	2025-09-01 00:16:53.972771
359db961-53fb-4b08-aa0f-1c6300248829	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU5NjMyLCJpYXQiOjE3NTY2NzMyMzIsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.Nb4TW1iZSXqUQZeglzXOV1kF82PC8nzmP5V5C2VO_4E	2025-08-31 23:57:12.896881	::1	curl/8.5.0	2025-08-31 23:47:12.896881	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc4MDMyLCJpYXQiOjE3NTY2NzMyMzIsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.ndHp8u_8ute6N6l0ocX6-CEFPO9dfKRi18wVnk8naoWQ7uut6YmmP9LjHVSbVswTOdiy0_jxNHS3tCO8i4YoSg	2025-09-01 00:17:12.896881
6e958aa8-7bb6-4480-a31a-5824a894e7cb	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU5NjUzLCJpYXQiOjE3NTY2NzMyNTMsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.s1mWre7BkU7uuJ2as87LLhjkB3c7ld7tHMfQ1UBfKSY	2025-08-31 23:57:33.8924	::1	curl/8.5.0	2025-08-31 23:47:33.8924	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc4MDUzLCJpYXQiOjE3NTY2NzMyNTMsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.demL7mkkEtbf2crdNyDHFV2OEVJ_ZnoGjUyQ3G9nwoovIdpLYv6JsyF4PfURm8ocW5UufSU8tjDOk-PLeaubPw	2025-09-01 00:17:33.8924
fea44667-42c6-4a0e-ae9e-4d5b4ca7c8b2	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzU5OTk5LCJpYXQiOjE3NTY2NzM1OTksImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.iFLWvMZXKHiskRiwTMMoJmM68SXdRGu5BdtQdpSB3P8	2025-09-01 00:03:19.223615	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	2025-08-31 23:53:19.223615	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc4Mzk5LCJpYXQiOjE3NTY2NzM1OTksImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.EFSSh2edYne8I5W6jjR_9OhKQAPPcQTTuSc6Q5qDd016pEh69P4WQ53ARdmEFis6LQRdyd0m8nJFY6J9orLzMw	2025-09-01 00:23:19.223614
1a9d1b7d-f9cd-406c-b4ec-82418a72484b	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2NzYwMTM0LCJpYXQiOjE3NTY2NzM3MzQsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.CGVkKPf6W__OamjTby3tAtHvaxxAoiyEw__6M7BBdrE	2025-09-01 00:05:34.124824	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	2025-08-31 23:55:34.124824	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3Mjc4NTM0LCJpYXQiOjE3NTY2NzM3MzQsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.t5uv4KuSYkMbHZV_DVgf_YH9LAH_9y3QDL4eZWp_Rk2gRUb9-W0zqAmTWbKb1-4c1__MY_7RxheQ1T7V2r-_RA	2025-09-01 00:25:34.124824
80191f3e-f086-4c45-833f-aaac38aa87a3	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU2ODkwNTEwLCJpYXQiOjE3NTY4MDQxMTAsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.5JU9_IzIdTVTeY1muc-GADFeuZ5PV2G1aUdLDwGcywE	2025-09-02 12:18:30.484575	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	2025-09-02 12:08:30.484575	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3NDA4OTEwLCJpYXQiOjE3NTY4MDQxMTAsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.VKdwlUzTutxfeC0IIv0ob61rOt9xo-a_nPT-hPfG_JJqqcR1LjS6VmLRVkhJQopcFesCuTtS72cvkayYiEZrog	2025-09-02 12:38:30.484575
77a276bd-a6e5-4b78-a1c0-e1ba62be2650	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3MDMxOTkxLCJpYXQiOjE3NTY5NDU1OTEsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.YML_MPMD3p4vTwAVv_uQ_f1BHBNJkoofwjCrmwywXzU	2025-09-04 03:36:31.549961	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	2025-09-04 03:26:31.549961	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3NTUwMzkxLCJpYXQiOjE3NTY5NDU1OTEsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.L3JUY-xO4-i5d38m76_d7_iObJumHOHoGbECXSRwQ5FM0wFWgZj_Hn9EGMQXVO81Y7J4ZGV8SRogTrtbLj00oQ	2025-09-04 03:56:31.549961
28088bcf-a766-461a-b599-c96a76f3bb0c	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3MDgzODY3LCJpYXQiOjE3NTY5OTc0NjcsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.nustCD6NuMZzURC8yjF_FhBXe1fDf1kEQpGz84yplz0	2025-09-04 18:01:07.043813	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	2025-09-04 17:51:07.043814	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3NjAyMjY3LCJpYXQiOjE3NTY5OTc0NjcsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.ZuvIitMK26NyLhy_gPsdRrjbOhxYDAiJTcU7STKmGGXcppvkBBxvztRtQwzWFY1S7PTOq2I2vYTXipsJ_w7Otg	2025-09-04 18:21:07.043813
d6d452a4-5e3e-4aaf-82a1-9e7dbc09e930	a5e168fb-168e-4183-84c5-d49038ce00b5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3MDg1MzE1LCJpYXQiOjE3NTY5OTg5MTUsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.CjXmIsEbMaUjGnMZA79BVS_Li-opRwY9uXF9D2ZdHeY	2025-09-04 18:25:15.609021	127.0.0.1	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	2025-09-04 18:15:15.609021	eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1IiwiaXNfdmVyaWZpZWQiOmZhbHNlLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsInBob25lX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzU3NjAzNzE1LCJpYXQiOjE3NTY5OTg5MTUsImlzcyI6InR1Y2FuYml0Iiwic3ViIjoiYTVlMTY4ZmItMTY4ZS00MTgzLTg0YzUtZDQ5MDM4Y2UwMGI1In0.ren9c1jW_rLi4lioHGekAZ18dj1Fv69O8sgmv8FVAcAY0CBFU1Rk7kcbpZmPHnVOmPjospVDgvgVSaLDC5nVQQ	2025-09-04 18:45:15.609021
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, phone_number, password, created_at, default_currency, profile, email, first_name, last_name, date_of_birth, source, is_email_verified, referal_code, street_address, country, state, city, postal_code, kyc_status, created_by, is_admin, status, referal_type, refered_by_code, user_type, primary_wallet_address, wallet_verification_status) FROM stdin;
e3588cc3-0578-4939-ab9e-597d1216f2a5	player_decf5b93	\N		2025-09-03 23:49:31.81907	USD		\N				wallet	f	HaJPhpfib2Ip						PENDING	\N	f	active	PLAYER	\N	PLAYER	\N	none
99d03999-0f02-4c97-9bc3-d7d3bb8fd885	player_5a517fd1	\N		2025-09-03 23:51:13.955767	USD		\N				wallet	f	2dRDYTVv1fle						PENDING	\N	f	active	PLAYER	\N	PLAYER	\N	none
a6147b2f-bd0b-4ff5-b94d-fd431d1aa074		\N		2025-08-31 19:07:38.597788			test@example.com					f	I6E2P3E1						PENDING	\N	f	\N	\N	\N	PLAYER	\N	none
a5e168fb-168e-4183-84c5-d49038ce00b5	P-uBKtmkyl5LPo	+251912308971	$2a$10$kCLcXu5lrI3/Qee.oEXfiu1iv1EYj8/XVSVOEhbljzQedaWo7Te/O	2025-08-31 20:25:57.127123	\N		ashenafialemu9898@gmail.com	Ashenafi	Alemu			t	ouWiLgN0RZDB						PENDING	\N	\N	ACTIVE	\N	\N	PLAYER	\N	none
47781512-f533-45f5-8e6e-14d239e890d5	P-f2zhknBSxyfh	+25191122014	$2a$10$5WTIfXdwnb8HZPwMKru1WOY3Qr6olelnbo5sw2fo2n/yiXqxRZU6y	2025-08-31 20:30:37.351669	P		ashenafi.mlm@gmail.com	Ashenafi	Alemu	1992-05-15	facebook	t	P-f2zhknBSxyfh						PENDING	\N	f	\N	PLAYER	REF999	PLAYER	\N	none
21e96e96-f70d-4eb8-a5eb-0ff6c2bc33eb	player_87879fe4	\N		2025-09-03 23:53:40.235362	USD		\N				wallet	f	p0iceouHqsPK						PENDING	\N	f	active	PLAYER	\N	PLAYER	\N	none
3fbc49ac-db45-40c4-a949-ade55082662e	player_72ee1fc4	\N		2025-09-03 23:47:58.477659	USD		\N				wallet	f	lc2zFJy4HGxx						PENDING	\N	f	active	PLAYER	\N	PLAYER	0xa9ce394f87cf36f3b7ddfd85824c2218270d25c1	verified
29ff053e-cc63-4894-bc2f-a38aaeca3244	player_de82421d	\N		2025-09-03 23:48:36.782038	USD		\N				wallet	f	wddKUHPkBvhj						PENDING	\N	f	active	PLAYER	\N	PLAYER	\N	none
f12e2768-0c41-40af-9c12-0d264a76d5ca	player_099d98f1	\N		2025-09-03 23:48:43.230372	USD		\N				wallet	f	wddKUHPkBvhj						PENDING	\N	f	active	PLAYER	\N	PLAYER	0x1234567890abcdef1234567890abcdef12345678	verified
\.


--
-- Data for Name: users_football_matche_rounds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_football_matche_rounds (id, status, won_status, user_id, football_round_id, bet_amount, won_amount, "timestamp", currency) FROM stdin;
\.


--
-- Data for Name: users_football_matches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_football_matches (id, status, match_id, selection, users_football_matche_round_id) FROM stdin;
\.


--
-- Data for Name: users_otp; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_otp (id, user_id, otp, created_at) FROM stdin;
\.


--
-- Data for Name: waiting_squad_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.waiting_squad_members (id, user_id, squad_id, created_at) FROM stdin;
\.


--
-- Name: casbin_rule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.casbin_rule_id_seq', 1, true);


--
-- Name: account_block account_block_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_block
    ADD CONSTRAINT account_block_pkey PRIMARY KEY (id);


--
-- Name: adds_services adds_services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.adds_services
    ADD CONSTRAINT adds_services_pkey PRIMARY KEY (id);


--
-- Name: agent_providers agent_providers_client_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_providers
    ADD CONSTRAINT agent_providers_client_id_key UNIQUE (client_id);


--
-- Name: agent_providers agent_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_providers
    ADD CONSTRAINT agent_providers_pkey PRIMARY KEY (id);


--
-- Name: agent_referrals agent_referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_referrals
    ADD CONSTRAINT agent_referrals_pkey PRIMARY KEY (id);


--
-- Name: agent_referrals agent_referrals_request_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_referrals
    ADD CONSTRAINT agent_referrals_request_id_key UNIQUE (request_id);


--
-- Name: airtime_transactions airtime_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.airtime_transactions
    ADD CONSTRAINT airtime_transactions_pkey PRIMARY KEY (id);


--
-- Name: airtime_utilities airtime_utilities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.airtime_utilities
    ADD CONSTRAINT airtime_utilities_pkey PRIMARY KEY (local_id);


--
-- Name: balance_logs balance_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balance_logs
    ADD CONSTRAINT balance_logs_pkey PRIMARY KEY (id);


--
-- Name: balances balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_pkey PRIMARY KEY (id);


--
-- Name: banners banners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_pkey PRIMARY KEY (id);


--
-- Name: bets bets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bets
    ADD CONSTRAINT bets_pkey PRIMARY KEY (id);


--
-- Name: casbin_rule casbin_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.casbin_rule
    ADD CONSTRAINT casbin_rule_pkey PRIMARY KEY (id);


--
-- Name: clubs clubs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clubs
    ADD CONSTRAINT clubs_pkey PRIMARY KEY (id);


--
-- Name: company company_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company
    ADD CONSTRAINT company_pkey PRIMARY KEY (id);


--
-- Name: configs configs_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configs
    ADD CONSTRAINT configs_name_key UNIQUE (name);


--
-- Name: configs configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configs
    ADD CONSTRAINT configs_pkey PRIMARY KEY (id);


--
-- Name: crypto_kings crypto_kings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crypto_kings
    ADD CONSTRAINT crypto_kings_pkey PRIMARY KEY (id);


--
-- Name: crypto_wallet_auth_logs crypto_wallet_auth_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crypto_wallet_auth_logs
    ADD CONSTRAINT crypto_wallet_auth_logs_pkey PRIMARY KEY (id);


--
-- Name: crypto_wallet_challenges crypto_wallet_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crypto_wallet_challenges
    ADD CONSTRAINT crypto_wallet_challenges_pkey PRIMARY KEY (id);


--
-- Name: crypto_wallet_connections crypto_wallet_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crypto_wallet_connections
    ADD CONSTRAINT crypto_wallet_connections_pkey PRIMARY KEY (id);


--
-- Name: crypto_wallet_connections crypto_wallet_connections_user_id_wallet_address_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crypto_wallet_connections
    ADD CONSTRAINT crypto_wallet_connections_user_id_wallet_address_key UNIQUE (user_id, wallet_address);


--
-- Name: crypto_wallet_connections crypto_wallet_connections_wallet_address_wallet_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crypto_wallet_connections
    ADD CONSTRAINT crypto_wallet_connections_wallet_address_wallet_type_key UNIQUE (wallet_address, wallet_type);


--
-- Name: currencies currencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_pkey PRIMARY KEY (id);


--
-- Name: departements_users departements_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departements_users
    ADD CONSTRAINT departements_users_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: exchange_rates exchange_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_pkey PRIMARY KEY (id);


--
-- Name: failed_bet_logs failed_bet_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_bet_logs
    ADD CONSTRAINT failed_bet_logs_pkey PRIMARY KEY (id);


--
-- Name: football_match_rounds football_match_rounds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.football_match_rounds
    ADD CONSTRAINT football_match_rounds_pkey PRIMARY KEY (id);


--
-- Name: football_matchs football_matchs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.football_matchs
    ADD CONSTRAINT football_matchs_pkey PRIMARY KEY (id);


--
-- Name: game_logs game_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.game_logs
    ADD CONSTRAINT game_logs_pkey PRIMARY KEY (id);


--
-- Name: games games_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT games_pkey PRIMARY KEY (id);


--
-- Name: ip_filters ip_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ip_filters
    ADD CONSTRAINT ip_filters_pkey PRIMARY KEY (id);


--
-- Name: leagues leagues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leagues
    ADD CONSTRAINT leagues_pkey PRIMARY KEY (id);


--
-- Name: level_requirements level_requirements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.level_requirements
    ADD CONSTRAINT level_requirements_pkey PRIMARY KEY (id);


--
-- Name: levels levels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.levels
    ADD CONSTRAINT levels_pkey PRIMARY KEY (id);


--
-- Name: login_attempts login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_attempts
    ADD CONSTRAINT login_attempts_pkey PRIMARY KEY (id);


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: loot_box loot_box_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loot_box
    ADD CONSTRAINT loot_box_pkey PRIMARY KEY (id);


--
-- Name: loot_box_place_bets loot_box_place_bets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loot_box_place_bets
    ADD CONSTRAINT loot_box_place_bets_pkey PRIMARY KEY (id);


--
-- Name: lotteries lotteries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotteries
    ADD CONSTRAINT lotteries_pkey PRIMARY KEY (id);


--
-- Name: lottery_logs lottery_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lottery_logs
    ADD CONSTRAINT lottery_logs_pkey PRIMARY KEY (id);


--
-- Name: lottery_services lottery_services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lottery_services
    ADD CONSTRAINT lottery_services_pkey PRIMARY KEY (id);


--
-- Name: lottery_winners_logs lottery_winners_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lottery_winners_logs
    ADD CONSTRAINT lottery_winners_logs_pkey PRIMARY KEY (id);


--
-- Name: manual_funds manual_funds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.manual_funds
    ADD CONSTRAINT manual_funds_pkey PRIMARY KEY (id);


--
-- Name: operational_groups operational_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_groups
    ADD CONSTRAINT operational_groups_pkey PRIMARY KEY (id);


--
-- Name: operational_types operational_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_types
    ADD CONSTRAINT operational_types_pkey PRIMARY KEY (id);


--
-- Name: otps otps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.otps
    ADD CONSTRAINT otps_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: plinko plinko_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plinko
    ADD CONSTRAINT plinko_pkey PRIMARY KEY (id);


--
-- Name: quick_hustles quick_hustles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quick_hustles
    ADD CONSTRAINT quick_hustles_pkey PRIMARY KEY (id);


--
-- Name: risk_settings risk_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_settings
    ADD CONSTRAINT risk_settings_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: roll_da_dice roll_da_dice_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roll_da_dice
    ADD CONSTRAINT roll_da_dice_pkey PRIMARY KEY (id);


--
-- Name: rounds rounds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rounds
    ADD CONSTRAINT rounds_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: scratch_cards scratch_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scratch_cards
    ADD CONSTRAINT scratch_cards_pkey PRIMARY KEY (id);


--
-- Name: spinning_wheel_configs spinning_wheel_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spinning_wheel_configs
    ADD CONSTRAINT spinning_wheel_configs_pkey PRIMARY KEY (id);


--
-- Name: spinning_wheel_mysteries spinning_wheel_mysteries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spinning_wheel_mysteries
    ADD CONSTRAINT spinning_wheel_mysteries_pkey PRIMARY KEY (id);


--
-- Name: spinning_wheel_rewards spinning_wheel_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spinning_wheel_rewards
    ADD CONSTRAINT spinning_wheel_rewards_pkey PRIMARY KEY (id);


--
-- Name: spinning_wheels spinning_wheels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spinning_wheels
    ADD CONSTRAINT spinning_wheels_pkey PRIMARY KEY (id);


--
-- Name: sport_bets sport_bets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sport_bets
    ADD CONSTRAINT sport_bets_pkey PRIMARY KEY (id);


--
-- Name: sport_bets sport_bets_transaction_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sport_bets
    ADD CONSTRAINT sport_bets_transaction_id_key UNIQUE (transaction_id);


--
-- Name: squads_earns squads_earns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.squads_earns
    ADD CONSTRAINT squads_earns_pkey PRIMARY KEY (id);


--
-- Name: squads_memebers squads_memebers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.squads_memebers
    ADD CONSTRAINT squads_memebers_pkey PRIMARY KEY (id);


--
-- Name: squads squads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.squads
    ADD CONSTRAINT squads_pkey PRIMARY KEY (id);


--
-- Name: street_kings street_kings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.street_kings
    ADD CONSTRAINT street_kings_pkey PRIMARY KEY (id);


--
-- Name: temp temp_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.temp
    ADD CONSTRAINT temp_pkey PRIMARY KEY (id);


--
-- Name: tournaments_claims tournaments_claims_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournaments_claims
    ADD CONSTRAINT tournaments_claims_pkey PRIMARY KEY (id);


--
-- Name: tournaments tournaments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournaments
    ADD CONSTRAINT tournaments_pkey PRIMARY KEY (id);


--
-- Name: banners unique_page; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT unique_page UNIQUE (page);


--
-- Name: user_notifications user_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_notifications
    ADD CONSTRAINT user_notifications_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users_football_matche_rounds users_football_matche_rounds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_football_matche_rounds
    ADD CONSTRAINT users_football_matche_rounds_pkey PRIMARY KEY (id);


--
-- Name: users_football_matches users_football_matches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_football_matches
    ADD CONSTRAINT users_football_matches_pkey PRIMARY KEY (id);


--
-- Name: users_otp users_otp_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_otp
    ADD CONSTRAINT users_otp_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_phone_number_key UNIQUE (phone_number);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: waiting_squad_members waiting_squad_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waiting_squad_members
    ADD CONSTRAINT waiting_squad_members_pkey PRIMARY KEY (id);


--
-- Name: idx_adds_services_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_adds_services_created_at ON public.adds_services USING btree (created_at);


--
-- Name: idx_adds_services_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_adds_services_status ON public.adds_services USING btree (status);


--
-- Name: idx_agent_referrals_callback_attempts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_referrals_callback_attempts ON public.agent_referrals USING btree (callback_attempts);


--
-- Name: idx_agent_referrals_callback_sent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_referrals_callback_sent ON public.agent_referrals USING btree (callback_sent);


--
-- Name: idx_agent_referrals_converted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_referrals_converted_at ON public.agent_referrals USING btree (converted_at);


--
-- Name: idx_agent_referrals_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_referrals_request_id ON public.agent_referrals USING btree (request_id);


--
-- Name: idx_agent_referrals_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_referrals_user_id ON public.agent_referrals USING btree (user_id);


--
-- Name: idx_casbin_rule; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_casbin_rule ON public.casbin_rule USING btree (ptype, v0, v1, v2, v3, v4, v5);


--
-- Name: idx_crypto_wallet_auth_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_crypto_wallet_auth_logs_created_at ON public.crypto_wallet_auth_logs USING btree (created_at);


--
-- Name: idx_crypto_wallet_auth_logs_wallet_address; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_crypto_wallet_auth_logs_wallet_address ON public.crypto_wallet_auth_logs USING btree (wallet_address);


--
-- Name: idx_crypto_wallet_challenges_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_crypto_wallet_challenges_expires_at ON public.crypto_wallet_challenges USING btree (expires_at);


--
-- Name: idx_crypto_wallet_challenges_wallet_address; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_crypto_wallet_challenges_wallet_address ON public.crypto_wallet_challenges USING btree (wallet_address);


--
-- Name: idx_crypto_wallet_connections_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_crypto_wallet_connections_user_id ON public.crypto_wallet_connections USING btree (user_id);


--
-- Name: idx_crypto_wallet_connections_wallet_address; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_crypto_wallet_connections_wallet_address ON public.crypto_wallet_connections USING btree (wallet_address);


--
-- Name: idx_crypto_wallet_connections_wallet_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_crypto_wallet_connections_wallet_type ON public.crypto_wallet_connections USING btree (wallet_type);


--
-- Name: idx_otps_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_otps_created_at ON public.otps USING btree (created_at);


--
-- Name: idx_otps_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_otps_email ON public.otps USING btree (email);


--
-- Name: idx_otps_email_type_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_otps_email_type_created ON public.otps USING btree (email, type, created_at DESC);


--
-- Name: idx_otps_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_otps_expires_at ON public.otps USING btree (expires_at);


--
-- Name: idx_otps_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_otps_status ON public.otps USING btree (status);


--
-- Name: idx_otps_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_otps_type ON public.otps USING btree (type);


--
-- Name: idx_sport_bets_bet_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sport_bets_bet_status ON public.sport_bets USING btree (status);


--
-- Name: idx_sport_bets_placed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sport_bets_placed_at ON public.sport_bets USING btree (placed_at);


--
-- Name: idx_sport_bets_transaction_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sport_bets_transaction_id ON public.sport_bets USING btree (transaction_id);


--
-- Name: idx_sport_bets_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sport_bets_user_id ON public.sport_bets USING btree (user_id);


--
-- Name: idx_squads_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_squads_type ON public.squads USING btree (type);


--
-- Name: idx_tournaments_rank; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_rank ON public.tournaments USING btree (rank);


--
-- Name: idx_waiting_squad_members_user_squad; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_waiting_squad_members_user_squad ON public.waiting_squad_members USING btree (user_id, squad_id);


--
-- Name: uniq_adds_services_service_id_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_adds_services_service_id_active ON public.adds_services USING btree (service_id) WHERE (deleted_at IS NULL);


--
-- Name: uniq_adds_services_service_id_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_adds_services_service_id_deleted ON public.adds_services USING btree (service_id, deleted_at);


--
-- Name: uniq_company_support_phone_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_company_support_phone_active ON public.company USING btree (support_phone) WHERE (deleted_at IS NULL);


--
-- Name: uniq_company_support_phone_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_company_support_phone_deleted ON public.company USING btree (support_phone, deleted_at);


--
-- Name: uniq_levels_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_levels_deleted ON public.levels USING btree (level, deleted_at);


--
-- Name: uniq_lottery_client_id_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_lottery_client_id_active ON public.lottery_services USING btree (client_id) WHERE (deleted_at IS NULL);


--
-- Name: uniq_lottery_client_id_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_lottery_client_id_deleted ON public.lottery_services USING btree (client_id, deleted_at);


--
-- Name: uniq_squads_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_squads_active ON public.squads USING btree (handle) WHERE (deleted_at IS NULL);


--
-- Name: uniq_squads_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_squads_deleted ON public.squads USING btree (handle, deleted_at);


--
-- Name: crypto_wallet_connections trigger_update_crypto_wallet_connections_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_update_crypto_wallet_connections_updated_at BEFORE UPDATE ON public.crypto_wallet_connections FOR EACH ROW EXECUTE FUNCTION public.update_crypto_wallet_connections_updated_at();


--
-- Name: otps update_otps_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_otps_updated_at BEFORE UPDATE ON public.otps FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: account_block account_block_blocked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_block
    ADD CONSTRAINT account_block_blocked_by_fkey FOREIGN KEY (blocked_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: account_block account_block_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_block
    ADD CONSTRAINT account_block_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: adds_services adds_services_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.adds_services
    ADD CONSTRAINT adds_services_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: airtime_transactions airtime_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.airtime_transactions
    ADD CONSTRAINT airtime_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: balance_logs balance_logs_operational_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balance_logs
    ADD CONSTRAINT balance_logs_operational_group_id_fkey FOREIGN KEY (operational_group_id) REFERENCES public.operational_groups(id) ON DELETE CASCADE;


--
-- Name: balance_logs balance_logs_operational_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balance_logs
    ADD CONSTRAINT balance_logs_operational_type_id_fkey FOREIGN KEY (operational_type_id) REFERENCES public.operational_types(id) ON DELETE CASCADE;


--
-- Name: balance_logs balance_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balance_logs
    ADD CONSTRAINT balance_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: balances balances_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: bets bets_round_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bets
    ADD CONSTRAINT bets_round_id_fkey FOREIGN KEY (round_id) REFERENCES public.rounds(id) ON DELETE CASCADE;


--
-- Name: bets bets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bets
    ADD CONSTRAINT bets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: company company_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company
    ADD CONSTRAINT company_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: crypto_kings crypto_kings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crypto_kings
    ADD CONSTRAINT crypto_kings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: crypto_wallet_connections crypto_wallet_connections_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crypto_wallet_connections
    ADD CONSTRAINT crypto_wallet_connections_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: departements_users departements_users_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departements_users
    ADD CONSTRAINT departements_users_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE CASCADE;


--
-- Name: departements_users departements_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departements_users
    ADD CONSTRAINT departements_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: failed_bet_logs failed_bet_logs_bet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_bet_logs
    ADD CONSTRAINT failed_bet_logs_bet_id_fkey FOREIGN KEY (bet_id) REFERENCES public.bets(id) ON DELETE CASCADE;


--
-- Name: failed_bet_logs failed_bet_logs_round_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_bet_logs
    ADD CONSTRAINT failed_bet_logs_round_id_fkey FOREIGN KEY (round_id) REFERENCES public.rounds(id) ON DELETE CASCADE;


--
-- Name: failed_bet_logs failed_bet_logs_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_bet_logs
    ADD CONSTRAINT failed_bet_logs_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.balance_logs(id) ON DELETE CASCADE;


--
-- Name: failed_bet_logs failed_bet_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_bet_logs
    ADD CONSTRAINT failed_bet_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_referrals fk_agent_referrals_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_referrals
    ADD CONSTRAINT fk_agent_referrals_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: levels fk_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.levels
    ADD CONSTRAINT fk_created_by FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: level_requirements fk_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.level_requirements
    ADD CONSTRAINT fk_created_by FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: level_requirements fk_level_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.level_requirements
    ADD CONSTRAINT fk_level_id FOREIGN KEY (level_id) REFERENCES public.levels(id) ON DELETE CASCADE;


--
-- Name: squads_earns fk_squad_earns_squad; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.squads_earns
    ADD CONSTRAINT fk_squad_earns_squad FOREIGN KEY (squad_id) REFERENCES public.squads(id) ON DELETE CASCADE;


--
-- Name: squads_earns fk_squad_earns_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.squads_earns
    ADD CONSTRAINT fk_squad_earns_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: squads fk_squad_owner; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.squads
    ADD CONSTRAINT fk_squad_owner FOREIGN KEY (owner) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: squads_memebers fk_squad_user_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.squads_memebers
    ADD CONSTRAINT fk_squad_user_by FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: logs fk_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: football_matchs football_matchs_round_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.football_matchs
    ADD CONSTRAINT football_matchs_round_id_fkey FOREIGN KEY (round_id) REFERENCES public.football_match_rounds(id) ON DELETE CASCADE;


--
-- Name: game_logs game_logs_round_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.game_logs
    ADD CONSTRAINT game_logs_round_id_fkey FOREIGN KEY (round_id) REFERENCES public.rounds(id) ON DELETE CASCADE;


--
-- Name: ip_filters ip_filters_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ip_filters
    ADD CONSTRAINT ip_filters_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: login_attempts login_attempts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_attempts
    ADD CONSTRAINT login_attempts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: lottery_winners_logs lottery_winners_logs_lottery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lottery_winners_logs
    ADD CONSTRAINT lottery_winners_logs_lottery_id_fkey FOREIGN KEY (lottery_id) REFERENCES public.lotteries(id) ON DELETE CASCADE;


--
-- Name: lottery_winners_logs lottery_winners_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lottery_winners_logs
    ADD CONSTRAINT lottery_winners_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: manual_funds manual_funds_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.manual_funds
    ADD CONSTRAINT manual_funds_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: manual_funds manual_funds_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.manual_funds
    ADD CONSTRAINT manual_funds_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: operational_types operational_types_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_types
    ADD CONSTRAINT operational_types_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.operational_groups(id) ON DELETE CASCADE;


--
-- Name: plinko plinko_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plinko
    ADD CONSTRAINT plinko_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: quick_hustles quick_hustles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quick_hustles
    ADD CONSTRAINT quick_hustles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: roll_da_dice roll_da_dice_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roll_da_dice
    ADD CONSTRAINT roll_da_dice_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: scratch_cards scratch_cards_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scratch_cards
    ADD CONSTRAINT scratch_cards_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: spinning_wheel_configs spinning_wheel_configs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spinning_wheel_configs
    ADD CONSTRAINT spinning_wheel_configs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: spinning_wheel_mysteries spinning_wheel_mysteries_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spinning_wheel_mysteries
    ADD CONSTRAINT spinning_wheel_mysteries_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: spinning_wheel_rewards spinning_wheel_rewards_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spinning_wheel_rewards
    ADD CONSTRAINT spinning_wheel_rewards_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: spinning_wheels spinning_wheels_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spinning_wheels
    ADD CONSTRAINT spinning_wheels_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sport_bets sport_bets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sport_bets
    ADD CONSTRAINT sport_bets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: street_kings street_kings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.street_kings
    ADD CONSTRAINT street_kings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tournaments_claims tournaments_claims_squad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournaments_claims
    ADD CONSTRAINT tournaments_claims_squad_id_fkey FOREIGN KEY (squad_id) REFERENCES public.squads(id) ON DELETE CASCADE;


--
-- Name: tournaments_claims tournaments_claims_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournaments_claims
    ADD CONSTRAINT tournaments_claims_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE CASCADE;


--
-- Name: user_notifications user_notifications_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_notifications
    ADD CONSTRAINT user_notifications_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: users_football_matche_rounds users_football_matche_rounds_football_round_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_football_matche_rounds
    ADD CONSTRAINT users_football_matche_rounds_football_round_id_fkey FOREIGN KEY (football_round_id) REFERENCES public.football_match_rounds(id) ON DELETE CASCADE;


--
-- Name: users_football_matche_rounds users_football_matche_rounds_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_football_matche_rounds
    ADD CONSTRAINT users_football_matche_rounds_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users_football_matches users_football_matches_match_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_football_matches
    ADD CONSTRAINT users_football_matches_match_id_fkey FOREIGN KEY (match_id) REFERENCES public.football_matchs(id) ON DELETE CASCADE;


--
-- Name: waiting_squad_members waiting_squad_members_squad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waiting_squad_members
    ADD CONSTRAINT waiting_squad_members_squad_id_fkey FOREIGN KEY (squad_id) REFERENCES public.squads(id) ON DELETE CASCADE;


--
-- Name: waiting_squad_members waiting_squad_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waiting_squad_members
    ADD CONSTRAINT waiting_squad_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

